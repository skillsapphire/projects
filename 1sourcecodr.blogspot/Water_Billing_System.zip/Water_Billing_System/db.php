<?php
$conn = mysqli_connect('localhost', 'root', '',"sourcecodester_wbsdb");
	 if (!$conn)
    {
	 die('Could not connect: ' . mysql_error());
	} 
	

