# Smart Parking - PHP

1. Install XAMPP/WAMP

2. Move the files to htdocs / www

3. Import the Database files (parking.sql in DataBase files) to PHPMyAdmin

4. Done 
