<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.1.0
    </div>
    <strong>Student Management System &nbsp;<a href="https://www.campcodes.com">Developed By CampCodes</a>.</strong> All rights
    reserved 2020.
  </footer>