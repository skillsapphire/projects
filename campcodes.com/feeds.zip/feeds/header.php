<!DOCTYPE html>
<html>
    <head>

        <title>Lady Joy Feeds Supply</title>
   
        <link href="css1/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
       
       
    </head>
    <script src="js/bootstrap.js" type="text/javascript"></script>
<?php 
include('db.php');
?>
