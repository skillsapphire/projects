<?php
mysql_select_db('ladyjoy_fs',mysql_connect('localhost','root',''))or die(mysql_error());

?>