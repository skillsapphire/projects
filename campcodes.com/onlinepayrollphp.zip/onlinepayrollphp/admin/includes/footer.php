<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2020 <a href="https://www.youtube.com/channel/UCsFgC9ggwrmYR2XqEHXpbNg/">Ser Bermz</a></strong>
</footer>