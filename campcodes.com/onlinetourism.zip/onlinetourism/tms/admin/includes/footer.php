<div class="copyrights">
	 <p>© 2016 TMS. All Rights Reserved |  <a href="#">TMS</a> </p>
</div>	
