<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-xs-12 col-sm-9">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
						<div class="panel-body">	
					
							<fieldset>
								<legend><h2 class="text-left">Location</h2></legend>
									<iframe width="500" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps/ms?msa=0&amp;msid=216284867372251359438.0004f12903dc23b39f7d5&amp;ie=UTF8&amp;t=h&amp;ll=9.991135,122.813008&amp;spn=0.00317,0.003219&amp;z=17&amp;output=embed"></iframe>
									<br /><small>View <a href="https://maps.google.com/maps/ms?msa=0&amp;msid=216284867372251359438.0004f12903dc23b39f7d5&amp;ie=UTF8&amp;t=h&amp;ll=9.991135,122.813008&amp;spn=0.00317,0.003219&amp;z=17&amp;source=embed" style="color:#0000FF;text-align:left">My Saved Places</a> in a larger map</small>	
									<p><i>our strategic position gives an easy access to the northern tourist corridor circuit, Hells gate Naivasha, Maasai mara, Lake Nakuru and the lake Bogoria hot spirngs. In addition we have easy access to the northern Kenya tourist circuit through the by pass to the Thika road, 
										mount Kenya national park,Meru national parks
									</i></p>

							</fieldset>	
						</div>
					</div>	
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
