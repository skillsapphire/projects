<div class="clearfix"></div>
<!--footer-->
<br>
<br>
<br>
<br>
<footer id="footer">
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p>&copy; 2015 JobsFinder &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')         </script> 
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.js"></script>
</body>
</html>