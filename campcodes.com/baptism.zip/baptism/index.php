<?php require_once("includes/initialize.php");?>
<?php include("header.php");?>
    <div class="container">
     <div class="starter-template">
        <h2 align="Left">Home</h2>
    
			<script>
				window.location="search.php";
			</script>
		</div>
    </div><!-- /.container -->

<?php include("footer.php");?>