<?php
/**
* Description:	The main class for Database.
* Author:		Joken Villanueva
* Date Created:	May 18, 2013
* Revised By:		
*/

//Database Constants
defined('DB_SERVER') ? null : define("DB_SERVER","localhost");
defined('DB_USER') ? null : define("DB_USER","root");
defined('DB_PASS') ? null : define("DB_PASS","");
defined('DB_NAME') ? null : define("DB_NAME","dbpims");
?>