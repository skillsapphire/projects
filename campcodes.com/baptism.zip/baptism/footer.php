  <hr width="50%">
  <footer>
        <p align="center">&copy; joken 2013 - <a href="http://www.sourcecodester.com/">www.sourcecodester.com</a></p>
      </footer>   
   <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script src="datepicker//js/bootstrap-datepicker.js"></script>
  </body>
</html>
  
