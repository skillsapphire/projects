<?php require_once("includes/initialize.php");?>
<?php include("header.php");?>
    <div class="container">
     <div class="starter-template">
        <h2 align="Left">Contact</h2>
			<div class="well">
				<h2>About Baptism Information System</h2>
				<h4><strong>Email:</strong> joken000189561@gmail.com</h4>
				<h4><strong>Cell No.</strong> 09983344318</h4>
			</div>
			
		</div>
    </div><!-- /.container -->

<?php include("footer.php");?>