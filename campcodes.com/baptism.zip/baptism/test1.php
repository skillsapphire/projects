<?php

echo $cur_date = trim($_POST['cur_date']);
echo '<br/>';
echo $birth_date  = $_POST['birth_date'];
?>