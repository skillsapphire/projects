<footer class="footer-area section_gap">
        <div class="container" align="center">

    <h2 align="center" style="color:#fff"> Teacher Records Management System</h2>
    <span style="color:#fff" >&copy;<a href="https://campcodes.com" target="_blank"> CampCodes</a></span>
        </div>
    </footer>