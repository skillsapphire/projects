<!-- <h1><?php echo $title;?></h1> -->

<div class="col-lg-12">  
<h4>Mandate</h4>
    <p> The Philippine Science High School System is an attached agency of the Department of Science and Technology (DOST).  The Board of Trustees (BOT), with the DOST Secretary as the Chairman, is the highest policy making body of the PSHS System. </p> 
</div>
<div  class="col-lg-6">
  <h4>Vision</h4> 
  <p>We are the leading science high school in the Asia Pacific Region preparing our scholars to become globally competitive Filipino scientists equipped with 21st century skills and imbued with the core values of truth, excellence, and service to nation.</p>
  <h4>Mission</h4>
  <p> The Philippine Science High School, operating under one System of Governance and Management, provides scholarship to students with high aptitude in science and mathematics.</p>
  <h4>Core Values</h4> 
  <ol>
    <li>Pursuit of TRUTH.</li>  
    <li>Passion for EXCELLENCE</li> 
    <li>Commitment to SERVICE</li> 
  </ol>


</div>
<div  class="col-lg-6">
  <h4>Guiding Principles</h4> 
    <ul>
      <li>Academic Freedom </li>
      <li>Responsibility</li>
      <li>Academic Standards</li>  
    </ul>

</div>
 

