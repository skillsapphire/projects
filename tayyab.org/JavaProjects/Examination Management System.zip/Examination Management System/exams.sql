-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 02, 2016 at 03:23 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `exams`
--
CREATE DATABASE IF NOT EXISTS `exams` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `exams`;

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `class_id` varchar(10) NOT NULL,
  `c_name` varchar(30) NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `c_name`) VALUES
('fsce1', 'Fsc_Pre_Engineering'),
('fsce2', 'Fsc_Pre_Engineering'),
('fscm1', 'Fsc_Pre_Medical'),
('fscm2', 'Fsc_Pre_Medical');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `course_id` varchar(30) NOT NULL,
  `course_name` varchar(30) NOT NULL,
  `tot_marks` int(10) NOT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `course_name`, `tot_marks`) VALUES
('bio18', 'Biology', 0),
('che16', 'Chemistry', 0),
('eng11', 'English', 0),
('isl13', 'Islamiyat', 0),
('math17', 'Mathematics', 0),
('phy15', 'Physics', 0),
('pk14', 'Pakistan_Studies', 0),
('urd12', 'Urdu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `first_term`
--

CREATE TABLE IF NOT EXISTS `first_term` (
  `roll_no` varchar(30) NOT NULL,
  `class_id` varchar(30) NOT NULL,
  `English` varchar(30) NOT NULL,
  `Urdu` varchar(30) NOT NULL,
  `Islamiyat` varchar(30) NOT NULL,
  `Pakistan_Studies` varchar(30) NOT NULL,
  `Physics` varchar(30) NOT NULL,
  `Chemistry` varchar(30) NOT NULL,
  `Biology` varchar(30) NOT NULL,
  `Mathematics` varchar(30) NOT NULL,
  PRIMARY KEY (`roll_no`,`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `first_term`
--

INSERT INTO `first_term` (`roll_no`, `class_id`, `English`, `Urdu`, `Islamiyat`, `Pakistan_Studies`, `Physics`, `Chemistry`, `Biology`, `Mathematics`) VALUES
('1', 'fsce1', '73', '83', '93', '83', '83', '93', '', '98'),
('2', 'fsce2', '76', '88', '98', '88', '88', '95', '', '99'),
('4', 'fscm2', '76', '89', '90', '87', '89', '90', '98', ''),
('5', 'fscm1', '87', '90', '89', '85', '88', '98', '93', ''),
('6', 'fscm1', '67', '98', '86', '84', '90', '91', '89', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `name` text NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`name`, `username`, `password`) VALUES
('Ramisha Farrukh', 'ram1234', 'mathematics20');

-- --------------------------------------------------------

--
-- Table structure for table `second_term`
--

CREATE TABLE IF NOT EXISTS `second_term` (
  `roll_no` varchar(30) NOT NULL,
  `class_id` varchar(30) NOT NULL,
  `English` varchar(30) NOT NULL,
  `Urdu` varchar(30) NOT NULL,
  `Islamiyat` varchar(30) NOT NULL,
  `Pakistan_Studies` varchar(30) NOT NULL,
  `Physics` varchar(30) NOT NULL,
  `Chemistry` varchar(30) NOT NULL,
  `Biology` varchar(30) NOT NULL,
  `Mathematics` varchar(30) NOT NULL,
  PRIMARY KEY (`roll_no`,`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `second_term`
--

INSERT INTO `second_term` (`roll_no`, `class_id`, `English`, `Urdu`, `Islamiyat`, `Pakistan_Studies`, `Physics`, `Chemistry`, `Biology`, `Mathematics`) VALUES
('1', 'fsce1', '77', '87', '97', '87', '87', '97', '', '97'),
('2', 'fsce2', '77', '87', '97', '87', '87', '97', '', '97'),
('4', 'fscm2', '73', '83', '93', '83', '83', '93', '93', ''),
('5', 'fscm1', '83', '91', '85', '89', '87', '93', '90', ''),
('6', 'fscm1', '83', '91', '85', '89', '87', '93', '90', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `roll_no` varchar(30) NOT NULL,
  `s_name` varchar(30) NOT NULL,
  `f_name` varchar(30) NOT NULL,
  `class_id` varchar(10) NOT NULL,
  `DOB` varchar(30) NOT NULL,
  PRIMARY KEY (`roll_no`,`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`roll_no`, `s_name`, `f_name`, `class_id`, `DOB`) VALUES
('1', 'Rabia Farrukh', 'Farrukh Rafiq', 'fsce1', '11/09/1995'),
('2', 'Mnahal Farrukh', 'Farrukh Rafiq', 'fsce2', '23/10/2002'),
('3', 'Azib Ahmad', 'Farrukh Rafiq', 'fsce2', '17/01/1995'),
('4', 'Ramisha Farrukh', 'Farrukh Rafiq', 'fscm2', '29/11/1993'),
('5', 'Sadia Zahra', 'Malik Khizar Hayat', 'fscm1', '10/5/1991'),
('6', 'Hira Qamar', 'Qamar ul Zaman', 'fscm1', '20/3/1995'),
('7', 'Ume Aiman Bilal', 'Bilal Khan', 'fsce1', '8/8/1995'),
('8', 'Aymen Mushtaq', 'Mushtaq Javed', 'fscm2', '2/9/1993');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `first_term`
--
ALTER TABLE `first_term`
  ADD CONSTRAINT `first_term_ibfk_1` FOREIGN KEY (`roll_no`) REFERENCES `student` (`roll_no`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `second_term`
--
ALTER TABLE `second_term`
  ADD CONSTRAINT `second_term_ibfk_1` FOREIGN KEY (`roll_no`) REFERENCES `student` (`roll_no`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
