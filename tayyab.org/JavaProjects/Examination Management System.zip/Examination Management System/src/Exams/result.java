package Exams;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class result extends JFrame {

	private JPanel contentPane;
	public static JTextField e1_textField;
	public static JTextField e2_textField_1;
	public static JTextField u1_textField_2;
	public static JTextField u2_textField_3;
	public static JTextField i1_textField_4;
	public static JTextField i2_textField_5;
	public static JTextField p1_textField_6;
	public static JTextField p2_textField_7;
	public static JTextField ph1_textField_8;
	public static JTextField ph2_textField_9;
	public static JTextField c1_textField_10;
	public static JTextField c2_textField_11;
	public static JTextField b1_textField_12;
	public static JTextField b2_textField_13;
	public static JTextField m1_textField_14;
	public static JTextField m2_textField_15;
	public static JTextField name_textField_16;
	public static JTextField f_nametextField_17;
	public static JTextField e_textField;
	public static JTextField u_textField_1;
	public static JTextField i_textField_2;
	public static JTextField p_textField_3;
	public static JTextField ph_textField_4;
	public static JTextField c_textField_5;
	public static JTextField b_textField_6;
	public static JTextField m_textField_7;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					result frame = new result();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public result() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 501, 607);
		contentPane = new JPanel();
		contentPane.setFont(new Font("SimSun-ExtB", Font.BOLD, 12));
		contentPane.setBackground(new Color(70, 130, 180));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		e1_textField = new JTextField();
		e1_textField.setBounds(142, 182, 92, 24);
		contentPane.add(e1_textField);
		e1_textField.setColumns(10);
		
		e2_textField_1 = new JTextField();
		e2_textField_1.setBounds(255, 182, 92, 24);
		contentPane.add(e2_textField_1);
		e2_textField_1.setColumns(10);
		
		u1_textField_2 = new JTextField();
		u1_textField_2.setBounds(142, 224, 92, 24);
		contentPane.add(u1_textField_2);
		u1_textField_2.setColumns(10);
		
		u2_textField_3 = new JTextField();
		u2_textField_3.setBounds(255, 224, 92, 24);
		contentPane.add(u2_textField_3);
		u2_textField_3.setColumns(10);
		
		i1_textField_4 = new JTextField();
		i1_textField_4.setBounds(142, 269, 92, 24);
		contentPane.add(i1_textField_4);
		i1_textField_4.setColumns(10);
		
		i2_textField_5 = new JTextField();
		i2_textField_5.setBounds(255, 266, 92, 27);
		contentPane.add(i2_textField_5);
		i2_textField_5.setColumns(10);
		
		p1_textField_6 = new JTextField();
		p1_textField_6.setBounds(142, 308, 92, 24);
		contentPane.add(p1_textField_6);
		p1_textField_6.setColumns(10);
		
		p2_textField_7 = new JTextField();
		p2_textField_7.setBounds(255, 308, 92, 24);
		contentPane.add(p2_textField_7);
		p2_textField_7.setColumns(10);
		
		ph1_textField_8 = new JTextField();
		ph1_textField_8.setBounds(142, 350, 92, 24);
		contentPane.add(ph1_textField_8);
		ph1_textField_8.setColumns(10);
		
		ph2_textField_9 = new JTextField();
		ph2_textField_9.setBounds(255, 350, 92, 24);
		contentPane.add(ph2_textField_9);
		ph2_textField_9.setColumns(10);
		
		c1_textField_10 = new JTextField();
		c1_textField_10.setBounds(142, 392, 92, 24);
		contentPane.add(c1_textField_10);
		c1_textField_10.setColumns(10);
		
		c2_textField_11 = new JTextField();
		c2_textField_11.setBounds(255, 392, 92, 24);
		contentPane.add(c2_textField_11);
		c2_textField_11.setColumns(10);
		
		b1_textField_12 = new JTextField();
		b1_textField_12.setBounds(142, 434, 92, 24);
		contentPane.add(b1_textField_12);
		b1_textField_12.setColumns(10);
		
		b2_textField_13 = new JTextField();
		b2_textField_13.setBounds(255, 434, 92, 24);
		contentPane.add(b2_textField_13);
		b2_textField_13.setColumns(10);
		
		m1_textField_14 = new JTextField();
		m1_textField_14.setBounds(142, 434, 92, 24);
		contentPane.add(m1_textField_14);
		m1_textField_14.setColumns(10);
		
		m2_textField_15 = new JTextField();
		m2_textField_15.setBounds(255, 434, 92, 24);
		contentPane.add(m2_textField_15);
		m2_textField_15.setColumns(10);
		
		name_textField_16 = new JTextField();
		name_textField_16.setBounds(142, 55, 320, 24);
		contentPane.add(name_textField_16);
		name_textField_16.setColumns(10);
		
		f_nametextField_17 = new JTextField();
		f_nametextField_17.setBounds(142, 90, 320, 24);
		contentPane.add(f_nametextField_17);
		f_nametextField_17.setColumns(10);
		
		e_textField = new JTextField();
		e_textField.setBounds(370, 182, 92, 24);
		contentPane.add(e_textField);
		e_textField.setColumns(10);
		
		u_textField_1 = new JTextField();
		u_textField_1.setBounds(370, 224, 92, 24);
		contentPane.add(u_textField_1);
		u_textField_1.setColumns(10);
		
		i_textField_2 = new JTextField();
		i_textField_2.setBounds(370, 266, 92, 24);
		contentPane.add(i_textField_2);
		i_textField_2.setColumns(10);
		
		p_textField_3 = new JTextField();
		p_textField_3.setBounds(370, 308, 92, 24);
		contentPane.add(p_textField_3);
		p_textField_3.setColumns(10);
		
		ph_textField_4 = new JTextField();
		ph_textField_4.setBounds(370, 350, 92, 24);
		contentPane.add(ph_textField_4);
		ph_textField_4.setColumns(10);
		
		c_textField_5 = new JTextField();
		c_textField_5.setBounds(370, 392, 92, 24);
		contentPane.add(c_textField_5);
		c_textField_5.setColumns(10);
		
		b_textField_6 = new JTextField();
		b_textField_6.setBounds(370, 434, 92, 24);
		contentPane.add(b_textField_6);
		b_textField_6.setColumns(10);
		
		m_textField_7 = new JTextField();
		m_textField_7.setBounds(370, 434, 92, 24);
		contentPane.add(m_textField_7);
		m_textField_7.setColumns(10);
		
		JButton btnShowResult = new JButton("show result");
		btnShowResult.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		btnShowResult.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				code r=new code();
				String a;
				a=(JOptionPane.showInputDialog("Enter Roll Number: "));
				r.f_select(a);
				r.s_select(a);
				
				int b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,s,t,u,v,w,x,y,z;
				
				b=Integer.parseInt(e1_textField.getText());
				c=Integer.parseInt(e2_textField_1.getText());
				d=b+c;
				e_textField.setText(String.valueOf(d));
				
				e=Integer.parseInt(u1_textField_2.getText());
				f=Integer.parseInt(u2_textField_3.getText());
				g=e+f;
				u_textField_1.setText(String.valueOf(g));
				
				h=Integer.parseInt(i1_textField_4.getText());
				i=Integer.parseInt(i2_textField_5.getText());
				j=h+i;
				i_textField_2.setText(String.valueOf(j));
				
				k=Integer.parseInt(p1_textField_6.getText());
				l=Integer.parseInt(p2_textField_7.getText());
				m=k+l;
				p_textField_3.setText(String.valueOf(m));
				
				n=Integer.parseInt(ph1_textField_8.getText());
				o=Integer.parseInt(ph2_textField_9.getText());
				p=n+o;
				ph_textField_4.setText(String.valueOf(p));
				
				q=Integer.parseInt(c1_textField_10.getText());
				s=Integer.parseInt(c2_textField_11.getText());
				t=q+s;
				c_textField_5.setText(String.valueOf(t));
				
				u=Integer.parseInt(b1_textField_12.getText());
				v=Integer.parseInt(b2_textField_13.getText());
				w=u+v;
				b_textField_6.setText(String.valueOf(w));
				
				x=Integer.parseInt(m1_textField_14.getText());
				y=Integer.parseInt(m2_textField_15.getText());
				z=x+y;
				m_textField_7.setText(String.valueOf(z));
			}
		});
		btnShowResult.setBounds(234, 530, 131, 27);
		contentPane.add(btnShowResult);
		
		JLabel lblEnglish = new JLabel("English");
		lblEnglish.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblEnglish.setForeground(Color.WHITE);
		lblEnglish.setBounds(23, 182, 131, 24);
		contentPane.add(lblEnglish);
		
		JLabel lblUrdu = new JLabel("Urdu");
		lblUrdu.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblUrdu.setForeground(Color.WHITE);
		lblUrdu.setBounds(23, 227, 145, 24);
		contentPane.add(lblUrdu);
		
		JLabel lblIslamiyat = new JLabel("Islamiyat");
		lblIslamiyat.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblIslamiyat.setForeground(Color.WHITE);
		lblIslamiyat.setBounds(23, 266, 145, 31);
		contentPane.add(lblIslamiyat);
		
		JLabel lblPakStudy = new JLabel("Pak Study");
		lblPakStudy.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblPakStudy.setForeground(Color.WHITE);
		lblPakStudy.setBounds(23, 311, 135, 24);
		contentPane.add(lblPakStudy);
		
		JLabel lblPhysics = new JLabel("Physics");
		lblPhysics.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblPhysics.setForeground(Color.WHITE);
		lblPhysics.setBounds(23, 350, 131, 31);
		contentPane.add(lblPhysics);
		
		JLabel lblChemistry = new JLabel("Chemistry");
		lblChemistry.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblChemistry.setForeground(Color.WHITE);
		lblChemistry.setBounds(23, 392, 145, 31);
		contentPane.add(lblChemistry);
		
		JLabel lblBio = new JLabel("Bio");
		lblBio.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblBio.setForeground(Color.WHITE);
		lblBio.setBounds(23, 437, 145, 24);
		contentPane.add(lblBio);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(comboBox.getSelectedIndex()==0)
				{ 
					m1_textField_14.hide();
					m2_textField_15.hide();
					m_textField_7.hide();
					b1_textField_12.show();
					b2_textField_13.show();
					b_textField_6.show();
					lblBio.setText("Biology");
				}
				else
				{
					b1_textField_12.hide();
					b2_textField_13.hide();
					b_textField_6.hide();
					m1_textField_14.show();
					m2_textField_15.show();
					m_textField_7.show();
					lblBio.setText("Mathematics");
				}
				
			}
		});
		comboBox.setBounds(255, 11, 207, 33);
		contentPane.add(comboBox);
		comboBox.addItem("Medical");
		comboBox.addItem("Engineering");
		
		JLabel lblStudentName = new JLabel("Student Name:");
		lblStudentName.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblStudentName.setForeground(Color.WHITE);
		lblStudentName.setBounds(23, 60, 109, 14);
		contentPane.add(lblStudentName);
		
		JLabel lblFatherName = new JLabel("Father Name:");
		lblFatherName.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblFatherName.setForeground(Color.WHITE);
		lblFatherName.setBounds(23, 95, 109, 14);
		contentPane.add(lblFatherName);
		
		JLabel lblFirstTerm = new JLabel("First Term");
		lblFirstTerm.setForeground(Color.WHITE);
		lblFirstTerm.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblFirstTerm.setBounds(143, 157, 91, 14);
		contentPane.add(lblFirstTerm);
		
		JLabel lblSecondTerm = new JLabel("Second Term");
		lblSecondTerm.setForeground(Color.WHITE);
		lblSecondTerm.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblSecondTerm.setBounds(255, 157, 92, 14);
		contentPane.add(lblSecondTerm);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setForeground(Color.WHITE);
		lblTotal.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblTotal.setBounds(366, 157, 46, 14);
		contentPane.add(lblTotal);
	}
}
