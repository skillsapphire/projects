package Exams;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import java.awt.Frame;

public class menu1 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					menu1 frame = new menu1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public menu1() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\ramis\\Downloads\\Documents\\Document-Text-icon.png"));
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnLogin = new JMenu("login");
		menuBar.add(mnLogin);
		
		JMenuItem mntmAddUsers = new JMenuItem("Add Users");
		mntmAddUsers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				add_user add= new add_user();
				add.setVisible(true);
			}
		});
		Image pic= new ImageIcon(this.getClass().getResource("/new.png")).getImage();
		mntmAddUsers.setIcon(new ImageIcon(pic));
		mnLogin.add(mntmAddUsers);
		
		JMenuItem mntmDeleteUser = new JMenuItem("Delete User");
		mntmDeleteUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				code d=new code();
				d.delete(JOptionPane.showInputDialog("Please Enter the username: "));
			}
		});
		mnLogin.add(mntmDeleteUser);
		
		JMenu mnMarks = new JMenu("Marks");
		menuBar.add(mnMarks);
		
		JMenuItem mntmAddMarks = new JMenuItem("Add Marks");
		mnMarks.add(mntmAddMarks);
		
		JMenu mnResults = new JMenu("Results");
		menuBar.add(mnResults);
		
		JMenuItem mntmShowReports = new JMenuItem("show reports");
		mnResults.add(mntmShowReports);
		
		JMenu mnStudent = new JMenu("Student");
		menuBar.add(mnStudent);
		
		JMenuItem mntmAddStudent = new JMenuItem("Add Student");
		mnStudent.add(mntmAddStudent);
		
		JMenuItem mntmDeleteStudent = new JMenuItem("Delete Student");
		mntmDeleteStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				code d=new code();
				d.delete(JOptionPane.showInputDialog("Please Enter the Roll No: "));
			}
		});
		mnStudent.add(mntmDeleteStudent);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		Image pics= new ImageIcon(this.getClass().getResource("/nw back.jpg")).getImage();
		lblNewLabel.setIcon(new ImageIcon(pics));
		lblNewLabel.setBounds(5, 5, 1266, 706);
		contentPane.add(lblNewLabel);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("New menu item");
		mntmNewMenuItem.setBounds(123, 27, 129, 22);
		contentPane.add(mntmNewMenuItem);
	}
}
