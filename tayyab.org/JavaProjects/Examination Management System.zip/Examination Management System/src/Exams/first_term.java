package Exams;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JRadioButton;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ItemEvent;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class first_term extends JFrame {

	private JPanel contentPane;
	private JTextField e_textField;
	private JTextField u_textField_1;
	private JTextField i_textField_2;
	public static JComboBox comboBox;
	public static JComboBox comboBox_1;
	public static JComboBox comboBox_2;
    private JTextField p_textField;
    private JTextField ph_textField_1;
    private JTextField c_textField_2;
    private JTextField b_textField_3;
    private JTextField m_textField_4;
    private JLabel lblNewLabel;
    private JLabel lblClassId;
    private JLabel lblSelectTerm;
    private JLabel lblEnglish;
    private JLabel lblUrdu;
    private JLabel lblIslamiyat;
    private JLabel lblPakStudies;
    private JLabel lblPhysics;
    private JLabel lblChemistry;
    private JLabel lblBiology;
    private JTextField rollnotxt;
	/**
	 * Launch the application.
	 */
    public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					first_term frame = new first_term();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	public first_term() {
	    setBackground(new Color(70, 130, 180));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 491, 570);
		contentPane = new JPanel();
		contentPane.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				comboBox_1.setEnabled(false);
				comboBox.setEnabled(false);
			}
		});
		contentPane.setBackground(new Color(70, 130, 180));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAddMarks = new JLabel("                  Add Marks");
		lblAddMarks.setFont(new Font("Candara", Font.BOLD | Font.ITALIC, 36));
		lblAddMarks.setForeground(new Color(255, 255, 240));
		lblAddMarks.setBounds(20, 192, 444, 55);
		contentPane.add(lblAddMarks);
		
		e_textField = new JTextField();
		e_textField.setBounds(131, 258, 86, 33);
		contentPane.add(e_textField);
		e_textField.setColumns(10);
		
		u_textField_1 = new JTextField();
		u_textField_1.setBounds(131, 312, 87, 33);
		contentPane.add(u_textField_1);
		u_textField_1.setColumns(10);
		
		i_textField_2 = new JTextField();
		i_textField_2.setBounds(132, 367, 86, 33);
		contentPane.add(i_textField_2);
		i_textField_2.setColumns(10);
		
		JComboBox term_comboBox = new JComboBox();
		term_comboBox.setEnabled(false);
		//comboBox.setModel(new DefaultComboBoxModel(new String[] {"first_term", "second_term"}));
		term_comboBox.setBounds(291, 102, 174, 33);
		contentPane.add(term_comboBox);
		//term_comboBox.setSelectedIndex(-1);
		
		p_textField = new JTextField();
		p_textField.setBounds(132, 417, 86, 33);
		contentPane.add(p_textField);
		p_textField.setColumns(10);
		
		ph_textField_1 = new JTextField();
		ph_textField_1.setBounds(378, 258, 86, 33);
		contentPane.add(ph_textField_1);
		ph_textField_1.setColumns(10);
		
		c_textField_2 = new JTextField();
		c_textField_2.setBounds(378, 312, 86, 33);
		contentPane.add(c_textField_2);
		c_textField_2.setColumns(10);
		
		b_textField_3 = new JTextField();
		b_textField_3.setBounds(378, 367, 86, 33);
		contentPane.add(b_textField_3);
		b_textField_3.setColumns(10);
		
		m_textField_4 = new JTextField();
		m_textField_4.setBounds(378, 367, 86, 33);
		contentPane.add(m_textField_4);
		m_textField_4.setColumns(10);
		
		JComboBox id_comboBox_1 = new JComboBox();
		id_comboBox_1.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e){
					term_comboBox.removeAllItems();
					term_comboBox.addItem("first_term");
					term_comboBox.addItem("second_term");
					term_comboBox.setEnabled(true);
					//term_comboBox.setSelectedIndex(-1);
			/*if(comboBox.getSelectedIndex()==0)
					//if(e.getStateChange()== ItemEvent.SELECTED){
			{
					e_textField.setEditable(true);
					u_textField_1.setEditable(true);
					i_textField_2.setEditable(true);
					p_textField.setEditable(true);
					ph_textField_1.setEditable(true);
					c_textField_2.setEditable(true);
					b_textField_3.setEditable(true);
					m_textField_4.setEditable(true);
					}
			else
			{
				e_textField.setEditable(false);
				u_textField_1.setEditable(false);
				i_textField_2.setEditable(false);
				p_textField.setEditable(false);
				ph_textField_1.setEditable(false);
				c_textField_2.setEditable(false);
				b_textField_3.setEditable(false);
				m_textField_4.setEditable(false);
			}*/
			}});
		
		lblBiology = new JLabel("Biology:");
		lblBiology.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		lblBiology.setForeground(Color.WHITE);
		lblBiology.setBounds(272, 375, 96, 14);
		contentPane.add(lblBiology);
		
		id_comboBox_1.setEnabled(false);
		id_comboBox_1.setBounds(291, 58, 174, 33);
		contentPane.add(id_comboBox_1);
		
		JComboBox grp_comboBox_2 = new JComboBox();
		grp_comboBox_2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(grp_comboBox_2.getSelectedIndex()==0)
				{
					id_comboBox_1.removeAllItems();
					id_comboBox_1.addItem("fscm1");
					id_comboBox_1.addItem("fscm2");
					id_comboBox_1.setEnabled(true);
					//id_comboBox_1.setSelectedIndex(-1);
					m_textField_4.hide();
					b_textField_3.show();
					lblBiology.setText("Biology");
				}
				else
				{
					id_comboBox_1.removeAllItems();
					id_comboBox_1.addItem("fsce1");
					id_comboBox_1.addItem("fsce2");
					id_comboBox_1.setEnabled(true);
					//id_comboBox_1.setSelectedIndex(-1);
					b_textField_3.hide();
					m_textField_4.show();
					lblBiology.setText("Mathematics");
				}
			}
		});
		grp_comboBox_2.setBounds(291, 14, 174, 33);
		contentPane.add(grp_comboBox_2);
		grp_comboBox_2.addItem("Fsc_Pre_Medical");
		grp_comboBox_2.addItem("Fsc_Pre_Engineering");
		
		lblNewLabel = new JLabel("Select Group:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		lblNewLabel.setBounds(20, 22, 139, 14);
		contentPane.add(lblNewLabel);
		
		lblClassId = new JLabel("Select Class ID:");
		lblClassId.setForeground(Color.WHITE);
		lblClassId.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		lblClassId.setBounds(20, 66, 139, 14);
		contentPane.add(lblClassId);
		
		lblSelectTerm = new JLabel("Select Term:");
		lblSelectTerm.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		lblSelectTerm.setForeground(Color.WHITE);
		lblSelectTerm.setBounds(20, 110, 147, 14);
		contentPane.add(lblSelectTerm);
		
		lblEnglish = new JLabel("English:");
		lblEnglish.setForeground(Color.WHITE);
		lblEnglish.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		lblEnglish.setBounds(20, 266, 75, 14);
		contentPane.add(lblEnglish);
		
		lblUrdu = new JLabel("Urdu:");
		lblUrdu.setForeground(Color.WHITE);
		lblUrdu.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		lblUrdu.setBounds(20, 320, 74, 14);
		contentPane.add(lblUrdu);
		
		lblIslamiyat = new JLabel("Islamiyat:");
		lblIslamiyat.setForeground(Color.WHITE);
		lblIslamiyat.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		lblIslamiyat.setBounds(20, 375, 86, 14);
		contentPane.add(lblIslamiyat);
		
		lblPakStudies = new JLabel("Pak.Studies:");
		lblPakStudies.setForeground(Color.WHITE);
		lblPakStudies.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		lblPakStudies.setBounds(20, 425, 104, 14);
		contentPane.add(lblPakStudies);
		
		lblPhysics = new JLabel("Physics:");
		lblPhysics.setForeground(Color.WHITE);
		lblPhysics.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		lblPhysics.setBounds(272, 266, 96, 14);
		contentPane.add(lblPhysics);
		
		lblChemistry = new JLabel("Chemistry:");
		lblChemistry.setForeground(Color.WHITE);
		lblChemistry.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		lblChemistry.setBounds(272, 320, 96, 14);
		contentPane.add(lblChemistry);
		
		
		
		rollnotxt = new JTextField();
		rollnotxt.setBounds(291, 146, 173, 31);
		contentPane.add(rollnotxt);
		rollnotxt.setColumns(10);
		
		JButton btnInsert = new JButton("Insert");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(id_comboBox_1.getSelectedIndex()==0)
				{
					if(term_comboBox.getSelectedIndex()==0)
					{
						
						String db="jdbc:mysql://127.0.0.1:3306/exams";//First term medical marks insertion
						String user="root";
						String pass=""; 
						try {
							Connection conn=DriverManager.getConnection(db, user, pass);
							Statement stmt =conn.createStatement();
							String query="insert into first_term values('"+rollnotxt.getText()+"','"+comboBox_1.getSelectedItem()+"','"+e_textField.getText()+"','"+u_textField_1.getText()+"','"+i_textField_2.getText()+"','"+p_textField.getText()+"','"+ph_textField_1.getText()+"','"+c_textField_2.getText()+"','"+b_textField_3.getText()+"','"+m_textField_4.getText()+"')";
							stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(null, " Your data is inserted");
						} catch (SQLException e) {
							
							// TODO Auto-generated catch block
							e.printStackTrace();
						}				
						
					}
					else
					{
						String db="jdbc:mysql://127.0.0.1:3306/exams";//Second term medical marks insertion
						String user="root";
						String pass=""; 
						try {
							Connection conn=DriverManager.getConnection(db, user, pass);
							Statement stmt =conn.createStatement();
							String query="insert into second_term values('"+rollnotxt.getText()+"','fscm2','"+e_textField.getText()+"','"+u_textField_1.getText()+"','"+i_textField_2.getText()+"','"+p_textField.getText()+"','"+ph_textField_1.getText()+"','"+c_textField_2.getText()+"','"+b_textField_3.getText()+"','"+m_textField_4.getText()+"')";
							stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(null, " Your data is inserted");
						} catch (SQLException e) {
							
							// TODO Auto-generated catch block
							e.printStackTrace();
						}				
						
					}
				}
				else
				{
					if(term_comboBox.getSelectedIndex()==0)
					{
						String db="jdbc:mysql://127.0.0.1:3306/exams";//First term engineering marks insertion
						String user="root";
						String pass=""; 
						try {
							Connection conn=DriverManager.getConnection(db, user, pass);
							Statement stmt =conn.createStatement();
							String query="insert into first_term values('"+rollnotxt.getText()+"','fsce1','"+e_textField.getText()+"','"+u_textField_1.getText()+"','"+i_textField_2.getText()+"','"+p_textField.getText()+"','"+ph_textField_1.getText()+"','"+c_textField_2.getText()+"','"+b_textField_3.getText()+"','"+m_textField_4.getText()+"')";
							stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(null, " Your data is inserted");
						} catch (SQLException e) {
							
							// TODO Auto-generated catch block
							e.printStackTrace();
						}				

					}
					else
					{
						String db="jdbc:mysql://127.0.0.1:3306/exams";//second term engineering marks insertion
						String user="root";
						String pass=""; 
						try {
							Connection conn=DriverManager.getConnection(db, user, pass);
							Statement stmt =conn.createStatement();
							String query="insert into second_term values('"+rollnotxt.getText()+"','"+comboBox_1.getSelectedItem().toString()+"','"+e_textField.getText()+"','"+u_textField_1.getText()+"','"+i_textField_2.getText()+"','"+p_textField.getText()+"','"+ph_textField_1.getText()+"','"+c_textField_2.getText()+"','"+b_textField_3.getText()+"','"+m_textField_4.getText()+"')";
							stmt.executeUpdate(query);
							JOptionPane.showMessageDialog(null, " Your data is inserted");
						} catch (SQLException e) {
							
							// TODO Auto-generated catch block
							e.printStackTrace();
						}				

					}
					
				}

			
			}
		});
		btnInsert.setBounds(355, 487, 109, 33);
		contentPane.add(btnInsert);
		
		JLabel lblStudentRoll = new JLabel("Student Roll#");
		lblStudentRoll.setForeground(Color.WHITE);
		lblStudentRoll.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblStudentRoll.setBounds(20, 154, 139, 14);
		contentPane.add(lblStudentRoll);
		

		
	}
}
