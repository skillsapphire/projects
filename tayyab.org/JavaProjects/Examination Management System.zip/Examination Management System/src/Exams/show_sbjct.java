package Exams;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;

public class show_sbjct extends JFrame {

	private JPanel contentPane;
	private JTable table;
	public static JComboBox comboBox_1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					show_sbjct frame = new show_sbjct();
					frame.setVisible(true);
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);	
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public show_sbjct() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\ramis\\Documents\\set.png"));
		setResizable(false);
		setTitle("Subject Result");
		addWindowListener(new WindowAdapter() {
			
			@Override
			
			public void windowActivated(WindowEvent arg0) {
				try 
				{
					Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/exams", "root", "");
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery("select * from course");
					while (rs.next())
					{
						comboBox_1.addItem(rs.getString(2));
					}
					comboBox_1.setSelectedIndex(-1);
				}
				catch (SQLException e){
					JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);	
				}
			}
		});
		setBackground(new Color(0, 139, 139));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 468, 477);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 152, 432, 275);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		comboBox_1 = new JComboBox();
		comboBox_1.setBounds(169, 68, 178, 25);
		contentPane.add(comboBox_1);
		
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(169, 32, 178, 25);
		contentPane.add(comboBox);
		comboBox.addItem("fscm1");
		comboBox.addItem("fscm2");
		comboBox.addItem("fsce1");
		comboBox.addItem("fsce2");
		comboBox.setSelectedIndex(-1);
		
		JButton btnShow = new JButton("Show");
		Image set= new ImageIcon(this.getClass().getResource("/set.png")).getImage();
		btnShow.setIcon(new ImageIcon(set));
		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(comboBox.getSelectedIndex()==-1)
				{
					JOptionPane.showMessageDialog(null, "Please Select class id first!!", "Warning", JOptionPane.WARNING_MESSAGE);
				}
				else if(comboBox_1.getSelectedIndex()==-1)
				{
					JOptionPane.showMessageDialog(null, "Please Select subject first!!", "Warning", JOptionPane.WARNING_MESSAGE);
				}
				else
				{
				try 
				{
					Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/exams", "root", "");
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery("SELECT first_term.roll_no as 'Roll#', student.s_name as 'Name', first_term."+comboBox_1.getSelectedItem().toString()+" ,second_term."+comboBox_1.getSelectedItem().toString()+" from first_term,second_term,student where first_term.roll_no = second_term.roll_no AND student.roll_no=first_term.roll_no AND first_term.class_id ='"+comboBox.getSelectedItem().toString()+"'");
					table.setModel(DbUtils.resultSetToTableModel(rs));
				}
				catch (SQLException e){
					JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);		
				}
				}
			}
		});
		btnShow.setBounds(242, 114, 105, 25);
		contentPane.add(btnShow);
		
		JLabel lblSelectClassId = new JLabel("Select class id:");
		lblSelectClassId.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblSelectClassId.setForeground(Color.WHITE);
		lblSelectClassId.setBounds(10, 32, 146, 25);
		contentPane.add(lblSelectClassId);
		
		JLabel lblSelectSubject = new JLabel("Select Subject:");
		lblSelectSubject.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblSelectSubject.setForeground(Color.WHITE);
		lblSelectSubject.setBounds(10, 68, 146, 25);
		contentPane.add(lblSelectSubject);
	}
}
