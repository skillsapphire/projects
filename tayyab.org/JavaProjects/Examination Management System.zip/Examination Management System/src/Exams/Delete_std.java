package Exams;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ItemEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Delete_std extends JFrame {

	private JPanel contentPane;
	public static JComboBox comboBox;
	public static JComboBox comboBox_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Delete_std frame = new Delete_std();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Delete_std() {
		setTitle("Delete Student");
		setBackground(new Color(46, 139, 87));
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 566, 331);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(347, 90, 174, 28);
		contentPane.add(comboBox);
		comboBox.addItem("fscm1");
		comboBox.addItem("fscm2");
		comboBox.addItem("fsce1");
		comboBox.addItem("fsce2");
		comboBox.setSelectedIndex(-1);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(347, 137, 174, 28);
		contentPane.add(comboBox_1);
		
		comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				try 
				{
					comboBox_1.removeAllItems();
					Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/exams", "root", "");
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery("select roll_no from student where class_id ='"+comboBox.getSelectedItem().toString()+"'");
					while (rs.next())
					{
						comboBox_1.addItem(rs.getString(1));
					}
					comboBox_1.setSelectedIndex(-1);
				}
				catch (SQLException e){
				e.printStackTrace();	
				}
			}
		});
	
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				code c=new code();
				c.del_std(comboBox_1.getSelectedItem().toString());

			}
		});
		btnDelete.setBounds(241, 204, 113, 28);
		contentPane.add(btnDelete);
		
		JLabel label = new JLabel("");
		Image pics= new ImageIcon(this.getClass().getResource("/del.png")).getImage();
		label.setIcon(new ImageIcon(pics));
		label.setBounds(25, 68, 128, 138);
		contentPane.add(label);
		
		JLabel lblSelectClassId = new JLabel("Select Class id:");
		lblSelectClassId.setForeground(new Color(255, 255, 255));
		lblSelectClassId.setFont(new Font("SimSun-ExtB", Font.BOLD | Font.ITALIC, 13));
		lblSelectClassId.setBounds(181, 97, 151, 20);
		contentPane.add(lblSelectClassId);
		
		JLabel lblSelectRollNo = new JLabel("Select Roll No:");
		lblSelectRollNo.setForeground(new Color(255, 255, 255));
		lblSelectRollNo.setFont(new Font("SimSun-ExtB", Font.BOLD | Font.ITALIC, 13));
		lblSelectRollNo.setBounds(181, 144, 151, 21);
		contentPane.add(lblSelectRollNo);
	}
}
