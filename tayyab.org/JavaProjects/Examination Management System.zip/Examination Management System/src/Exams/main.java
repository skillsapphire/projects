package Exams;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.BadLocationException;

import java.awt.Toolkit;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.Component;
import java.awt.SystemColor;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.ActionEvent;

public class main extends JFrame {

	private JPanel contentPane;
	public static main frame;
	private JTextField textField;
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main frame = new main();
					frame.setVisible(true);
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);	
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public main() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\ramis\\Downloads\\Documents\\Register-icon.png"));
		setTitle("LOGIN");
	    
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 670, 479);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setAlignmentX(Component.RIGHT_ALIGNMENT);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setForeground(Color.BLACK);
		textField.setBounds(340, 252, 207, 28);
		contentPane.add(textField);
		textField.setColumns(10);
		
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(340, 304, 207, 28);
		contentPane.add(passwordField_1);
		
		
		JLabel lblUsername = new JLabel("UserName");
		lblUsername.setForeground(new Color(255, 255, 255));
		lblUsername.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		lblUsername.setAlignmentX(Component.RIGHT_ALIGNMENT);
		lblUsername.setFont(new Font("Candara", Font.BOLD, 14));
		lblUsername.setBounds(255, 253, 108, 28);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(new Color(255, 255, 255));
		lblPassword.setFont(new Font("Candara", Font.BOLD, 14));
		lblPassword.setBounds(255, 309, 95, 20);
		contentPane.add(lblPassword);
		
		JLabel label = new JLabel("");
		Image pics= new ImageIcon(this.getClass().getResource("/login.png")).getImage();
		label.setIcon(new ImageIcon(pics));
		label.setBounds(92, 178, 173, 217);
		contentPane.add(label);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setBackground(new Color(176, 196, 222));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				code l= new code();
				l.login_user(textField.getText(), passwordField_1.getText());
				menu m= new menu();
				m.setVisible(true);
			}
		});
		btnNewButton.setForeground(new Color(0, 0, 0));
		Image pic= new ImageIcon(this.getClass().getResource("/Ok-icon.png")).getImage();
		btnNewButton.setIcon(new ImageIcon(pic));
		btnNewButton.setBounds(314, 375, 121, 44);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Cancel");
		btnNewButton_1.setBackground(new Color(176, 196, 222));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnNewButton_1.setForeground(new Color(0, 0, 0));
		Image p= new ImageIcon(this.getClass().getResource("/Close-2-icon.png")).getImage();
		btnNewButton_1.setIcon(new ImageIcon(p));
		btnNewButton_1.setBounds(445, 375, 121, 44);
		contentPane.add(btnNewButton_1);
		
		JLabel label_1 = new JLabel("");
		Image clg= new ImageIcon(this.getClass().getResource("/clg.jpg")).getImage();
		label_1.setIcon(new ImageIcon(clg));
		label_1.setBounds(247, 11, 150, 145);
		contentPane.add(label_1);
		
		JLabel lblExaminationSystem = new JLabel("Examination System");
		lblExaminationSystem.setFont(new Font("Snap ITC", Font.BOLD | Font.ITALIC, 47));
		lblExaminationSystem.setForeground(new Color(255, 255, 255));
		lblExaminationSystem.setBounds(31, 142, 633, 99);
		contentPane.add(lblExaminationSystem);
		
	}
}
