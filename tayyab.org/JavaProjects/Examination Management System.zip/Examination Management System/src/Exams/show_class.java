package Exams;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JComboBox;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Toolkit;

public class show_class extends JFrame {

	private JPanel contentPane;
	public static JTable table;
	public static JComboBox terms_comboBox_1;
	public static JComboBox class_id_comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					show_class frame = new show_class();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public show_class() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\ramis\\Documents\\report.png"));
		setTitle("Class Result");
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent arg0) {
	
			}
		});
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setBounds(0, 100, 1292, 582);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 103, 1256, 581);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		class_id_comboBox = new JComboBox();
		class_id_comboBox.setBounds(260, 11, 199, 31);
		contentPane.add(class_id_comboBox);
		class_id_comboBox.setSelectedIndex(-1);
		class_id_comboBox.addItem("fscm1");
		class_id_comboBox.addItem("fscm2");
		class_id_comboBox.addItem("fsce1");
		class_id_comboBox.addItem("fsce2");
		
		
	    terms_comboBox_1 = new JComboBox();
		terms_comboBox_1.setBounds(260, 53, 199, 31);
		contentPane.add(terms_comboBox_1);
		terms_comboBox_1.setSelectedIndex(-1);
		terms_comboBox_1.addItem("first_term");
		terms_comboBox_1.addItem("second_term");
		
		
		JLabel lblSelectTheClass = new JLabel("Select Class:");
		lblSelectTheClass.setForeground(new Color(255, 255, 255));
		lblSelectTheClass.setFont(new Font("SimSun-ExtB", Font.BOLD | Font.ITALIC, 13));
		lblSelectTheClass.setBounds(88, 14, 180, 23);
		contentPane.add(lblSelectTheClass);
		
		JButton btnShow = new JButton("Show");
		Image set= new ImageIcon(this.getClass().getResource("/set.png")).getImage();
		btnShow.setIcon(new ImageIcon(set));
		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				code tab=new code();
				if(class_id_comboBox.getSelectedIndex()==0 || class_id_comboBox.getSelectedIndex()==1)
				{
					tab.show_classm(class_id_comboBox.getSelectedItem().toString());
				}
				else
				{
					tab.show_classe(class_id_comboBox.getSelectedItem().toString());
				}
			}
		});
		btnShow.setBounds(357, 695, 119, 31);
		contentPane.add(btnShow);
		
		
		JLabel lblSelectTerm = new JLabel("Select Term:");
		lblSelectTerm.setForeground(new Color(255, 255, 255));
		lblSelectTerm.setFont(new Font("SimSun-ExtB", Font.BOLD | Font.ITALIC, 13));
		lblSelectTerm.setBounds(88, 56, 136, 23);
		contentPane.add(lblSelectTerm);
	}
}
