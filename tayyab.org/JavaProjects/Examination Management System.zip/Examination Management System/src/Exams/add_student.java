package Exams;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class add_student extends JFrame {

	private JPanel contentPane;
	private JTextField txtRollno;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JButton btnUpdate;
	private JButton btnInsert;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					add_student frame = new add_student();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public add_student() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 452, 466);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(70, 130, 180));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAddStudent = new JLabel("Add Student");
		lblAddStudent.setVerticalAlignment(SwingConstants.BOTTOM);
		Image pics= new ImageIcon(this.getClass().getResource("/Actions-contact-new-png.png")).getImage();
		lblAddStudent.setIcon(new ImageIcon(pics));
		lblAddStudent.setFont(new Font("Sitka Display", Font.BOLD | Font.ITALIC, 45));
		lblAddStudent.setForeground(new Color(255, 255, 255));
		lblAddStudent.setBounds(10, 11, 424, 120);
		contentPane.add(lblAddStudent);
		
		txtRollno = new JTextField();
		txtRollno.setBounds(159, 160, 207, 27);
		contentPane.add(txtRollno);
		txtRollno.setColumns(10);
		
		textField = new JTextField();
		textField.setText("");
		textField.setBounds(159, 198, 207, 27);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(159, 236, 207, 27);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(159, 274, 208, 27);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    code d=new code();
				//d.update_std(txtRollno.getText(), textField.getText(), textField_1.getText(), textField_2.getText(),textField_3.getText());
			}
		});
		btnUpdate.setBounds(271, 369, 95, 32);
		contentPane.add(btnUpdate);
		
		btnInsert = new JButton("Insert");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				code c=new code();
				//c.insert_std(txtRollno.getText(),textField.getText(),textField_1.getText(),textField_2.getText(),textField_3.getText());
				
			}
		});
		btnInsert.setBounds(159, 369, 95, 32);
		contentPane.add(btnInsert);
		
		textField_3 = new JTextField();
		textField_3.setBounds(159, 312, 209, 27);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblRoll = new JLabel("Roll#");
		lblRoll.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblRoll.setForeground(Color.WHITE);
		lblRoll.setBounds(31, 165, 46, 14);
		contentPane.add(lblRoll);
		
		JLabel lblStudentName = new JLabel("Student Name:");
		lblStudentName.setForeground(Color.WHITE);
		lblStudentName.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblStudentName.setBounds(31, 203, 104, 14);
		contentPane.add(lblStudentName);
		
		JLabel lblFatherName = new JLabel("Father Name:");
		lblFatherName.setForeground(Color.WHITE);
		lblFatherName.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblFatherName.setBounds(31, 241, 104, 14);
		contentPane.add(lblFatherName);
		
		JLabel lblNewLabel = new JLabel("Class ID:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblNewLabel.setBounds(31, 279, 118, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblDateOfBirth = new JLabel("Date of Birth:");
		lblDateOfBirth.setForeground(Color.WHITE);
		lblDateOfBirth.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblDateOfBirth.setBounds(31, 317, 116, 14);
		contentPane.add(lblDateOfBirth);
	}
}
