package Exams;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import java.awt.Toolkit;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;
import javax.swing.JMenu;
import java.awt.SystemColor;
import javax.swing.JComboBox;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import javax.swing.JMenuItem;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JToolBar;

public class menu extends JFrame {

	private JPanel contentPane;
	private JTextField txtRollno;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField e_textField;
	private JTextField u_textField_1;
	private JTextField i_textField_2;
	private JTextField p_textField;
	private JTextField ph_textField_1;
	private JTextField c_textField_2;
	private JTextField m_textField_4;
	private JTextField b3_textField_3;
	private JTextField rollnotxt;
	public static JComboBox grp_comboBox_2;
	public static JComboBox id_comboBox_1;
	public static JComboBox term_comboBox;
	public static JLabel label_16;
	public static JTextField e1_textField;
	public static JTextField e2_textField_1;
	public static JTextField u1_textField_2;
	public static JTextField u2_textField_3;
	public static JTextField i1_textField_4;
	public static JTextField i2_textField_5;
	public static JTextField p1_textField_6;
	public static JTextField p2_textField_7;
	public static JTextField ph1_textField_8;
	public static JTextField ph2_textField_9;
	public static JTextField c1_textField_10;
	public static JTextField c2_textField_11;
	public static JTextField b1_textField_12;
	public static JTextField b2_textField_13;
	public static JTextField m1_textField_14;
	public static JTextField m2_textField_15;
	public static JTextField name_textField_16;
	public static JTextField f_nametextField_17;
	public static JTextField et_textField;
	public static JTextField ut_textField_1;
	public static JTextField it_textField_2;
	public static JTextField pt_textField_3;
	public static JTextField pht_textField_4;
	public static JTextField c_textField_5;
	public static JTextField bt_textField_6;
	public static JTextField mt_textField_7;
	public static JComboBox slct_comboBox;
	public static JTextField textField_4;
	public static JTextField textField_5;
	public static JPasswordField passwordField;
	public static JTextField textField_6;
	public static JTextField textField_7;
	public static JComboBox comboBox_1_id;
	public static JComboBox d_comboBox;
	public static JComboBox m_comboBox_1;
	public static JComboBox y_comboBox_2;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					menu frame = new menu();
					frame.setVisible(true);
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public menu() {
		setResizable(false);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent arg0) {
				code id=new code();
				id.select_class_id();
			}
		});
		setTitle("Altus College Examination System");
		setBackground(new Color(0, 0, 0));
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\ramis\\Documents\\Test-paper-icon.png"));
		//setExtendedState(JFrame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 0, 679, 779);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setForeground(Color.BLACK);
		menuBar.setBackground(new Color(32, 178, 170));
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Statistical Reports");
		mnNewMenu.setForeground(new Color(255, 255, 255));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmClassReport = new JMenuItem("Class Report");
		mntmClassReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				show_class t=new show_class();
				t.setVisible(true);
			}
		});
		Image report= new ImageIcon(this.getClass().getResource("/report.png")).getImage();
		mntmClassReport.setIcon(new ImageIcon(report));
		mnNewMenu.add(mntmClassReport);
		
		JMenuItem mntmSubjectReport = new JMenuItem("Subject Report");
		mntmSubjectReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				show_sbjct sbjct=new show_sbjct();
				sbjct.setVisible(true);
			}
		});
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setOrientation(SwingConstants.VERTICAL);
		mnNewMenu.add(separator_1);
		mnNewMenu.add(mntmSubjectReport);
		Image set= new ImageIcon(this.getClass().getResource("/set.png")).getImage();
		mntmSubjectReport.setIcon(new ImageIcon(set));
		
		JMenu mnDeleteRecord = new JMenu("Delete Record");
		mnDeleteRecord.setForeground(new Color(255, 255, 255));
		menuBar.add(mnDeleteRecord);
		
		JMenuItem mntmDeleteStudent = new JMenuItem("Delete Student");
		Image can= new ImageIcon(this.getClass().getResource("/can.png")).getImage();
		mntmDeleteStudent.setIcon(new ImageIcon(can));
		mntmDeleteStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Delete_std del=new Delete_std();
				del.setVisible(true);
			}
		});
		mnDeleteRecord.add(mntmDeleteStudent);
		
		JMenuItem mntmDeleteUser = new JMenuItem("Delete User");
		Image canc= new ImageIcon(this.getClass().getResource("/can.png")).getImage();
		mntmDeleteUser.setIcon(new ImageIcon(canc));
		mntmDeleteUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				code del=new code();
				del.delete(JOptionPane.showInputDialog("Enter UserName:"));
			}
		});
		mnDeleteRecord.add(mntmDeleteUser);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		Image pics= new ImageIcon(this.getClass().getResource("/clg.jpg")).getImage();
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(5, 127, 653, 587);
		tabbedPane.setBackground(new Color(240, 240, 240));
		contentPane.add(tabbedPane);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(0, 128, 128));
		panel_4.setLayout(null);
		panel_4.setBorder(new EmptyBorder(5, 5, 5, 5));
		tabbedPane.addTab("Welcome", null, panel_4, null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		Image build= new ImageIcon(this.getClass().getResource("/newbuilding.jpg")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(build));
		lblNewLabel_1.setBounds(37, 176, 628, 343);
		panel_4.add(lblNewLabel_1);
		
		JLabel lblWelcome = new JLabel("Welcome");
		lblWelcome.setFont(new Font("Snap ITC", Font.BOLD | Font.ITALIC, 60));
		lblWelcome.setForeground(new Color(255, 255, 255));
		lblWelcome.setBounds(145, 47, 584, 129);
		panel_4.add(lblWelcome);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		panel.setBackground(new Color(0, 128, 128));
		tabbedPane.addTab("Add Students", null, panel, null);
		
		JLabel label = new JLabel("Add Student");
		label.setVerticalAlignment(SwingConstants.BOTTOM);
		Image pic= new ImageIcon(this.getClass().getResource("/Actions-contact-new-png.png")).getImage();
		label.setIcon(new ImageIcon(pic));
		label.setForeground(Color.WHITE);
		label.setFont(new Font("Sitka Display", Font.BOLD | Font.ITALIC, 45));
		label.setBounds(10, 11, 424, 120);
		panel.add(label);
		
		txtRollno = new JTextField();
		txtRollno.setColumns(10);
		txtRollno.setBounds(159, 160, 207, 27);
		panel.add(txtRollno);
		
		textField = new JTextField();
		textField.setText("");
		textField.setColumns(10);
		textField.setBounds(159, 198, 207, 27);
		panel.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(159, 236, 207, 27);
		panel.add(textField_1);
		
		d_comboBox = new JComboBox();
		d_comboBox.setBounds(159, 312, 46, 27);
		panel.add(d_comboBox);
		for(int i=1;i<=31;i++)
		{
			d_comboBox.addItem(i);
		}
		
	    m_comboBox_1 = new JComboBox();
		m_comboBox_1.setBounds(215, 311, 54, 28);
		panel.add(m_comboBox_1);
		for(int i=1;i<=12;i++)
		{
			m_comboBox_1.addItem(i);
		}
		
	     y_comboBox_2 = new JComboBox();
		y_comboBox_2.setBounds(279, 312, 87, 27);
		panel.add(y_comboBox_2);
		for(int i=1985;i<=2000;i++)
		{
			y_comboBox_2.addItem(i);
		}
		
		JButton button = new JButton("Update");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				    code d=new code();
					d.update_std(txtRollno.getText(), textField.getText(), textField_1.getText(), comboBox_1_id.getSelectedItem().toString(),d_comboBox.getSelectedItem().toString(),m_comboBox_1.getSelectedItem().toString(),y_comboBox_2.getSelectedItem().toString());
				}
			
		});
		button.setBounds(271, 369, 95, 32);
		panel.add(button);
		
		JButton button_1 = new JButton("Insert");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				code c=new code();
				c.insert_std(txtRollno.getText(),textField.getText(),textField_1.getText(),comboBox_1_id.getSelectedItem().toString(),d_comboBox.getSelectedItem().toString(),m_comboBox_1.getSelectedItem().toString(),y_comboBox_2.getSelectedItem().toString());
			}
		});
		button_1.setBounds(159, 369, 95, 32);
		panel.add(button_1);
		
		JLabel label_1 = new JLabel("Roll#");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_1.setBounds(31, 165, 46, 14);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("Student Name:");
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_2.setBounds(31, 203, 104, 14);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("Father Name:");
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_3.setBounds(31, 241, 104, 14);
		panel.add(label_3);
		
		JLabel label_4 = new JLabel("Class ID:");
		label_4.setForeground(Color.WHITE);
		label_4.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_4.setBounds(31, 279, 118, 14);
		panel.add(label_4);
		
		JLabel label_5 = new JLabel("Date of Birth:");
		label_5.setForeground(Color.WHITE);
		label_5.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_5.setBounds(31, 317, 116, 14);
		panel.add(label_5);
		
	    comboBox_1_id = new JComboBox();
		comboBox_1_id.setBounds(159, 274, 207, 27);
		panel.add(comboBox_1_id);
		comboBox_1_id.setSelectedIndex(-1);
		
		JButton btnSelect = new JButton("Select");
		btnSelect.setBounds(376, 369, 95, 32);
		panel.add(btnSelect);
		
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBorder(new EmptyBorder(5, 5, 5, 5));
		panel_1.setBackground(new Color(0, 128, 128));
		tabbedPane.addTab("Add Marks", null, panel_1, null);
		
		JLabel label_6 = new JLabel("                  Add Marks");
		label_6.setForeground(new Color(255, 255, 240));
		label_6.setFont(new Font("Candara", Font.BOLD | Font.ITALIC, 36));
		label_6.setBounds(20, 192, 444, 55);
		panel_1.add(label_6);
		
		e_textField = new JTextField();
		e_textField.setColumns(10);
		e_textField.setBounds(131, 258, 86, 33);
		panel_1.add(e_textField);
		
		u_textField_1 = new JTextField();
		u_textField_1.setColumns(10);
		u_textField_1.setBounds(131, 312, 87, 33);
		panel_1.add(u_textField_1);
		
		i_textField_2 = new JTextField();
		i_textField_2.setColumns(10);
		i_textField_2.setBounds(132, 367, 86, 33);
		panel_1.add(i_textField_2);
		
	 term_comboBox = new JComboBox();
		term_comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
			}
		});
		term_comboBox.setBounds(291, 102, 174, 33);
		panel_1.add(term_comboBox);
		
		p_textField = new JTextField();
		p_textField.setColumns(10);
		p_textField.setBounds(132, 417, 86, 33);
		panel_1.add(p_textField);
		
		ph_textField_1 = new JTextField();
		ph_textField_1.setColumns(10);
		ph_textField_1.setBounds(378, 258, 86, 33);
		panel_1.add(ph_textField_1);
		
		c_textField_2 = new JTextField();
		c_textField_2.setColumns(10);
		c_textField_2.setBounds(378, 312, 86, 33);
		panel_1.add(c_textField_2);
		
		m_textField_4 = new JTextField();
		m_textField_4.setColumns(10);
		m_textField_4.setBounds(378, 367, 86, 33);
		panel_1.add(m_textField_4);
		
		b3_textField_3 = new JTextField();
		b3_textField_3.setColumns(10);
		b3_textField_3.setBounds(378, 367, 86, 33);
		panel_1.add(b3_textField_3);
		
		JLabel lblBio = new JLabel("Bio");
		lblBio.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblBio.setForeground(Color.WHITE);
		lblBio.setBounds(275, 370, 145, 24);
		panel_1.add(lblBio);
		
		id_comboBox_1 = new JComboBox();
		
		
		
		id_comboBox_1.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				term_comboBox.addItem("first_term");
				term_comboBox.addItem("second_term");
				
				term_comboBox.setEnabled(true);
				
			}
		});
		id_comboBox_1.setBounds(291, 58, 174, 33);
		panel_1.add(id_comboBox_1);
		
		grp_comboBox_2 = new JComboBox();
		grp_comboBox_2.setSelectedIndex(-1);
		grp_comboBox_2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
			
				if(grp_comboBox_2.getSelectedIndex()==0){
					
					id_comboBox_1.removeAllItems();
					//id_comboBox_1.setEnabled(true);
					id_comboBox_1.addItem("fscm1");
					id_comboBox_1.addItem("fscm2");
					id_comboBox_1.setEnabled(true);
					m_textField_4.hide();
					b3_textField_3.show();
					lblBio.setText("Biology:");
				}
				else
				{
					
					id_comboBox_1.removeAllItems();
					//id_comboBox_1.setEnabled(true);
					id_comboBox_1.addItem("fsce1");
					id_comboBox_1.addItem("fsce2");
					id_comboBox_1.setEnabled(true);
					b3_textField_3.hide();
					m_textField_4.show();
					lblBio.setText("Mathematics:");
				}
			}
		});
	
		grp_comboBox_2.setBounds(291, 14, 174, 33);
		panel_1.add(grp_comboBox_2);
		grp_comboBox_2.addItem("Fsc_Pre_Medical");
		grp_comboBox_2.addItem("Fsc_Pre_Engineering");
		
		JLabel label_7 = new JLabel("Select Group:");
		label_7.setForeground(Color.WHITE);
		label_7.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		label_7.setBounds(20, 22, 139, 14);
		panel_1.add(label_7);
		
		JLabel label_8 = new JLabel("Select Class ID:");
		label_8.setForeground(Color.WHITE);
		label_8.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		label_8.setBounds(20, 66, 139, 14);
		panel_1.add(label_8);
		
		JLabel label_9 = new JLabel("Select Term:");
		label_9.setForeground(Color.WHITE);
		label_9.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		label_9.setBounds(20, 110, 147, 14);
		panel_1.add(label_9);
		
		JLabel label_10 = new JLabel("English:");
		label_10.setForeground(Color.WHITE);
		label_10.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		label_10.setBounds(20, 266, 75, 14);
		panel_1.add(label_10);
		
		JLabel label_11 = new JLabel("Urdu:");
		label_11.setForeground(Color.WHITE);
		label_11.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		label_11.setBounds(20, 320, 74, 14);
		panel_1.add(label_11);
		
		JLabel label_12 = new JLabel("Islamiyat:");
		label_12.setForeground(Color.WHITE);
		label_12.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		label_12.setBounds(20, 375, 86, 14);
		panel_1.add(label_12);
		
		JLabel label_13 = new JLabel("Pak.Studies:");
		label_13.setForeground(Color.WHITE);
		label_13.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		label_13.setBounds(20, 425, 104, 14);
		panel_1.add(label_13);
		
		JLabel label_14 = new JLabel("Physics:");
		label_14.setForeground(Color.WHITE);
		label_14.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		label_14.setBounds(272, 266, 96, 14);
		panel_1.add(label_14);
		
		JLabel label_15 = new JLabel("Chemistry:");
		label_15.setForeground(Color.WHITE);
		label_15.setFont(new Font("SimSun-ExtB", Font.BOLD, 14));
		label_15.setBounds(272, 320, 96, 14);
		panel_1.add(label_15);
		
		
		
		rollnotxt = new JTextField();
		rollnotxt.setColumns(10);
		rollnotxt.setBounds(291, 146, 173, 31);
		panel_1.add(rollnotxt);
		
		JLabel label_17 = new JLabel("Student Roll#");
		label_17.setForeground(Color.WHITE);
		label_17.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_17.setBounds(20, 154, 139, 14);
		panel_1.add(label_17);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(20, 192, 458, 8);
		panel_1.add(separator);
		
		JButton btnInsert = new JButton("Insert");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (grp_comboBox_2.getSelectedIndex()==-1){
					JOptionPane.showMessageDialog(null, "Please select the group!!");
				}
				else
				{
				if(grp_comboBox_2.getSelectedIndex()==0)
				{
					String db="jdbc:mysql://127.0.0.1:3306/exams";
					String user="root";
					String pass=""; 
					try {
						Connection conn=DriverManager.getConnection(db, user, pass);
						Statement stmt =conn.createStatement();
						String query="insert into "+term_comboBox.getSelectedItem().toString()+" values('"+rollnotxt.getText()+"','"+id_comboBox_1.getSelectedItem().toString()+"','"+e_textField.getText()+"','"+u_textField_1.getText()+"','"+i_textField_2.getText()+"','"+p_textField.getText()+"','"+ph_textField_1.getText()+"','"+c_textField_2.getText()+"','"+b3_textField_3.getText()+"','') ";
						if (stmt.executeUpdate(query) >0 )
						JOptionPane.showMessageDialog(null, "Marks inserted successfully!!");
					} catch (SQLException e) {
						
						// TODO Auto-generated catch block
						 //e.printStackTrace();
						 JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);
					}
				}
				else
				{
					String db="jdbc:mysql://127.0.0.1:3306/exams";
					String user="root";
					String pass=""; 
					try {
						Connection conn=DriverManager.getConnection(db, user, pass);
						Statement stmt =conn.createStatement();
						String query="insert into "+term_comboBox.getSelectedItem().toString()+" values('"+rollnotxt.getText()+"','"+id_comboBox_1.getSelectedItem().toString()+"','"+e_textField.getText()+"','"+u_textField_1.getText()+"','"+i_textField_2.getText()+"','"+p_textField.getText()+"','"+ph_textField_1.getText()+"','"+c_textField_2.getText()+"','','"+m_textField_4.getText()+"') ";
						if (stmt.executeUpdate(query) >0 )
						JOptionPane.showMessageDialog(null, "Marks inserted successfully!!");
					} catch (SQLException e) {
						
						// TODO Auto-generated catch block
						 //e.printStackTrace();
						 JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);
					}
				}
				}
				
			}
		});
		btnInsert.setBounds(375, 480, 89, 33);
		panel_1.add(btnInsert);
	
		panel_1.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{grp_comboBox_2, id_comboBox_1, term_comboBox, rollnotxt, e_textField, u_textField_1, i_textField_2, p_textField, ph_textField_1, c_textField_2, b3_textField_3, m_textField_4, label_6, lblBio, label_7, label_8, label_9, label_10, label_11, label_12, label_13, label_14, label_15, label_17}));
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setFont(new Font("SimSun-ExtB", Font.BOLD, 12));
		panel_2.setBorder(new EmptyBorder(5, 5, 5, 5));
		panel_2.setBackground(new Color(0, 128, 128));
		tabbedPane.addTab("Result", null, panel_2, null);
		
		e1_textField = new JTextField();
		e1_textField.setEditable(false);
		e1_textField.setColumns(10);
		e1_textField.setBounds(142, 182, 92, 24);
		panel_2.add(e1_textField);
		
		e2_textField_1 = new JTextField();
		e2_textField_1.setEditable(false);
		e2_textField_1.setColumns(10);
		e2_textField_1.setBounds(255, 182, 92, 24);
		panel_2.add(e2_textField_1);
		
		u1_textField_2 = new JTextField();
		u1_textField_2.setEditable(false);
		u1_textField_2.setColumns(10);
		u1_textField_2.setBounds(142, 224, 92, 24);
		panel_2.add(u1_textField_2);
		
		u2_textField_3 = new JTextField();
		u2_textField_3.setEditable(false);
		u2_textField_3.setColumns(10);
		u2_textField_3.setBounds(255, 224, 92, 24);
		panel_2.add(u2_textField_3);
		
		i1_textField_4 = new JTextField();
		i1_textField_4.setEditable(false);
		i1_textField_4.setColumns(10);
		i1_textField_4.setBounds(142, 269, 92, 24);
		panel_2.add(i1_textField_4);
		
		i2_textField_5 = new JTextField();
		i2_textField_5.setEditable(false);
		i2_textField_5.setColumns(10);
		i2_textField_5.setBounds(255, 266, 92, 27);
		panel_2.add(i2_textField_5);
		
		p1_textField_6 = new JTextField();
		p1_textField_6.setEditable(false);
		p1_textField_6.setColumns(10);
		p1_textField_6.setBounds(142, 308, 92, 24);
		panel_2.add(p1_textField_6);
		
		p2_textField_7 = new JTextField();
		p2_textField_7.setEditable(false);
		p2_textField_7.setColumns(10);
		p2_textField_7.setBounds(255, 308, 92, 24);
		panel_2.add(p2_textField_7);
		
		ph1_textField_8 = new JTextField();
		ph1_textField_8.setEditable(false);
		ph1_textField_8.setColumns(10);
		ph1_textField_8.setBounds(142, 350, 92, 24);
		panel_2.add(ph1_textField_8);
		
		ph2_textField_9 = new JTextField();
		ph2_textField_9.setEditable(false);
		ph2_textField_9.setColumns(10);
		ph2_textField_9.setBounds(255, 350, 92, 24);
		panel_2.add(ph2_textField_9);
		
		c1_textField_10 = new JTextField();
		c1_textField_10.setEditable(false);
		c1_textField_10.setColumns(10);
		c1_textField_10.setBounds(142, 392, 92, 24);
		panel_2.add(c1_textField_10);
		
		c2_textField_11 = new JTextField();
		c2_textField_11.setEditable(false);
		c2_textField_11.setColumns(10);
		c2_textField_11.setBounds(255, 392, 92, 24);
		panel_2.add(c2_textField_11);
		
		b1_textField_12 = new JTextField();
		b1_textField_12.setEditable(false);
		b1_textField_12.setColumns(10);
		b1_textField_12.setBounds(142, 434, 92, 24);
		panel_2.add(b1_textField_12);
		
		b2_textField_13 = new JTextField();
		b2_textField_13.setEditable(false);
		b2_textField_13.setColumns(10);
		b2_textField_13.setBounds(255, 434, 92, 24);
		panel_2.add(b2_textField_13);
		
		m1_textField_14 = new JTextField();
		m1_textField_14.setEditable(false);
		m1_textField_14.setColumns(10);
		m1_textField_14.setBounds(142, 434, 92, 24);
		panel_2.add(m1_textField_14);
		
		m2_textField_15 = new JTextField();
		m2_textField_15.setEditable(false);
		m2_textField_15.setColumns(10);
		m2_textField_15.setBounds(255, 434, 92, 24);
		panel_2.add(m2_textField_15);
		
		name_textField_16 = new JTextField();
		name_textField_16.setEditable(false);
		name_textField_16.setColumns(10);
		name_textField_16.setBounds(142, 55, 320, 24);
		panel_2.add(name_textField_16);
		
		f_nametextField_17 = new JTextField();
		f_nametextField_17.setEditable(false);
		f_nametextField_17.setColumns(10);
		f_nametextField_17.setBounds(142, 90, 320, 24);
		panel_2.add(f_nametextField_17);
		
		et_textField = new JTextField();
		et_textField.setEditable(false);
		et_textField.setColumns(10);
		et_textField.setBounds(370, 182, 92, 24);
		panel_2.add(et_textField);
		
		ut_textField_1 = new JTextField();
		ut_textField_1.setEditable(false);
		ut_textField_1.setColumns(10);
		ut_textField_1.setBounds(370, 224, 92, 24);
		panel_2.add(ut_textField_1);
		
		it_textField_2 = new JTextField();
		it_textField_2.setEditable(false);
		it_textField_2.setColumns(10);
		it_textField_2.setBounds(370, 266, 92, 24);
		panel_2.add(it_textField_2);
		
		pt_textField_3 = new JTextField();
		pt_textField_3.setEditable(false);
		pt_textField_3.setColumns(10);
		pt_textField_3.setBounds(370, 308, 92, 24);
		panel_2.add(pt_textField_3);
		
		pht_textField_4 = new JTextField();
		pht_textField_4.setEditable(false);
		pht_textField_4.setColumns(10);
		pht_textField_4.setBounds(370, 350, 92, 24);
		panel_2.add(pht_textField_4);
		
		c_textField_5 = new JTextField();
		c_textField_5.setEditable(false);
		c_textField_5.setColumns(10);
		c_textField_5.setBounds(370, 392, 92, 24);
		panel_2.add(c_textField_5);
		
		bt_textField_6 = new JTextField();
		bt_textField_6.setEditable(false);
		bt_textField_6.setColumns(10);
		bt_textField_6.setBounds(370, 434, 92, 24);
		panel_2.add(bt_textField_6);
		
		mt_textField_7 = new JTextField();
		mt_textField_7.setEditable(false);
		mt_textField_7.setColumns(10);
		mt_textField_7.setBounds(370, 434, 92, 24);
		panel_2.add(mt_textField_7);
		
		textField_6 = new JTextField();
		textField_6.setEditable(false);
		textField_6.setBounds(370, 472, 92, 24);
		panel_2.add(textField_6);
		textField_6.setColumns(10);
		
		JComboBox slct_comboBox = new JComboBox();
		slct_comboBox.setBounds(255, 11, 207, 33);
		panel_2.add(slct_comboBox);
		slct_comboBox.addItem("Medical");
		slct_comboBox.addItem("Engineering");
		slct_comboBox.setSelectedIndex(-1);
		
		JButton button_3 = new JButton("show result");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(slct_comboBox.getSelectedIndex()==-1){
					JOptionPane.showMessageDialog(null, "Please Select the class_id");
				}
				else
				{
				try{
				code ram=new code();
				String ab;
				ab=(JOptionPane.showInputDialog("Enter Roll Number: "));
				ram.f_select(ab);
				ram.s_select(ab);
				
					int b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,s,t,u,v,w,x,y,z,total;
					if(slct_comboBox.getSelectedIndex()==0){
						ram.f_select(ab);
						ram.s_select(ab);
					b=Integer.parseInt(e1_textField.getText());
					c=Integer.parseInt(e2_textField_1.getText());
					d=b+c;
					et_textField.setText(String.valueOf(d));
					
					e=Integer.parseInt(u1_textField_2.getText());
					f=Integer.parseInt(u2_textField_3.getText());
					g=e+f;
					ut_textField_1.setText(String.valueOf(g));
					
					h=Integer.parseInt(i1_textField_4.getText());
					i=Integer.parseInt(i2_textField_5.getText());
					j=h+i;
					it_textField_2.setText(String.valueOf(j));
					
					k=Integer.parseInt(p1_textField_6.getText());
					l=Integer.parseInt(p2_textField_7.getText());
					m=k+l;
					pt_textField_3.setText(String.valueOf(m));
					
					n=Integer.parseInt(ph1_textField_8.getText());
					o=Integer.parseInt(ph2_textField_9.getText());
					p=n+o;
					pht_textField_4.setText(String.valueOf(p));
					
					q=Integer.parseInt(c1_textField_10.getText());
					s=Integer.parseInt(c2_textField_11.getText());
					t=q+s;
					c_textField_5.setText(String.valueOf(t));
					
					u=Integer.parseInt(b1_textField_12.getText());
					v=Integer.parseInt(b2_textField_13.getText());
					w=u+v;
					bt_textField_6.setText(String.valueOf(w));
					
					total=d+g+j+m+p+t+w;
					textField_6.setText(String.valueOf(total));
				
					}
					else
					{
						ram.f_select(ab);
						ram.s_select(ab);
					b=Integer.parseInt(e1_textField.getText());
					c=Integer.parseInt(e2_textField_1.getText());
					d=b+c;
					et_textField.setText(String.valueOf(d));
					
					e=Integer.parseInt(u1_textField_2.getText());
					f=Integer.parseInt(u2_textField_3.getText());
					g=e+f;
					ut_textField_1.setText(String.valueOf(g));
					
					h=Integer.parseInt(i1_textField_4.getText());
					i=Integer.parseInt(i2_textField_5.getText());
					j=h+i;
					it_textField_2.setText(String.valueOf(j));
					
					k=Integer.parseInt(p1_textField_6.getText());
					l=Integer.parseInt(p2_textField_7.getText());
					m=k+l;
					pt_textField_3.setText(String.valueOf(m));
					
					n=Integer.parseInt(ph1_textField_8.getText());
					o=Integer.parseInt(ph2_textField_9.getText());
					p=n+o;
					pht_textField_4.setText(String.valueOf(p));
					
					q=Integer.parseInt(c1_textField_10.getText());
					s=Integer.parseInt(c2_textField_11.getText());
					t=q+s;
					c_textField_5.setText(String.valueOf(t));
					
					
					
					x=Integer.parseInt(m1_textField_14.getText());
					y=Integer.parseInt(m2_textField_15.getText());
					z=x+y;
					mt_textField_7.setText(String.valueOf(z));
					
					total=d+g+j+m+p+t+z;
					textField_6.setText(String.valueOf(total));
					
					
					
					}
					
				}
				catch(Exception error){
					JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + error.getMessage().toString() +" ", error.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);	
				}
			}
			}
		});
		button_3.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		button_3.setBounds(444, 507, 131, 27);
		panel_2.add(button_3);
		
		JLabel label_18 = new JLabel("English");
		label_18.setForeground(Color.WHITE);
		label_18.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_18.setBounds(23, 182, 131, 24);
		panel_2.add(label_18);
		
		JLabel label_19 = new JLabel("Urdu");
		label_19.setForeground(Color.WHITE);
		label_19.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_19.setBounds(23, 227, 145, 24);
		panel_2.add(label_19);
		
		JLabel label_20 = new JLabel("Islamiyat");
		label_20.setForeground(Color.WHITE);
		label_20.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_20.setBounds(23, 266, 145, 31);
		panel_2.add(label_20);
		
		JLabel label_21 = new JLabel("Pak Study");
		label_21.setForeground(Color.WHITE);
		label_21.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_21.setBounds(23, 311, 135, 24);
		panel_2.add(label_21);
		
		JLabel label_22 = new JLabel("Physics");
		label_22.setForeground(Color.WHITE);
		label_22.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_22.setBounds(23, 350, 131, 31);
		panel_2.add(label_22);
		
		JLabel label_23 = new JLabel("Chemistry");
		label_23.setForeground(Color.WHITE);
		label_23.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_23.setBounds(23, 392, 145, 31);
		panel_2.add(label_23);
		
		JLabel label_24 = new JLabel("");
		label_24.setForeground(Color.WHITE);
		label_24.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_24.setBounds(23, 437, 145, 24);
		panel_2.add(label_24);
		
		
		
		
		slct_comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(slct_comboBox.getSelectedIndex()==0)
				{ 
					m1_textField_14.hide();
					m2_textField_15.hide();
					mt_textField_7.hide();
					b1_textField_12.show();
					b2_textField_13.show();
					bt_textField_6.show();
					label_24.setText("Biology");
				}
				else
				{
					b1_textField_12.hide();
					b2_textField_13.hide();
					bt_textField_6.hide();
					m1_textField_14.show();
					m2_textField_15.show();
					mt_textField_7.show();
					label_24.setText("Mathematics");
				}
				
			}
		});
		
		
		JLabel label_25 = new JLabel("Student Name:");
		label_25.setForeground(Color.WHITE);
		label_25.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_25.setBounds(23, 60, 109, 14);
		panel_2.add(label_25);
		
		JLabel label_26 = new JLabel("Father Name:");
		label_26.setForeground(Color.WHITE);
		label_26.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_26.setBounds(23, 95, 109, 14);
		panel_2.add(label_26);
		
		JLabel label_27 = new JLabel("First Term");
		label_27.setForeground(Color.WHITE);
		label_27.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_27.setBounds(143, 157, 91, 14);
		panel_2.add(label_27);
		
		JLabel label_28 = new JLabel("Second Term");
		label_28.setForeground(Color.WHITE);
		label_28.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_28.setBounds(255, 157, 92, 14);
		panel_2.add(label_28);
		
		JLabel label_29 = new JLabel("Total");
		label_29.setForeground(Color.WHITE);
		label_29.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		label_29.setBounds(366, 157, 46, 14);
		panel_2.add(label_29);
		
		JLabel lblSelectTheGroup = new JLabel("Select the Group:");
		lblSelectTheGroup.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblSelectTheGroup.setForeground(new Color(255, 255, 255));
		lblSelectTheGroup.setBounds(23, 20, 145, 14);
		panel_2.add(lblSelectTheGroup);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setForeground(new Color(255, 255, 255));
		lblTotal.setFont(new Font("SimSun-ExtB", Font.BOLD, 13));
		lblTotal.setBounds(260, 476, 87, 14);
		panel_2.add(lblTotal);
		
		textField_7 = new JTextField();
		textField_7.setEditable(false);
		textField_7.setText("1400");
		textField_7.setBounds(472, 472, 92, 24);
		panel_2.add(textField_7);
		textField_7.setColumns(10);
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBorder(new EmptyBorder(5, 5, 5, 5));
		panel_3.setBackground(new Color(0, 128, 128));
		tabbedPane.addTab("Add Users", null, panel_3, null);
		
		JLabel label_30 = new JLabel("");
		Image i= new ImageIcon(this.getClass().getResource("/image.png")).getImage();
		label_30.setIcon(new ImageIcon(i));
		label_30.setBounds(10, 52, 146, 241);
		panel_3.add(label_30);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(316, 110, 193, 30);
		panel_3.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(316, 162, 193, 30);
		panel_3.add(textField_5);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(316, 212, 193, 30);
		panel_3.add(passwordField);
		
		JLabel label_31 = new JLabel("Add Users");
		label_31.setForeground(Color.WHITE);
		label_31.setFont(new Font("Candara", Font.BOLD | Font.ITALIC, 40));
		label_31.setBounds(85, 32, 320, 51);
		panel_3.add(label_31);
		
		JLabel label_32 = new JLabel("Full Name");
		label_32.setHorizontalAlignment(SwingConstants.LEFT);
		label_32.setForeground(Color.WHITE);
		label_32.setFont(new Font("Candara", Font.BOLD | Font.ITALIC, 16));
		label_32.setBounds(220, 116, 79, 18);
		panel_3.add(label_32);
		
		JLabel label_33 = new JLabel("UserName");
		label_33.setHorizontalTextPosition(SwingConstants.LEFT);
		label_33.setHorizontalAlignment(SwingConstants.LEFT);
		label_33.setForeground(Color.WHITE);
		label_33.setFont(new Font("Candara", Font.BOLD | Font.ITALIC, 16));
		label_33.setBounds(220, 170, 86, 14);
		panel_3.add(label_33);
		
		JLabel label_34 = new JLabel("Password");
		label_34.setHorizontalTextPosition(SwingConstants.LEFT);
		label_34.setHorizontalAlignment(SwingConstants.LEFT);
		label_34.setForeground(Color.WHITE);
		label_34.setFont(new Font("Candara", Font.BOLD | Font.ITALIC, 16));
		label_34.setBounds(220, 220, 103, 14);
		panel_3.add(label_34);
		
		JButton button_4 = new JButton("");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				code l=new code();
				l.insert_user(textField_4.getText(), textField_5.getText(), passwordField.getText());
			}
		});
		Image p= new ImageIcon(this.getClass().getResource("/add2.png")).getImage();
		button_4.setIcon(new ImageIcon(p));
		button_4.setBounds(363, 284, 79, 57);
		panel_3.add(button_4);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(5, 0, 150, 127);
		lblNewLabel.setVerticalTextPosition(SwingConstants.BOTTOM);
		lblNewLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Snap ITC", Font.BOLD | Font.ITALIC, 37));
		contentPane.add(lblNewLabel);
		Image pi= new ImageIcon(this.getClass().getResource("/clg.jpg")).getImage();
		lblNewLabel.setIcon(new ImageIcon(pi));
		
		JLabel lblExaminationSystem = new JLabel("Examination System");
		lblExaminationSystem.setFont(new Font("Snap ITC", Font.ITALIC, 40));
		lblExaminationSystem.setForeground(Color.WHITE);
		lblExaminationSystem.setBounds(158, 58, 495, 69);
		contentPane.add(lblExaminationSystem);
		
		
	}
}
