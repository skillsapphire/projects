package Exams;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class add_user extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JPasswordField passwordField;
	private JLabel lblAddUsers;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					add_user frame = new add_user();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public add_user() {
		setResizable(false);
		setBackground(new Color(220, 20, 60));
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\ramis\\Downloads\\Documents\\new.png"));
		setTitle("Add Users");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 564, 394);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(70, 130, 180));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		Image pic= new ImageIcon(this.getClass().getResource("/back.jpg")).getImage();
		
		JLabel lblNewLabel_1 = new JLabel("");
		Image pics= new ImageIcon(this.getClass().getResource("/image.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(pics));
		lblNewLabel_1.setBounds(10, 52, 146, 241);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(316, 110, 193, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(316, 162, 193, 30);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(316, 212, 193, 30);
		contentPane.add(passwordField);
		
		lblAddUsers = new JLabel("Add Users");
		lblAddUsers.setFont(new Font("Candara", Font.BOLD | Font.ITALIC, 40));
		lblAddUsers.setForeground(new Color(255, 255, 255));
		lblAddUsers.setBounds(85, 32, 320, 51);
		contentPane.add(lblAddUsers);
		
		lblNewLabel = new JLabel("Full Name");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Candara", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel.setBounds(214, 116, 79, 18);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_2 = new JLabel("UserName");
		lblNewLabel_2.setHorizontalTextPosition(SwingConstants.LEFT);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Candara", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel_2.setBounds(207, 170, 86, 14);
		contentPane.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("Password");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setFont(new Font("Candara", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_3.setHorizontalTextPosition(SwingConstants.LEFT);
		lblNewLabel_3.setBounds(203, 220, 103, 14);
		contentPane.add(lblNewLabel_3);
		
		JButton btnAdd = new JButton("");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				code l=new code();
				l.insert_user(textField.getText(), textField_1.getText(), passwordField.getText());
			}
		});
		Image p= new ImageIcon(this.getClass().getResource("/add2.png")).getImage();
		btnAdd.setIcon(new ImageIcon(p));
		btnAdd.setBounds(363, 284, 79, 57);
		contentPane.add(btnAdd);
		
	}
}
