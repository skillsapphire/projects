package Exams;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.mysql.jdbc.PreparedStatement;

import net.proteanit.sql.DbUtils;




public class code {
	public static Object frame;
	void login_user (String name, String pass)
	{
		try 
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/exams", "root", "");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from login where username= '"+name+"'and password='"+pass+"'");
			if(rs.next())
			{
				JOptionPane.showMessageDialog(null, "Login Successful");
			}
		else
		JOptionPane.showMessageDialog(null, "Invalid username/password");
		} catch (SQLException e){
		
		JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);
		}
	}
	void insert_user(String name, String username, String pass1)
	{
		String db="jdbc:mysql://127.0.0.1:3306/exams";
		String user="root";
		String pass=""; 
		try {
			Connection conn=DriverManager.getConnection(db, user, pass);
			Statement stmt =conn.createStatement();
			String query="insert into login values('"+name+"','"+username+"','"+pass1+"')";
			if (stmt.executeUpdate(query) >0 )
			JOptionPane.showMessageDialog(null, "New User added successfully!!");
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);
		}
		System.out.println("Connection Created");
	}
	void delete(String s){

		String db="jdbc:mysql://127.0.0.1:3306/exams";
		String user="root";
		String pass="";
		try{
			Connection conn=DriverManager.getConnection(db, user, pass);
			Statement stmt =conn.createStatement();
			String query="delete from login where username='"+s+"'";
			if (stmt.executeUpdate(query) >0 )
			JOptionPane.showMessageDialog(null, "User deleted successfully!!");
		}
		catch(SQLException e){
			JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);
		}
	}
	void del_std(String s){
		String db="jdbc:mysql://127.0.0.1:3306/exams";
		String user="root";
		String pass="";


		try{
			Connection conn=DriverManager.getConnection(db, user, pass);
			Statement stmt =conn.createStatement();
			String query="delete from student where roll_no='"+s+"'";
			if (stmt.executeUpdate(query) >0 )
			JOptionPane.showMessageDialog(null, "Record deleted successfully!!");
		}
		catch(SQLException e){
			JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);
		}
	}

	void f_select(String roll){
		String db="jdbc:mysql://127.0.0.1:3306/exams";
		String user="root";
		String pass=""; 
		try {
			Connection conn=DriverManager.getConnection(db, user, pass);
			Statement stmt =conn.createStatement();
			String query="SELECT student.s_name, student.f_name, first_term.English, first_term.Urdu, first_term.Islamiyat, first_term.Pakistan_Studies, first_term.Physics, first_term.Chemistry, first_term.Biology,first_term.Mathematics FROM student, first_term WHERE student.roll_no = first_term.roll_no AND student.roll_no ="+roll+"";
			ResultSet rs=stmt.executeQuery(query);
			//practice.table.setModel(DbUtils.resultSetToTableModel(rs));
			if(rs.next()){
			menu.name_textField_16.setText(rs.getString("student.s_name"));
			menu.f_nametextField_17.setText(rs.getString("student.f_name"));
			menu.e1_textField.setText(rs.getString("first_term.English"));
			menu.u1_textField_2.setText(rs.getString("first_term.Urdu"));	
			menu.i1_textField_4.setText(rs.getString("first_term.Islamiyat"));	
			menu.p1_textField_6.setText(rs.getString("first_term.Pakistan_Studies"));
			menu.ph1_textField_8.setText(rs.getString("first_term.Physics"));
			menu.c1_textField_10.setText(rs.getString("first_term.Chemistry"));
			menu.b1_textField_12.setText(rs.getString("first_term.Biology"));	
			menu.m1_textField_14.setText(rs.getString("Mathematics"));	
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Record Not Found!!", "Not found", JOptionPane.INFORMATION_MESSAGE);
			}
			
		} catch (SQLException e) {
			
			e.getMessage();
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +"Warning ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);
		}
	}
	void insert_std(String roll,String name, String fname, String class_id,String d,String m, String y)
	{
		String db="jdbc:mysql://127.0.0.1:3306/exams";
		String user="root";
		String pass=""; 
		try {
			Connection conn=DriverManager.getConnection(db, user, pass);
			Statement stmt =conn.createStatement();
			String query="insert into student values('"+roll+"','"+name+"','"+fname+"','"+class_id+"','"+d+"/"+m+"/"+y+"')";
			//stmt.executeUpdate(query);
			if (stmt.executeUpdate(query) >0 )
			JOptionPane.showMessageDialog(null, "Student added successfully!!");
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			 //e.printStackTrace();
			 JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);
		}
	}
	void delete_std(String d){

		String db="jdbc:mysql://127.0.0.1:3306/exams";
		String user="root";
		String pass="";
		try{
			Connection conn=DriverManager.getConnection(db, user, pass);
			Statement stmt =conn.createStatement();
			String query="delete from student where s_name='"+d+"'";
			stmt.executeUpdate(query);
			JOptionPane.showMessageDialog(null, "User deleted successfully!!");
		}
		catch(SQLException e){
			JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);
		}
	}
	void s_select(String roll){
		String db="jdbc:mysql://127.0.0.1:3306/exams";
		String user="root";
		String pass=""; 
		try {
			Connection conn=DriverManager.getConnection(db, user, pass);
			Statement stmt =conn.createStatement();
			String query="SELECT second_term.English, second_term.Urdu, second_term.Islamiyat, second_term.Pakistan_Studies, second_term.Physics, second_term.Chemistry, second_term.Biology,second_term.Mathematics FROM student, second_term WHERE student.roll_no = second_term.roll_no AND student.roll_no ="+roll+"";
			ResultSet rs=stmt.executeQuery(query);
			if(rs.next()){
			menu.e2_textField_1.setText(rs.getString("English"));
			menu.u2_textField_3.setText(rs.getString("Urdu"));		
			menu.i2_textField_5.setText(rs.getString("Islamiyat"));	
			menu.p2_textField_7.setText(rs.getString("Pakistan_Studies"));
			menu.ph2_textField_9.setText(rs.getString("Physics"));
			menu.c2_textField_11.setText(rs.getString("Chemistry"));
			menu.b2_textField_13.setText(rs.getString("Biology"));	
			menu.m2_textField_15.setText(rs.getString("Mathematics"));	
			//practice.table.setModel(DbUtils.resultSetToTableModel(rs));
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Record Not Found!!", "Not found", JOptionPane.INFORMATION_MESSAGE);
			}
			
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);
		
		}
	}
	void update_std(String roll, String name,String fname, String class_id,String d,String m,String y)
	{
		String db="jdbc:mysql://127.0.0.1:3306/exams";
		String user="root";
		String pass=""; 
		try {
			Connection conn=DriverManager.getConnection(db, user, pass);
			Statement stmt =conn.createStatement();
			String query="update student SET roll_no= '"+roll+"', s_name='"+name+"', f_name= '"+fname+"', class_id='"+class_id+"', DOB='"+d+"/"+m+"/"+y+"' where roll_no="+roll;
			if (stmt.executeUpdate(query) >0 )
			JOptionPane.showMessageDialog(null, "Record Updated");
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);
		}
	}
	void select_class_id(){
		try 
		{
			menu.comboBox_1_id.removeAllItems();
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/exams", "root", "");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select class_id from class");
			while (rs.next())
			{
				menu.comboBox_1_id.addItem(rs.getString(1));
			}
		}
		catch (SQLException e){
			JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);	
		}
	}
	void show_classm(String id){
		try 
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/exams", "root", "");
			Statement stmt = con.createStatement();
			String query=("SELECT student.roll_no as 'Roll#', student.s_name as 'Name', "+show_class.terms_comboBox_1.getSelectedItem().toString()+".English, "+show_class.terms_comboBox_1.getSelectedItem().toString()+".Urdu, "+show_class.terms_comboBox_1.getSelectedItem().toString()+".Islamiyat, "+show_class.terms_comboBox_1.getSelectedItem().toString()+".Pakistan_Studies, "+show_class.terms_comboBox_1.getSelectedItem().toString()+".Physics, "+show_class.terms_comboBox_1.getSelectedItem().toString()+".Chemistry, "+show_class.terms_comboBox_1.getSelectedItem().toString()+".Biology FROM student, "+show_class.terms_comboBox_1.getSelectedItem().toString()+" WHERE student.roll_no = "+show_class.terms_comboBox_1.getSelectedItem().toString()+".roll_no AND "+show_class.terms_comboBox_1.getSelectedItem().toString()+".class_id = '"+id+"'");
			
			ResultSet rs = stmt.executeQuery(query);
			//rs.next();
			show_class.table.setModel(DbUtils.resultSetToTableModel(rs));
			
		}
		catch (SQLException e){
			JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);	
		}
		
	}
	void show_classe(String id){
		try 
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/exams", "root", "");
			Statement stmt = con.createStatement();
			String query=("SELECT student.roll_no as 'Roll#', student.s_name as 'Name', "+show_class.terms_comboBox_1.getSelectedItem().toString()+".English, "+show_class.terms_comboBox_1.getSelectedItem().toString()+".Urdu, "+show_class.terms_comboBox_1.getSelectedItem().toString()+".Islamiyat, "+show_class.terms_comboBox_1.getSelectedItem().toString()+".Pakistan_Studies, "+show_class.terms_comboBox_1.getSelectedItem().toString()+".Physics, "+show_class.terms_comboBox_1.getSelectedItem().toString()+".Chemistry, "+show_class.terms_comboBox_1.getSelectedItem().toString()+".Mathematics FROM student, "+show_class.terms_comboBox_1.getSelectedItem().toString()+" WHERE student.roll_no = "+show_class.terms_comboBox_1.getSelectedItem().toString()+".roll_no AND "+show_class.terms_comboBox_1.getSelectedItem().toString()+".class_id = '"+id+"'");
			ResultSet rs = stmt.executeQuery(query);
			//rs.next();
			show_class.table.setModel(DbUtils.resultSetToTableModel(rs));
			
		}
		catch (SQLException e){
			JOptionPane.showMessageDialog(null,"An unexpected error has occurred:\n" + e.getMessage().toString() +" ", e.getStackTrace().toString(), JOptionPane.ERROR_MESSAGE, null);	
		}
	}

	
}
	
