-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2017 at 06:27 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mahnoor`
--

-- --------------------------------------------------------

--
-- Table structure for table `information`
--

CREATE TABLE IF NOT EXISTS `information` (
  `con_no` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `cnic` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `desig` varchar(255) NOT NULL,
  `salry` varchar(255) NOT NULL,
  `accno` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `information`
--

INSERT INTO `information` (`con_no`, `name`, `cnic`, `address`, `email`, `company`, `number`, `desig`, `salry`, `accno`) VALUES
('', '', '', '', '', '', '', '', '', ''),
('00', 'nhklk', 'klnkln', 'lkn', 'lknlk', 'nlk', 'null', '', '', ''),
('22', 'toshiba', 'red', '2gb', '512mb', '4', 'null', '', '', ''),
('adj', 'dskfj', 'sfj', 'sdjf', 'sdj', 'sjk', 'null', '', '', ''),
('sdfi', 'iew', 'ksdj', 'skdj', 'sdkfj', 'sdkfj', 'sdkfj', 'sdfk', 'sdji', 'eir'),
('sdj', 'sdji', 'sdi', 'iwej', 'di', 'sdij', 'iwe', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `information`
--
ALTER TABLE `information`
  ADD PRIMARY KEY (`con_no`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
