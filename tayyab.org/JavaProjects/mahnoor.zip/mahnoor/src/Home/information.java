package Home;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class information {
	void insert(String con_no, String name,String cnic,String address,String email,String company,String number,String desig, String salry, String accno)
	{
	
		String db = "jdbc:mysql://127.0.0.1:3306/mahnoor";
		String user = "root";
		String pass = "";
		
		try 
		{
			Connection con = DriverManager.getConnection(db, user, pass);
			Statement stmt = con.createStatement();
			
			String query = "insert into information values('"+con_no+"','"+name+"','"+cnic+"','"+address+"','"+email+"','"+company+"','"+number+"','"+desig+"','"+salry+"','"+accno+"')";
			
			stmt.executeUpdate(query);
			JOptionPane.showMessageDialog(null, "Record Inserted Sucessfully");
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "record already exist");
		}
		
		
		
	}

	public void insert(String text, String text2, String text3, String text4, String text5, String text6, String text7,
			String c) {
		// TODO Auto-generated method stub
		
	}
	


}
