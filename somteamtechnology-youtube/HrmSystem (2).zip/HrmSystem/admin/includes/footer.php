<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>@<a href="#">Mustafa</a></b>
    </div>
    <strong>Copyright &copy; 2018 HRM, Attendance and Payroll System </strong>
</footer>