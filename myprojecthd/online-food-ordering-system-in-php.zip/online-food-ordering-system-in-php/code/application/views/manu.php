<ul>
<li><b><?php echo anchor('Welcome/home','Home'); ?></b></li>
<li><b><?php echo anchor('Welcome/product','Product'); ?></b></li>
<li><b><?php echo anchor('Welcome/contect','Contect Us'); ?></b></li>
<li><a href="#"><b>Login</b></a></li>
</ul>