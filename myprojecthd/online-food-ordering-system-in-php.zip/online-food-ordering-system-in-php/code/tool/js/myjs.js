$('document').ready(function(){
	$('#btn').click(function(){
		$('#nav').stop().slideToggle();
	});
});