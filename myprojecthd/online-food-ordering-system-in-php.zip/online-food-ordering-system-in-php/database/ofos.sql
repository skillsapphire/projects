-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2018 at 04:26 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ofos`
--

-- --------------------------------------------------------

--
-- Table structure for table `a`
--

CREATE TABLE `a` (
  `id` int(11) NOT NULL,
  `un` varchar(50) DEFAULT NULL,
  `ps` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `a`
--

INSERT INTO `a` (`id`, `un`, `ps`) VALUES
(1, 'a', 'b'),
(2, 'c', 'd');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `un` varchar(50) DEFAULT NULL,
  `ps` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`un`, `ps`) VALUES
('admin', 'a123');

-- --------------------------------------------------------

--
-- Table structure for table `order_booking`
--

CREATE TABLE `order_booking` (
  `id` int(11) NOT NULL,
  `pname` varchar(50) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `cname` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mno` varchar(20) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_booking`
--

INSERT INTO `order_booking` (`id`, `pname`, `price`, `cname`, `email`, `mno`, `address`, `city`, `type`) VALUES
(1, 'ds', 'Rajput', 'Deependra', 'rajpuutds815@gmail.com', '96916268878', 'Ujjain', 'Ujjian', 'ofline'),
(2, 'ds', 'Rajput', 'Deependra', 'rajpuutds815@gmail.com', '96916268878', 'Ujjain', 'Ujjian', 'ofline'),
(3, 'ds', 'Rajput', 's', 's', 's', 's', 's', 'ofline'),
(4, 'ds', 'Rajput', 's', 's', 's', 's', 's', 'ofline'),
(5, 'ds', 'Rajput', 's', 's', 's', 's', 's', 'ofline'),
(6, 'ds', 'Rajput', 's', 's', 's', 's', 's', 'ofline'),
(7, 'ds', 'Rajput', 's', 's', 's', 's', 's', 'ofline'),
(8, 'ds', 'Rajput', 's', 's', 's', 's', 's', 'ofline'),
(9, 'ds', 'Rajput', 's', 's', 's', 's', 's', 'ofline'),
(10, 'ds', 'Rajput', 's', 's', 's', 's', 's', 'ofline'),
(11, 'ds', 'Rajput', 's', 's', 's', 's', 's', 'ofline'),
(12, 'ds', 'Rajput', 's', 's', 's', 's', 's', 'ofline'),
(13, 'q', 'q', 'e', 'e', 'e', 'e', 'e', 'ofline'),
(14, 'q', 'q', 'e', 'e', 'e', 'e', 'e', 'ofline'),
(15, 'q', 'q', 'd', 'd', 'd', 'd', 'd', 'ofline'),
(16, 'q', 'q', 'd', 'd', 'd', 'd', 'd', 'ofline'),
(17, 'q', 'q', 'd', 'd', 'd', 'd', 'd', 'ofline'),
(18, 'q', 'q', 'd', 'd', 'd', 'd', 'd', 'ofline'),
(19, 'q', 'q', 'd', 'd', 'd', 'd', 'd', 'ofline'),
(20, 'q', 'q', 'd', 'd', 'd', 'd', 'd', 'ofline'),
(21, 'q', 'q', 'd', 'd', 'd', 'd', 'd', 'ofline'),
(22, 'q', 'q', 'd', 'd', 'd', 'd', 'd', 'ofline'),
(23, 'q', 'q', 'd', 'd', 'd', 'd', 'd', 'ofline'),
(24, 'q', 'q', 'd', 'd', 'd', 'd', 'd', 'ofline'),
(25, 'q', 'q', 'd', 'd', 'd', 'd', 'd', 'online'),
(26, 'q', 'q', '', '', '', '', '', 'ofline'),
(27, 'q', 'q', 'Deepe', 'a@gmail.com', '9691626878', 'ujjain', 'ujjian', 'ofline'),
(28, 'q', 'q', 'Deepe', 'a@gmail.com', '9691626878', 'ujjain', 'ujjian', 'ofline'),
(29, 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'ofline'),
(30, 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'ofline'),
(31, 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'ofline'),
(32, 'ds', 'Rajput', 'r', 'r', 'r', 'r', 'r', 'ofline'),
(33, 'ds', 'Rajput', 's', 's', 's', 's', 's', 'ofline'),
(34, 'ds', 'Rajput', 'Deependra', 'rajpuutds815@gmail.com', '96916268878', 'Ujjain', 'Ujjian', 'online'),
(35, 'ds', 'Rajput', 'q', 'q', 'a', 'q', 'a', 'ofline');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `price`) VALUES
(1, 'q', 'q'),
(2, 'q', 'q'),
(3, 'q', 'q'),
(4, 'q', 'q'),
(5, 'ds', 'Rajput'),
(6, 'q', 'q'),
(7, 'q', 'q'),
(8, 'q', 'q'),
(9, 'q', 'q'),
(11, 'r', 'r'),
(12, 'q', 'q');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `a`
--
ALTER TABLE `a`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_booking`
--
ALTER TABLE `order_booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `a`
--
ALTER TABLE `a`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_booking`
--
ALTER TABLE `order_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
