<?php
class My_model extends CI_Model
{
	public function select_data($tbl_name,$field,$war='')
	{
		if($war!='')
		{
			$this->db->where($war);
		}
		$q=$this->db->select($field)->from($tbl_name)->get();
		return $q->result_array();
	}
}
?>