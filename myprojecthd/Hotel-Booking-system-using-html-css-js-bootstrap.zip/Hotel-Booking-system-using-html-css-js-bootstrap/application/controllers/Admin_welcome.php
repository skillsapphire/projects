<?php
class Admin_welcome extends CI_controller
{
	public function __construct()
	{
		
		parent::__construct();
		
		$this->load->helper('url');
		if(!$this->session->userdata('session'))
		{
			redirect('/admin');
		}
	}
	public function dashbord()
	{
		
		$this->load->view('admin/dashbord');
	}
	public function room_manage()
	{
		$this->load->view('admin/room_manage');	
	}
	public function contect()
	{
		$this->load->view('admin/contect');
	}
}
?>