<?php
class Home extends CI_controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(['url','form']);
	}
	public function index()
	{
		$this->load->view('home');	
	}
}
?>