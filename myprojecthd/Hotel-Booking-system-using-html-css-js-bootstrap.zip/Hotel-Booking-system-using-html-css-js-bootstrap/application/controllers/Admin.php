<?php
class Admin extends Ci_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
	}
	public function index()
	{
		$this->load->view('admin/login');
	}
	public function login()
	{
		$data=$this->input->post();
		$res=$this->my_model->select_data('admin','*',$data);
		if($res)
		{
			$this->session->set_userdata('session','1');
			echo "1";
		}
		else 
		{
			echo "0";
		}
	}
	public function dashbord()
	{
		if($this->session->userdata('session'))
		{
			
		}
		$this->load->view('admin/dashbord');
	}
	
}
?>