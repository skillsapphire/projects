<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="<?= base_url('tool/css/bootstrap.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('tool/css/style.css'); ?>">
	<script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
	<script type="text/javascript" src="<?= base_url('tool/js/bootstrap.js'); ?>"></script>


</head>
<body>
<div class="container-fluid">
	<div class="container" >
		<div class="col-sm-4" style="padding: 10px"><h3><font face="Courier New">Hotel Booking System</font></h3></div>
		<div class="col-sm-8" style="padding-top: 20px;">
			<ul class="homem">
			<li><a href="#">Home</a></li>
			<li><a href="#contect">Contect US</a></li>
			<li><a href="#galeary">Galeary</a></li>
			<li><a href="#restront">Restront</a></li>
			<li><a href="#room">Room</a></li>
			</ul>
		</div>
	</div>
	<div class="container">
	<img src="<?= base_url('tool/img1/banner.jpeg'); ?>" width="100%" height="400px">
	</div>
	<div class="container" id="contect">
	<h3 align="center">Contect</h3>
	<div class="col-sm-6" style="padding:30px;">
		<div class="form-group">
			<label>Enter Name</label>
			<input type="text" name="name" class="form-control" />
		</div>
		<div class="form-group">
			<label>Enter E-Mail</label>
			<input type="text" name="email" class="form-control" />
		</div>
		<div class="form-group">
			<label>Enter Mobile No</label>
			<input type="text" name="mno" class="form-control" />
		</div>
		<div class="form-group">
			<label>Enter Address</label>
			<input type="text" name="address" class="form-control" />
		</div>
		<div class="form-group">
			<input type="submit" name="sub" class="btn btn-primary"  value="Submit"  />
		</div>
	</div>
	<div class="col-sm-6">
		  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d58688.49379055593!2d75.7622007602501!3d23.16907368887748!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39637469de00ff23%3A0x7f82abdf7899d412!2sUjjain%2C+Madhya+Pradesh!5e0!3m2!1sen!2sin!4v1543136640250" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

		  
	</div>
	</div>
	
	<div class="container" id="galeary" style="padding:30px;">
	<div class="col-sm-3">
	<div class="container1">
	<img src="<?= base_url('tool/img1/g5.jpeg'); ?>" height="200px" width="250px" />
	<div class="overlay overleft"><div class="text"><font face="Courier" size="5">Restront</font></div></div>
	</div>
	</div>
	<div class="col-sm-3">
	<div class="container1">
	<img src="<?= base_url('tool/img1/g2.jpeg'); ?>" height="200px" width="250px" />
	<div class="overlay overleft"><div class="text"><font face="Courier" size="5">Pull</font></div></div>
	</div>
	</div>
	<div class="col-sm-3">
	<div class="container1">
	<img src="<?= base_url('tool/img1/g3.jpeg'); ?>" height="200px" width="250px"  />
	<div class="overlay overleft"><div class="text"><font face="Courier" size="5">Room</font></div></div>
	<p align="center"></p>
	</div>
	</div>
	<div class="col-sm-3">
	<div class="container1">
	<img src="<?= base_url('tool/img1/g4.jpeg'); ?>" height="200px" width="250px"  />
	<div class="overlay overleft"><div class="text"><font face="Courier" size="5">Food</font></div></div>
	</div>
	</div>
	</div>
	<div class="container" id="restront" style="background:url('<?= base_url('tool/img1/g8.jpeg'); ?>'); background-size:100% height:1000px;color:red;">
	<h3 align="center">Restront</h3>
	<div class="col-sm-6"></div>
	<div class="col-sm-6" style="padding:30px;">
		<div class="form-group">
			<label>Enter Name</label>
			<input type="text" name="name" class="form-control" />
		</div>
		<div class="form-group">
			<label>Enter E-Mail</label>
			<input type="text" name="email" class="form-control" />
		</div>
		<div class="form-group">
			<label>Enter Mobile No</label>
			<input type="text" name="mno" class="form-control" />
		</div>
		<div class="form-group">
			<label>Enter Address</label>
			<input type="text" name="address" class="form-control" />
		</div>
		<div class="form-group">
			<input type="submit" name="sub" class="btn btn-primary"  value="Submit"  />
		</div>
	</div>
	</div>
	<div class="container" id="room" style="padding:30px;">
	<div class="col-sm-3">
	<img src="<?= base_url('tool/img1/r1.jpeg'); ?>" class="img-responsive" />
	</div>
	<div class="col-sm-3">
	<img src="<?= base_url('tool/img1/r2.jpeg'); ?>" class="img-responsive" />
	</div>
	<div class="col-sm-3">
	<img src="<?= base_url('tool/img1/r3.jpeg'); ?>" class="img-responsive" />
	</div>
	<div class="col-sm-3">
	<img src="<?= base_url('tool/img1/r4.jpeg'); ?>" class="img-responsive" />
	</div>
	</div>
	<div class="container">
	<h4 align="center">copyright@myprojecthd</h4>
	</div>
</div>
</body>
</html>
