<!DOCTYPE html>
<html>
<head>
	<title>Admin - Login</title>
	<link rel="stylesheet" type="text/css" href="<?= base_url('tool/css/bootstrap.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('tool/css/style.css'); ?>">
	<script type="text/javascript" src="<?= base_url('tool/js/jquery-3.2.1.min.js')?>"></script>
	<script type="text/javascript" src="<?= base_url('tool/js/bootstrap.js'); ?>"></script>
	<script type="text/javascript" src="<?= base_url('tool/js/myjs.js')?>"></script>
</head>
<body>
<div class="container-fluid">
	<div class="container" >
		<div class="col-sm-4" style="padding: 10px"><h3><font face="Courier New">Hotel Booking System</font></h3></div>
		<div class="col-sm-8" style="padding-top: 20px;">
			
		</div>
	</div>
	<div class="container">
	<br><br><br><br><br><br>
	<div class="col-sm-4"></div>
	<div class="col-sm-4">
			<h2 align="center">Admin Login</h2>
			<div class="form-group">
				<label>Enter E-Mail</label>
				<input type="text" name="un" id="un" class="form-control" placeholder="Enter Username" />
			</div>
			<div class="form-group">
				<label>Enter Password</label>
				<input type="password" name="ps" id="ps" class="form-control" placeholder="Enter Password" />
			</div>
			<div class="form-group">
				<input type="submit" onclick="login();" class="btn btn-primary"  value="submit" />
			</div>
	</div>
	<div class="col-sm-4"></div><br><br>
	</div>
	<div class="container">
	<h4 align="center">copyright@myprojecthd</h4>
	</div>
</div>
</body>
</html>