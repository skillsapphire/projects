<!DOCTYPE html>
<html>
<head>
	<title>Admin - Home</title>
	<link rel="stylesheet" type="text/css" href="<?= base_url('tool/css/bootstrap.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('tool/css/style.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('tool/css/font-awesome.min.css'); ?>">
	<script type="text/javascript" src="<?= base_url('tool/js/jquery-3.2.1.min.js')?>"></script>
	<script type="text/javascript" src="<?= base_url('tool/js/bootstrap.js'); ?>"></script>
	<script type="text/javascript" src="<?= base_url('tool/js/myjs.js')?>"></script>
	<style type="text/css">
		i{ font-size: 20px; }
		td{text-align: center;}
	</style>
</head>
<body>
<div class="container-fluid">
	<div class="container" >
		<div class="col-sm-4" style="padding: 10px"><h3><font face="Courier New">Hotel Booking System</font></h3></div>
		<div class="col-sm-8" style="padding-top: 25px;">
			<div class="col-sm-8"></div>
			<div class="col-sm-1"><a href="<?= base_url('index.php/admin_welcome/dashbord'); ?>"><i title="Home" class="fa fa-home"></i></a></div>
			<div class="col-sm-1"><a href="<?= base_url('index.php/admin_welcome/room_manage'); ?>"><i title="Room Manage" class="fa fa-hotel"></i></a></div>
			<div class="col-sm-1"><a href="<?= base_url('index.php/admin_welcome/contect'); ?>"><i title="Contect" class="fa fa-envelope"></i></a></div>
			<div class="col-sm-1"><a href="<?= base_url('index.php/admin/'); ?>"><i title="Logout" class="fa fa-sign-out"></i></a></div>
		</div>
	</div>