<?php include('include/header.php'); ?>

  <div class="container">
  <div class="col-sm-3"><br><br><br>
  	 <ul class="nav">
	    <li class="active"><a data-toggle="tab" href="#home">Home</a></li><br>
	    <li><a data-toggle="tab" href="#room_list">Room List</a></li><br>
	    <li><a data-toggle="tab" href="#online_booking">Online Room Booking</a></li><br>
	    <li><a data-toggle="tab" href="#offline_booking">Offline Room Booking</a></li><br>
	    <li><a data-toggle="tab" href="#empty_room_list">Empty Room List</a></li><br>
	    <li><a data-toggle="tab" href="#online_billing">Online Billing</a></li><br>
	  </ul><br><br>
  </div><br><br>
  <div class="col-sm-7" style="border: 1px solid black">
  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      <h3 align="center">Room Manage</h3><br><br><br>
     <center> <img src="<?= base_url('tool/img/admin_home.jpeg'); ?>" width="350px" height="250px"></center>
    </div>
    <div id="room_list" class="tab-pane fade">
      <div class="col-sm-8"><h3>Room List</h3></div>
      <div class="col-sm-4" style="padding:20px;"><center><a data-toggle="modal" data-target="#room_add" class="btn btn-primary">Add Room</a></center></div>
      

      <br><br><br>
      <table class="table">
      	  <tr>
      	  	<td><font color="blue"><b>Room No</b></font></td>
      	  	<td><font color="blue"><b>Type</b></font></td>
      	  	<td><font color="blue"><b>Status</b></font></td>
      	  	<td><font color="blue"><b>Amount</b></font></td>
      	  </tr>
      	  <tr>
      	  	<td>101</td>
      	  	<td>AC</td>
      	  	<td>Unbook</td>
      	  	<td>1000</td>
      	  </tr>
      	  <tr>
      	  	<td>102</td>
      	  	<td>NoN - AC</td>
      	  	<td>book</td>
      	  	<td>1000</td>
      	  </tr>
      	  <tr>
      	  	<td>103</td>
      	  	<td>NoN-AC</td>
      	  	<td>Unbook</td>
      	  	<td>2000</td>
      	  </tr>
      </table>
    </div>
    <div id="online_booking" class="tab-pane fade">
      <h3>Online Booking Manage</h3>
     <br><br><br>
      <table class="table">
      	  <tr>
      	  	<td><font color="blue"><b>ID</b></font></td>
      	  	<td><font color="blue"><b>Name</b></font></td>
      	  	<td><font color="blue"><b>Address</b></font></td>
      	  	<td><font color="blue"><b>City</b></font></td>
      	  	<td><font color="blue"><b>Pay Status</b></font></td>
      	  	<td><font color="blue"><b>Status</b></font></td>
      	  </tr>
      	  <tr>
      	  	<td>1</td>
      	  	<td>Ds</td>
      	  	<td>Ujjain</td>
      	  	<td>Ujjain</td>
      	  	<td>Yes</td>
      	  	<td><select class="form-control" name="pay_status">
      	  		<option>UnAccept</option>
      	  		<option selected="selected">Accept</option>
      	  	</select>
      	  	</td>
      	  </tr>
      	  <tr>
      	  	<td>2</td>
      	  	<td>Test</td>
      	  	<td>Test Add</td>
      	  	<td>Test City</td>
      	  	<td>No</td>
      	  	<td><select class="form-control" name="pay_status">
      	  		<option>UnAccept</option>
      	  		<option >Accept</option>
      	  	</select>
      	  	</td>
      	  </tr>
      </table>
    </div>
    <div id="offline_booking" class="tab-pane fade">
    <div class="col-sm-8"><h3>Ofline Booking Manage</h3></div>
      <div class="col-sm-4" style="padding:20px;"><center><a data-toggle="modal" data-target="#book_new_room" class="btn btn-primary">Book New Room</a></center></div><br><br>
      <table class="table">
      	  <tr>
      	  	<td><font color="blue"><b>ID</b></font></td>
      	  	<td><font color="blue"><b>Name</b></font></td>
      	  	<td><font color="blue"><b>Address</b></font></td>
      	  	<td><font color="blue"><b>City</b></font></td>
      	  	<td><font color="blue"><b>Room No</b></font></td>
      	  	<td><font color="blue"><b>Pay Status</b></font></td>
      	  </tr>
      	  <tr>
      	  	<td>1</td>
      	  	<td>Ds</td>
      	  	<td>Ujjain</td>
      	  	<td>Ujjain</td>
      	  	<td>101</td>
      	  	<td>Yes</td>
      	  </tr>
      	  <tr>
      	  	<td>2</td>
      	  	<td>Test</td>
      	  	<td>Test Add</td>
      	  	<td>Test City</td>
      	  	<td>102</td>
      	  	<td>No</td>
      	  </tr>
      </table>
    </div>
    <div id="empty_room_list" class="tab-pane fade">
      <h3>Empty Room List</h3>
       <table class="table"><br><br>
      	  <tr>
      	  	<td><font color="blue"><b>Room No</b></font></td>
      	  	<td><font color="blue"><b>Type</b></font></td>
      	  	<td><font color="blue"><b>Status</b></font></td>
      	  	<td><font color="blue"><b>Amount</b></font></td>
      	  </tr>
      	  <tr>
      	  	<td>101</td>
      	  	<td>AC</td>
      	  	<td>Unbook</td>
      	  	<td>1000</td>
      	  </tr>
      	  <tr>
      	  	<td>103</td>
      	  	<td>NoN-AC</td>
      	  	<td>Unbook</td>
      	  	<td>2000</td>
      	  </tr>
      </table>
    </div>
    <div id="online_billing" class="tab-pane fade">
      <h3>Online Billing</h3><br><br><br>
      <table class="table">
      	  <tr>
      	  	<td><font color="blue"><b>ID</b></font></td>
      	  	<td><font color="blue"><b>Name</b></font></td>
      	  	<td><font color="blue"><b>Address</b></font></td>
      	  	<td><font color="blue"><b>City</b></font></td>
      	  	<td><font color="blue"><b>Room No</b></font></td>
      	  	<td><font color="blue"><b>Pay Status</b></font></td>
      	  </tr>
      	  <tr>
      	  	<td>1</td>
      	  	<td>Ds</td>
      	  	<td>Ujjain</td>
      	  	<td>Ujjain</td>
      	  	<td>101</td>
      	  	<td>Yes</td>
      	  </tr>
      	  <tr>
      	  	<td>2</td>
      	  	<td>Test</td>
      	  	<td>Test Add</td>
      	  	<td>Test City</td>
      	  	<td>102</td>
      	  	<td>Yes</td>
      	  </tr>
      </table>
    </div>
  </div><br><br><br><br><br>
  </div>
</div>
	<div class="container">
	<h4 align="center">copyright@myprojecthd</h4>
	</div>
</div>
</body>
</html>
<div id="room_add" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Room Add</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
        	<label>Enter Room No</label>
        	<input type="text" name="room_no" class="form-control" placeholder="Enter Room Number">
        </div>
        <div class="form-group">
        	<label>Enter Room Type</label>
        	<select class="form-control">
        		<option>Select</option>
        		<option>AC</option>
        		<option>NoN-AC</option>
        	</select>
        </div>
         <div class="form-group">
        	<label>Enter Room Price</label>
        	<input type="text" name="room_price" class="form-control" placeholder="Enter Room Price">
        </div>
        <div class="form-group">
        	<input type="submit" class="btn btn-primary" name="sub" value="Save" />
        </div>
      </div>
    </div>
  </div>
</div>

<div id="book_new_room" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Book New Room</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
        	<label>Enter Name</label>
        	<input type="text" name="room_no" class="form-control" placeholder="Enter Name">
        </div>
        <div class="form-group">
        	<label>Enter Address</label>
        	<input type="text" name="room_type" class="form-control" placeholder="Enter Address">
        </div>
         <div class="form-group">
        	<label>Enter City</label>
        	<select class="form-control">
        		<option>Select</option>
        		<option>AC</option>
        		<option>NoN-AC</option>
        	</select>
        </div>
        <div class="form-group">
        	<label>Room Type</label>
        	<input type="text" name="room_price" class="form-control" placeholder="Enter Room Type">
        </div>
        <div class="form-group">
        	<label>Pay Amount</label>
        	<input type="text" name="room_price" class="form-control" placeholder="Enter Pay Amount">
        </div>
        <div class="form-group">
        	<input type="submit" class="btn btn-primary" name="sub" value="Save" />
        </div>
      </div>
    </div>
  </div>
</div>