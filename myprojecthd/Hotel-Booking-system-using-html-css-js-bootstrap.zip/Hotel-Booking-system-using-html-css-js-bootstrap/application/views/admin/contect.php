<?php include('include/header.php'); ?>

  <div class="container">
	<h1>Contect</h1>  
	<table class="table">
		<tr>
			<td><font color="blue">Name</font></td>
			<td><font color="blue">E-Mail</font></td>
			<td><font color="blue">Mobile</font></td>
			<td><font color="blue">Address</font></td>
			<td><font color="blue">Commment</font></td>
		</tr>
		<tr>
			<td>Deependra</td>
			<td>engineersworld8@gmail.com</td>
			<td>8685585455</td>
			<td>Ujjain</td>
			<td>testing Comment</td>
		</tr>
	</table>
  </div>
	<div class="container">
	<h4 align="center">copyright@myprojecthd</h4>
	</div>
</div>
</body>
</html>
<div id="room_add" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Room Add</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
        	<label>Enter Room No</label>
        	<input type="text" name="room_no" class="form-control" placeholder="Enter Room Number">
        </div>
        <div class="form-group">
        	<label>Enter Room Type</label>
        	<select class="form-control">
        		<option>Select</option>
        		<option>AC</option>
        		<option>NoN-AC</option>
        	</select>
        </div>
         <div class="form-group">
        	<label>Enter Room Price</label>
        	<input type="text" name="room_price" class="form-control" placeholder="Enter Room Price">
        </div>
        <div class="form-group">
        	<input type="submit" class="btn btn-primary" name="sub" value="Save" />
        </div>
      </div>
    </div>
  </div>
</div>

<div id="book_new_room" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Book New Room</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
        	<label>Enter Name</label>
        	<input type="text" name="room_no" class="form-control" placeholder="Enter Name">
        </div>
        <div class="form-group">
        	<label>Enter Address</label>
        	<input type="text" name="room_type" class="form-control" placeholder="Enter Address">
        </div>
         <div class="form-group">
        	<label>Enter City</label>
        	<select class="form-control">
        		<option>Select</option>
        		<option>AC</option>
        		<option>NoN-AC</option>
        	</select>
        </div>
        <div class="form-group">
        	<label>Room Type</label>
        	<input type="text" name="room_price" class="form-control" placeholder="Enter Room Type">
        </div>
        <div class="form-group">
        	<label>Pay Amount</label>
        	<input type="text" name="room_price" class="form-control" placeholder="Enter Pay Amount">
        </div>
        <div class="form-group">
        	<input type="submit" class="btn btn-primary" name="sub" value="Save" />
        </div>
      </div>
    </div>
  </div>
</div>