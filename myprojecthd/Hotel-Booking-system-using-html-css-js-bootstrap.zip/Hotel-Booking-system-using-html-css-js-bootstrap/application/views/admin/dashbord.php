<?php include('include/header.php'); ?>
	<div class="container" style="background-image: url(<?= base_url('tool/img1/banner.jpeg'); ?>); background-size: 100% 450px;background-repeat: no-repeat;">
			<div style="width: 100%;height: 330px">
		  <center> <div style="background-color: red;opacity: 0.5;width: 250px;height: 100px;border-radius: 10px;margin-top: 150px;padding-top: 5px;"> 
			   <h2 align="center" style="color:Yellow;">Admin Home</h2>
	       </div></center>
	       </div>
	</div>
	<div class="container">
	<h4 align="center">copyright@myprojecthd</h4>
	</div>
</div>
</body>
</html>