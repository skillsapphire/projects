function login()
{
	un=$('#un').val();
	ps=$('#ps').val();
	data={'un':un,'ps':ps};
	$.post('admin/login',data,function(res){
		if(res.match('1'))
		{
			window.location.href="admin_welcome/dashbord";
		}
		else
		{
			alert('Wrong User');
		}
	})
}
