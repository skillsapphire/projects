<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
</head>
<body>
<div class="container-fluid">
	<div class="container">
		<?php include('include/menu.php'); ?>
		<div class="col-sm-12">
			<h3>About</h3>
			<div class="col-sm-4">
				<br>
				<img src="<?php echo base_url().'tool/img1/g4.jpeg' ?>" class="img-responsive">
				<br>
			</div>
			<div class="col-sm-8"><br>
				<p>This IS a Contect Page Demo Contect. This IS a Contect Page Demo Contect. This IS a Contect Page Demo Contect. This IS a Contect Page Demo Contect. This IS a Contect Page Demo Contect. This IS a Contect Page Demo Contect. This IS a Contect Page Demo Contect.</p><br>
				<p>This IS a Contect Page Demo Contect. This IS a Contect Page Demo Contect. This IS a Contect Page Demo Contect. This IS a Contect Page Demo Contect. This IS a Contect Page Demo Contect. This IS a Contect Page Demo Contect. This IS a Contect Page Demo Contect.</p>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>