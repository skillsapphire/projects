<!DOCTYPE html>
<html>
<head>
	<title>Payment Success</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<style type="text/css">
		a:hover{ text-decoration: none; }
		.Success_msg_block {
		    width: 20%;
		    margin-top: 30px;
		    margin-bottom: 30px;
		    margin-left: 42%;
		}
	</style>
</head>
<body>
<div class="container-fluid">
	<div class="container">
		<?php include('include/menu.php'); ?>
		<div class="col-sm-12">
			<h3>Payment Success</h3>
			<div class="col-sm-12">
				<div class="Success_msg_block">
					<img src="<?php echo base_url().'tool/img/checked.svg' ?>">
					<a href="<?php echo base_url() ?>" class="btn btn-success" style=" margin-left: 53px;margin-top: 30px;">Go To Home</a>
				</div>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>