<!DOCTYPE html>
<html>
<head>
	<title>Checkout</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<style type="text/css">
		a:hover{ text-decoration: none; }
	</style>
</head>
<body>
<div class="container-fluid">
	<div class="container">
		<?php include('include/menu.php'); ?>
		<div class="col-sm-12">
			<h3>Checkout</h3>
			<form action="<?php echo base_url().'index.php/home/place_order' ?>"  method="post">
			<div class="col-sm-6">
				<div class="form-group">
					<label>Enter Name</label>
					<input type="text" name="name" required="required" value="<?php echo $user_info['name'] ?>" placeholder="Enter Name" class="form-control" id="name">
				</div>
				<div class="form-group">
					<label>Enter Mobile NO</label>
					<input type="text" required="required" value="<?php echo $user_info['mno'] ?>" name="mobile_no" placeholder="Enter Mobile No" class="form-control" id="mobile">
				</div>
				<div class="form-group">
					<label>Enter E-Mail</label>
					<input type="text" required="required" value="<?php echo $user_info['email'] ?>" name="email" placeholder="Enter E-Mail" class="form-control" id="email">
				</div>
				<div class="form-group">
					<label>Enter Address</label>
					<textarea required="required" name="address" class="form-control"></textarea>
				</div>
				<div class="form-group">
					<label>Enter City</label>
					<input type="text" required="required"  name="city" placeholder="Enter City" class="form-control" id="city">
				</div>
				<div class="form-group">
					<button class="btn btn-primary">Continue</button>
				</div>
				<br>
			</div>
			</form>
			<div class="col-sm-6"><br>
				<h3>Your Cart</h3>
				<table class="table">
					<tr>
						<th>Product</th>
						<th>QTY</th>
						<th>Price</th>
					</tr>
					<?php 
					foreach($cart_info as $cart)
					{
					?>
					<tr>
						<td><?php echo $cart['name'] ?></td>
						<td><?php echo $cart['qty'] ?></td>
						<td><?php echo $cart['price']*$cart['qty'] ?></td>
					</tr>
					<?php 
					}
					?>
				</table>

			</div>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>
<script type="text/javascript">
	
</script>