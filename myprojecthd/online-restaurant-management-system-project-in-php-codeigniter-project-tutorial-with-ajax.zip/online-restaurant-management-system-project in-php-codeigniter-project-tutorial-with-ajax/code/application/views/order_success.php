<!DOCTYPE html>
<html>
<head>
	<title>Payment</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<style type="text/css">
		a:hover{ text-decoration: none; }
		.success_message_bock >img {
		    width: 100px;
		    margin-bottom: 29px;
		}
		.success_message_bock {
	    text-align: center;
	    margin-top: 32px;
	    margin-bottom: 62px;
	}
	</style>
</head>
<body>
<div class="container-fluid">
	<div class="container">
		<?php include('include/menu.php'); ?>
		<div class="col-sm-12">
			<div class="success_message_bock">
				<img src="<?php echo base_url().'tool/img/checked.svg' ?>">
				<h4>Order Successfully Booked Your Order No : <?php echo $order_no[0]['order_no'] ?></h4>
			</div>
		
		</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>
<script type="text/javascript">
	
</script>