<!DOCTYPE html>
<html>
<head>
	<title>Cart</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<style type="text/css">
		a:hover{ text-decoration: none; }
	</style>
</head>
<body>
<div class="container-fluid">
	<div class="container">
		<?php include('include/menu.php'); ?>
		<div class="col-sm-12">
			<h3>Cart</h3>
			<table class="table">
				<tr>
					<td>#</td>
					<td>Product Name</td>
					<td>Product Qty</td>
					<td>Product Amount</td>
					<td>Action</td>
				</tr>
				<?php 
				if($cart_products)
				{
					$i=1;
				foreach($cart_products as $cp)
				{
				?>
				<tr>
					<td><?php  echo $i; ?></td>
					<td><?php echo $cp['pname'] ?></td>
					<td><?php echo $cp['qty'] ?></td>
					<td><?php echo $cp['qty']*$cp['price']; ?></td>
					<td><a href="<?php echo base_url().'index.php/home/delete_cart_product/'.$cp['id']; ?>" class="btn btn-danger">X</a></td>
				</tr>
				<?php 
				$i++;
				}
				}
				else 
				{
					?>
					<tr>
						<td colspan="5"><center>Cart is Empty</center></td>
					</tr>
					<?php 
				}
				?>
			</table>
			<div class="row">
				<div class="col-sm-12">
					<a href="<?php echo  base_url().'index.php/home/continue_cart' ?>" class="btn btn-primary pull-right" style=" margin-bottom: 20px; ">Continue</a>
				</div>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>
<script type="text/javascript">
	function login_now()
	{
		email=$('#email').val();
		password=$('#password').val();
		if(email=='')
			alert('Enter E-Mail')
		else if(password=='')
			alert('Enter Password ')
		else 
		{
			data={'email':email,'password':password};
			$.post('<?php echo base_url().'index.php/home/login' ?>',data,function(fb){
				if(fb.match('1'))
				{
					window.location.href="<?php echo base_url() ?>";
				}
				else 
				{
					alert("Username And Password Dose't Match ")
				}
			});
		}
	}
</script>