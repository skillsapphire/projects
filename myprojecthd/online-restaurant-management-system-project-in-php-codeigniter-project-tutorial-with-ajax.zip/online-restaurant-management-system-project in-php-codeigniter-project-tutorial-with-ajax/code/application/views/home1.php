<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/fa/css/font-awesome.min.css' ?>">

	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
<style type="text/css">
	.add_to_cart_control {
	    color: black !important;
	}
</style>
</head>
<body>
<div class="container-fluid">
	<div class="container">
		<?php include('include/menu.php'); ?>
		<div class="col-sm-12">
			<hr>
			<?php 
			if($products)
			{
			foreach($products as $prod)
			{
			?>
			<div class="col-sm-4" ><img src="<?php echo base_url().'uploads/products/'.$prod['img']; ?>" class="img-responsive">
			<div class="col-sm-8">
			<br><table>
				<tr>
					<td width="40%"><?php echo $prod['name']; ?></td>
				</tr>
				<tr>
					<td width="40%">$<?php echo $prod['price']; ?></td>
				</tr>
			</table>
			</div>
			<div class="col-sm-4" style="padding-top: 15px"><a id="add_to_cart" data-user="<?php echo $this->session->userdata('user_id'); ?>" data-product="<?php echo $prod['id']; ?>" href="javascript:;"><font size="5"><i class="fa fa-cart-plus pull-right add_to_cart_control" aria-hidden="true"></i></font></font></a></div>
			</div>
			<?php 
			}
			}
			else 
			{
				echo "<h3 align='center'>Product Not Found</h3>";
			}
			?>
		</div><br>.
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>

<script type="text/javascript">
$(document).on('click','#add_to_cart',function(){
	user=$(this).attr('data-user');
	product=$(this).attr('data-product');
	if(user=='')
	{
		window.location.href='<?php echo base_url()."index.php/home/login"; ?>'
	}
	else 
	{
		data={'user_id':user,'product_id':product};
		$.post('<?php echo base_url()."index.php/home/add_to_cart" ?>',data,function(fb){
			if(fb.match('1'))
				alert('Product Successfully Added');
			else if(fb.match('2'))
				alert('Product is Outof Stock')
			else 
				alert('Product Not Added');
		})
	}
});
</script>