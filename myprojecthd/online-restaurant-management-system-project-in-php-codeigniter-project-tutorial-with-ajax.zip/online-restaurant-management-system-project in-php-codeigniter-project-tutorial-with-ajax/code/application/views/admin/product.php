<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<script type="text/javascript">

	</script>
</head>
<body>
<?php 
include('include/header.php');
?>
			<div class="col-sm-8">
				<div style="width: 100%;height: 400px;padding-top: 10px;">
					<div class="row">
						<div class="col-sm-12">
							<a  data-toggle="modal" href="#delete_popup" class="btn btn-primary pull-right" style="margin-bottom: 10px;">Add New Product</a>
						</div>
					</div>
					<table class="table">
						<tr>
							<td>Image</td>
							<td>Name</td>
							<th>Price</th>
							<th>Qty</th>
						</tr>
						<?php 
						if($products)
						{
							foreach($products as $prod1)
							{
							?>
							<tr>
								<td><img src="<?php echo base_url().'uploads/products/'.$prod1['img']; ?>" width="100px" height="100px;"> </td>
								<td><?php echo $prod1['name'] ?></td>
								<th>$<?php echo $prod1['price'] ?></th>
								<th><?php echo $prod1['qty']; ?></th>
							</tr>
							<?php 
							}
						}
						else 
						{
							?>
							<tr>
								<td colspan="4">Product Not Found</td>
							</tr>
							<?php 	
						}	
						?>
						
					</table>
				</div>
				<br>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>



<div id="delete_popup" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Add New Product</h4>
      </div>
      <div class="modal-body">
       <form id="product_add_form">
        <div class="form-group">
        	<label>Enter Name</label>
        	<input type="text" name="name"  class="form-control" placeholder="Enter Name" id="name">
        </div>
          <div class="form-group">
        	<label>Enter Price</label>
        	<input type="number" name="price" class="form-control" placeholder="Enter Price" id="price">
        </div>
          <div class="form-group">
        	<label>Enter QTY</label>
        	<input type="number" name="qty" class="form-control" placeholder="Enter Qty" id="qty">
        </div>
          <div class="form-group">
        	<label>Image</label>
        	<input type="file" class="form-control" name="img" id="img">
        </div>
    	</form>
        <div class="form-group">
        	<button class="btn btn-success" onclick="add_new_product()">Add Product</button>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
	function add_new_product()
	{
		name=$('#name').val();
		price=$('#price').val();
		qty=$('#qty').val();
		if(name=='')
			alert('Enter Product Name')
		else if(price=='')
			alert('Enter Product Price')
		else if(qty=='')
			alert('Enter Qty')
		else
		{
			$.ajax({
				'url':'<?php echo  base_url("index.php/admin/add_products") ?>',
				'method':'post',
				'data':new FormData($("#product_add_form")[0]),
				'contentType':false,
				'processData':false,
				'success':function(fb)
				{
					if(fb.match('1'))
					{
						$('#delete_popup').modal('toggle');
						$('#name').val('');
						$('#price').val('');
						$('#qty').val('');
						alert('Product Successfully Added');
					}
					else if(fb.match('2'))
					{
						alert('Only JPG And PNG File Are Allowed')
					}
					else 
					{
						alert('product Not Added');
					}
				}
			});
		}
	}
</script>