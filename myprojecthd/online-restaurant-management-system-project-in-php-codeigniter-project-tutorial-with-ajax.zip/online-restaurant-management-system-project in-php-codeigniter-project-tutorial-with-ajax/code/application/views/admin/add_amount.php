<!DOCTYPE html>
<html>
<head>
	<title>Users</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<script type="text/javascript">
	
	</script>
</head>
<style type="text/css">
	ol li{ width: 30%;height: 100px;margin-left: 2%;float: left;list-style: none; line-height: 100px;border:1px solid silver;text-align: center;color: red; }
</style>
<body>
<?php 
include('include/header.php');
?>
			<div class="col-sm-8">
				<div style="width: 100%;height: 400px;padding-top: 10px;padding-top:140px;">
						<div class="form-group">
							<label>Enter Amount</label>
							<input type="number" name="amount" id="amount" placeholder="Enter Amount" class="form-control">
						</div>
						<div class="form-group">
							<button class="btn btn-success" id="add_amount">Add</button>
						</div>
				</div>
				<br>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>
<script type="text/javascript">
	$('#add_amount').click(function(){
		var amount=$('#amount').val();
		if(amount=='')
			alert('Enter Amount');
		else 
		{
			$.post('<?php echo base_url()."index.php/admin/add_amount/".$this->uri->segment("3") ?>',{'amount':amount},function(fb){
				if(fb.match('1'))
				{
					alert('Amount Successfully Added');
					setTimeout(function(){
						window.location.href="<?php echo base_url() ?>index.php/admin/users";
					},2000);
				}
			})
		}
	});
</script>