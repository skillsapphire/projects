<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<script type="text/javascript">
	
	</script>
</head>
<style type="text/css">
.tbl_master_form {
    margin-top: 50px;
}	
</style>
<body>
<?php 
include('include/header.php');
?>
			<div class="col-sm-8">
				<div class="tbl_master_form">
					<div class="form-group">
						<label>Enter Table No</label>
						<input type="text" name="tbl_no" placeholder="Enter Table No" id="tbl_no" class="form-control">
					</div>
					<div class="form-group">
						<label>Select Category</label>
						<select name="category" id="category" class="form-control">
							<option value="">Select</option>
							<option >2 Member</option>
							<option>4 Member</option>
							<option>6 Member</option>
						</select>
					</div>
					<div class="form-group">
						<label>Enter Amount</label>
						<input type="text" name="tbl_amount" placeholder="Enter Table Amount" id="tbl_amount" class="form-control">
					</div>
					<div class="form-group">
						<button class="btn btn-success" id="add_table">Add</button>
					</div>
				</div>
				<br>
			</div>
			
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>
<script type="text/javascript">
	$('#add_table').click(function(){
		tbl_no=$('#tbl_no').val();
		category=$('#category').val();
		tbl_amount=$('#tbl_amount').val();
		if(tbl_no=='')
			alert('Enter Table No');
		else if(category=='')
			alert('Select Category')
		else if(tbl_amount=='')
			alert('Enter Table Amount')
		else 
		{
			var data={
				'table_no':tbl_no,
				'category':category,
				'amount':tbl_amount
			};
			$.post('<?php echo base_url().'index.php/admin/add_new_table' ?>',data,function(fb){
				if(fb.match('1'))
				{
					alert('Table Successfully Added')
					setTimeout(function(){
						window.location.href="<?php echo base_url().'index.php/admin/tables/' ?>"
					},2000);
				}
				else 
				{
					alert('Table Not Added');
				}
			})
		}
	});
</script>