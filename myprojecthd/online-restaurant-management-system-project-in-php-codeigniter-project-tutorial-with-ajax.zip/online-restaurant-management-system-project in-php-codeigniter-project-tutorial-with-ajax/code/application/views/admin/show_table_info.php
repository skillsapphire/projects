<!DOCTYPE html>
<html>
<head>
	<title>Table Book Info</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<script type="text/javascript">
	
	</script>
</head>
<style type="text/css">
	.info_box {
	    height: 100px;
	    padding: 7px;
	}
	</style>
<body>
<?php 
include('include/header.php');
?>
			<div class="col-sm-8">
				<div style="width: 100%;height: 400px;padding-top: 10px;padding-top:61px;">
					<div class="row">
						<div class="col-sm-3">
							<div class="info_box">
							<p><b>Table No</b></p>
							<?php echo $book_tables['table_no'] ?>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="info_box">
							<p><b>Book Date</b></p>
							<?php echo $book_tables['bookdate_date'] ?>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="info_box">
							<p><b>Start Time</b></p>
							<?php echo $book_tables['stime'] ?>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="info_box">
							<p><b>End Time</b></p>
							<?php echo $book_tables['etime'] ?>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-4">
							<div class="info_box">
							<p><b>Name</b></p>
							<?php echo $book_tables['name'] ?>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="info_box">
							<p><b>E-Mail</b></p>
							<?php echo $book_tables['email'] ?>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="info_box">
							<p><b>Mobile No</b></p>
							<?php echo $book_tables['mobile_no'] ?>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-4">
							<div class="info_box">
							<p><b>Address</b></p>
							<?php echo $book_tables['address'] ?>
							</div>
						</div>
						
					</div>
				</div>
				<br>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>