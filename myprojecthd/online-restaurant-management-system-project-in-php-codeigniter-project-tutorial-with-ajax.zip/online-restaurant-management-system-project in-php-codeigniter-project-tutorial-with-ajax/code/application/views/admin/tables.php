<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<link rel="stylesheet" type="text/css" href="http://localhost/Tutorial/rbs/tool/fa/css/font-awesome.min.css">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<script type="text/javascript">
	
	</script>
</head>
<style type="text/css">
	ol li{ width: 30%;height: 100px;margin-left: 2%;float: left;list-style: none; line-height: 100px;border:1px solid silver;text-align: center;color: red; }
	.tab_block > ul li {
	    width: 40%;
	    float: left;
	    margin-right: 6px;
	    cursor: pointer;
	}
	.hide_div{
		display: none;
	}
	.tab_active {
    background: green;
    color: white;
}
.booked_table_container {
    margin-top: 24px;
}
</style>
<body>
<?php 
include('include/header.php');
?>
			<div class="col-sm-8">
				<div class="tab_block">
					<ul>
						<li class="custom_tabs tab_active" id="tbl_mas">Table Master</li>
						<li class="custom_tabs" id="tbl_book">Booked Tables</li>
					</ul>
				</div>
				<br>
			</div>
			<div class="col-sm-8">
				<div class="table_master" id="table_master">
					<a href="<?php echo base_url().'index.php/admin/add_new_table' ?>" class="btn btn-success pull-right">Add New Table</a>
					<div class="row">
						<div class="col-sm-12">
							<table class="table">
								<tr>
									<td>#</td>
									<td>Table No</td>
									<td>Category</td>
									<td>Amount</td>
								</tr>
								<?php 
								if($tables)
								{
									$i=1;
									foreach($tables as $table)
									{
										?>
										<tr>
											<td><?php echo $i ?></td>
											<td><?php echo $table['table_no'] ?></td>
											<td><?php echo $table['category'] ?></td>
											<td><?php echo $table['amount'] ?></td>
										</tr>
										<?php 
										$i++;
									}
								}
								else 
								{
									?>
									<tr>
										<td colspan="4">Data Not Found</td>
									</tr>
									<?php 
								}
								?>
							</table>
						</div>
					</div>
				</div>
				<div class="booked_tables hide_div" id="booked_tables">
					<div class="booked_table_container">
						<table class="table"> 
							<tr>
								<th>#</th>
								<th>Table No</th>
								<th>Name</th>
								<th>Amount</th>
								<th>Book Date</th>
								<th>Action</th>
							</tr>
							<?php 
							$i=1;
							foreach($book_tables as $bt)
							{
								?>
								<tr>
									<td><?php echo $i; ?></td>
									<td><?php  echo $bt['table_no'] ?></td>
									<td><?php  echo $bt['name'] ?></td>
									<td><?php  echo $bt['amount'] ?></td>
									<td><?php  echo $bt['bookdate_date'] ?></td>
									<td><a href="<?php echo base_url().'index.php/admin/show_table_info/'.$bt['id'] ?>" class="btn btn-info"><i class="fa fa-eye"></i></a></td>
								</tr>
								<?php
								$i++; 
							}
							?>
						</table>	

					</div>
				</div>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>
<script type="text/javascript">
	$('#tbl_mas').click(function(){
		$('#table_master').removeClass('hide_div');
		$('#booked_tables').addClass('hide_div');
		$('.custom_tabs').removeClass('tab_active');
		$('#tbl_mas').addClass('tab_active');
	});
	$('#tbl_book').click(function(){
		$('#table_master').addClass('hide_div');
		$('#booked_tables').removeClass('hide_div');
		$('.custom_tabs').removeClass('tab_active');
		$('#tbl_book').addClass('tab_active');
	});
</script>