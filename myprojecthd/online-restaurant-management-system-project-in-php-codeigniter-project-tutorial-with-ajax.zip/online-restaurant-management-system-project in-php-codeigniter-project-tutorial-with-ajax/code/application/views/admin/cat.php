<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<script type="text/javascript">
		$('document').ready(function(){
			$('#cat_btn').addClass('active');
		$('#cat_btn').click(function(){
			$('#sub_cat').hide();
			$('#cat').show();
			$('#sub_cat_btn').removeClass('active');
			$('#cat_btn').addClass('active');
			$('#page_title').text('Category');
		});
		$('#sub_cat_btn').click(function(){
				$('#cat').hide();
				$('#sub_cat').show();
				$('#cat_btn').removeClass('active');
			     $('#sub_cat_btn').addClass('active');
			     $('#page_title').text('Sub - Category');
		});
		});
		function add_cat()
		{
			 var cat=$('#add_cat').val();
			 var data={'name':cat,'status':'1'};
			 $.post('<?php echo  base_url('index.php/admin/add_cat'); ?>',data,function(fb){
			 	if(fb.match('1'))
			 	{
			 		$('#add_cat').val('');
			 		alert('Category Successfully Inserted');
			 		window.location.href="<?php base_url('index.php/admin/cat/') ?>";
			 	}
			 	else 
			 		alert('Category Not Inserted');
			 })
		}
		function status_change(tbl_name,field,data)
		{
			status_data=$('#status_'+data).val();
			var obj={'tbl_name':tbl_name,'field':field,'field_data':data,'op_data':status_data};
			$.post('<?= base_url().'index.php/admin/status_change'; ?>',obj,function(fb){
				if(fb.match('1'))
					alert('Status Successfully Changed');
				else 
					alert('Status Not Changed');
			});
		}
		function status_change1(tbl_name,field,data)
		{
			status_data=$('#status1_'+data).val();
			
			var obj={'tbl_name':tbl_name,'field':field,'field_data':data,'op_data':status_data};
			$.post('<?= base_url().'index.php/admin/status_change'; ?>',obj,function(fb){
				if(fb.match('1'))
					alert('Status Successfully Changed');
				else 
					alert('Status Not Changed');
			});
		}
		function delete_data(tbl_name,field,data)
		{
			$('#id1').val(data);
			$('#tbl_name').val(tbl_name);
			$('#field1').val(field);
			$('#delete_popup').modal('toggle');

		}		
		function update_data(tbl_name,field,data)
		{
			var data1=$('#cat_name_'+data).text();
			$('#name').val(data1);
			$('#id').val(data);
			$('#update_popup').modal('toggle');
		}
		function update()
		{
			name=$('#name').val();
			id=$('#id').val();
			if(name=='')
				alert('Enter Category Name');
			else 
			{
				$.post('<?php echo base_url().'index.php/admin/update_cat/' ?>',{'name':name,'id':id},function(fb){
					if(fb.match('1'))
					{
						alert('category Successfully updated')
						location.reload();
					}
					else 
					{
						alert('category not updated')
					}
				});
			}
		}
		function add_sub_cat()
		{
			name=$('#sub_cat_name').val();
			cat_id=$('#cat_id').val();
			data={'name':name,'cat':cat_id,'status':'1'};
			$.post('<?php echo base_url('index.php/admin/add_sub_cat')  ?>',data,function(fb){
				if(fb.match('1'))
				{
					alert('Sub Category Successfully Added')
					window.location.href="<?php echo base_url('index.php/admin/cat'); ?>";
				}
				else 
				{
					alert('Sub Category Not Added');
				}
			})
		}
		function change_cat(id)
		{
			cat_id=$('#c1_'+id).val();
			$.post('<?php echo base_url().'index.php/admin/change_cat'; ?>',{'id':id,'cat_id':cat_id},function(fb){
				if(fb.match('1'))
					alert('Category Successfully Changed');
				else 
					alert('Category Not Changed')
			});
		}
		function update_sub_cat(id)
		{
			sname=$('#sname_'+id).text();
			$('#update_scatpopup').modal('toggle');
			$('#sname').val(sname);
			$('#sid').val(id);
		}
		function supdate1()
		{
			sname=$('#sname').val();
			sid=$('#sid').val();
			if(sname=='')
			{
				alert('Enter Sub Category')
			}
			else 
			{
					
					$.post('<?php echo  base_url("index.php/admin/supdate/"); ?>',{'sname':sname,'id':sid},function(fb){
						if(fb.match('1'))
						{
							location.reload();
						}
						else 
						{
							alert('Some Technical Problum Please Try Again');
						}
					})
			}
		}
	</script>
</head>
<style type="text/css">
	ol li{ width: 46%;height: 50px;margin-left: 2%;float: left;list-style: none; line-height: 50px;border:1px solid silver;text-align: center;color: red; }
	#sub_cat{display: none;}
	.active{ background: green;color: white; }
</style>
<body>
<?php 
include('include/header.php');
?>
			<div class="col-sm-8">
				<div style="width: 100%;height: 400px;padding-top: 10px;">
						<ol>
							<a href="javascript:;" > <li id="cat_btn">Category</li></a>
							<a href="javascript:;" ><li id="sub_cat_btn">Sub Category</li></a>
						</ol>
						<div id="cat" ><br><br>.
							<div class="form-group">
								<lable><b>Enter Category</b></lable>
								<input type="text" id="add_cat"  class="form-control" placeholder="Enter Category" title="Enter Category" />
							</div>
							<div class="form-group">
								<input type="submit" onclick="add_cat();" id="btn" value="Save" class="btn btn-success" />
							</div>
							<table class="table">
								<tr>
									<td>SNo.</td>
									<td>Name</td>
									<td>Status</td>
									<td>Action</td>
								</tr>
								<?php
								$i=1; 
								if(isset($cats))
								{
								foreach($cats as $cat)
								{
								?>
								<tr>
									<td><?php echo $i; ?></td>
									<td id="cat_name_<?php echo $cat['id']; ?>"><?php echo $cat['name']; ?></td>
									<td>
										<select id="status_<?php echo $cat['id'] ?>" onchange="status_change('category','id','<?php echo $cat['id']; ?>')" >
											<option <?php if($cat['status']=='1') { echo "selected"; } ?> value="1">Active</option>
											<option <?php if($cat['status']=='0') { echo "selected"; } ?> value="0">Inactive</option>
										</select>
									</td>
									<td>
										<a href="javascript:;" onclick="delete_data('category','id','<?php echo $cat['id']; ?>')" class="btn btn-success">Delete</a>
										<a href="javascript:;" onclick="update_data('category','id','<?php echo  $cat['id'] ?>')" class="btn btn-success">Update</a>
									</td>
								</tr>
								<?php 
								$i++;
								}
								}
								else 
								{ ?>
									<h2>Catgory Not fOUND</h2>
							<?php	}
								?>
							</table>
						</div>
						<div id="sub_cat">
							<br><br>.
							<div class="form-group">
								<lable><b>Enter Sub Category</b></lable>
								<input type="text" name="sub_cat" id="sub_cat_name" class="form-control" placeholder="Enter Category" title="Enter Category" />
							</div>
							<div class="form-group">
								<label>Select Category</label>
								<select id="cat_id" class="form-control">
									<option>---Select---</option>
									<?php 
									foreach($cats as $c1)
									{
									?>
									<option value="<?php echo $c1['id']; ?>"><?php echo $c1['name']; ?></option>
									<?php 
									}
									?>
								</select>
							</div>
							<div class="form-group">
								<input type="submit" id="btn" onclick="add_sub_cat()" value="Save" class="btn btn-success" />
							</div>
							<table class="table">
								<tr>
									<td>SNo.</td>
									<td>Name</td>
									<td>Category</td>
									<td>Status</td>
									<td>Action</td>
								</tr>
								<?php 
								$i=1;
								foreach($sub_cats as $scat)
								{
								?>
								<tr>
									<td><?php echo $i; ?></td>
									<td  id="sname_<?php echo $scat['id']  ?>"><?php echo $scat['name']; ?></td>
									<td>
									<select id="c1_<?php echo $scat['id']; ?>" onchange="change_cat('<?php echo $scat['id']; ?>')">
									<?php 
									foreach($cats as $c1)
									{
									?>
										<option value="<?php echo $c1['id'] ?>" <?php if($c1['id']==$scat['cat']) { echo "selected"; } ?>><?php echo $c1['name']; ?></option>
									<?php 
									}
									?>
									</select>
									</td>
									<td>
										<select onchange="status_change1('sub_category','id','<?php echo $scat['id']; ?>')" id="status1_<?php echo $scat['id']; ?>">
											<option <?php if($scat['status']=='1') {  echo "selected"; } ?> value="1">Active</option>
											<option <?php if($scat['status']=='0') {  echo "selected"; } ?> value="0">Inactive</option>
										</select>
									</td>
									<td>
										<a href="javascript:;" onclick="delete_data('sub_category','id','<?php echo $scat['id']; ?>')" class="btn btn-success">Delete</a>
										<a href="javascript:;" onclick="update_sub_cat('<?php echo $scat['id']; ?>')" class="btn btn-success">Update</a>
									</td>
								</tr>
								<?php 
								}
								?>
							</table>
						</div>
				</div>
				<br>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>
<div id="update_popup" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Update Category</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
        	<input type="hidden" id="id" >
        	<label>Enter Name</label>
        	<input type="text" name="name" id="name" class="form-control" placeholder="Enter Name" value="" title="Enter Name">
        </div>
        <div class="form-group">
        	<input type="button"  class="btn btn-primary" onclick="update();"  value="Update" title="Click Now">
        </div>
      </div>
    </div>
  </div>
</div>
<div id="update_scatpopup" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Update  Sub Category</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
        	<input type="hidden" id="sid" >
        	<label>Enter Name</label>
        	<input type="text" name="name" id="sname" class="form-control" placeholder="Enter Sub Category Name" value="" title="Enter Sub Category Name">
        </div>
        <div class="form-group">
        	<input type="button"  class="btn btn-primary" onclick="supdate1();"  value="Update" title="Click Now">
        </div>
      </div>
    </div>
  </div>
</div>


<div id="delete_popup" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Do you wont to delete this data</h4>
      </div>
      <div class="modal-body">
      	<?php echo form_open('admin/delete_data'); ?>
        <div class="form-group">
        	<input type="hidden" id="id1" name="id" >
        	<input type="hidden" id="tbl_name" name="tbl_name" >
        	<input type="hidden" id="field1" name="field1" >
        	<input type="submit" class="btn btn-primary" name="sub" value="Delete" />
        </div>
        <?php 
        echo form_close();
        ?>
      </div>
    </div>
  </div>
</div>