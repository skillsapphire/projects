<!DOCTYPE html>
<html>
<head>
	<title>View Orders</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/fa/css/font-awesome.min.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<script type="text/javascript">
	
	</script>
</head>
<style type="text/css">
	ol li{ width: 30%;height: 100px;margin-left: 2%;float: left;list-style: none; line-height: 100px;border:1px solid silver;text-align: center;color: red; }
</style>
<body>
<?php 
include('include/header.php');
?>
			<div class="col-sm-8">
				<div style="width: 100%;height: 400px;padding-top: 10px;padding-top:61px;">
					<?php 
					$prod_data=json_decode($orders[0]['product_info']);
					
					?>
						<table class="table">
							<tr>
								<td>#</td>
								<td>Product Name</td>
								<td>Amount</td>
								<td>Qty</td>
								<td>Total Amount</td>
							</tr>
							<?php 
							$i=1;
							foreach($prod_data as $pd)
							{
								
								$prod_info=$this->my_model->select_data('products','name,price',array('id'=>$pd->product_id));
								
							 ?>
								<tr>
									<td><?php echo $i; ?></td>
									<td><?php echo $prod_info[0]['name'] ?></td>
									<td><?php echo $prod_info[0]['price'] ?></td>
									<td><?php echo $pd->qty ?></td>
									<td><?php echo $prod_info[0]['price']*$pd->qty ?></td>
								</tr>
								<?php
								$i++; 
							}
							?>
						</table>
				</div>
				<br>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>