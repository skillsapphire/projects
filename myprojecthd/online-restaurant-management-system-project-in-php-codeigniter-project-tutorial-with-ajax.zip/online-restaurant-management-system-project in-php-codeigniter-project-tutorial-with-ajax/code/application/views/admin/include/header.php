<div class="container-fluid">
	<div class="container">
		<div class="col-sm-12 header" >
			<div class="col-sm-4"><h3>Restront Booking System</h3></div>
			<div class="col-sm-2"></div>
			<div class="col-sm-6">
				<h3 class="pull-right"><span id="page_title"><?php echo $page_title; ?></span></h3>
			</div>
		</div>
		<div class="col-sm-12">
			<div class="col-sm-4">
				<div class="menu">
					<ul>
						<li><a href="<?php echo  base_url().'index.php/admin'; ?>">Home</a></li>
						<li><a href="<?php echo  base_url().'index.php/admin/users'; ?>">Users</a></li>
						<li><a href="<?php echo  base_url().'index.php/admin/cat/'; ?>">Category</a></li>
						<li><a href="<?php echo  base_url().'index.php/admin/product/'; ?>">Product</a></li>
						<li><a href="<?php echo  base_url().'index.php/admin/orders/'; ?>">Orders</a></li>
						<li><a href="<?php echo  base_url().'index.php/admin/tables/'; ?>">Tables</a></li>
					</ul>
				</div>
			</div>