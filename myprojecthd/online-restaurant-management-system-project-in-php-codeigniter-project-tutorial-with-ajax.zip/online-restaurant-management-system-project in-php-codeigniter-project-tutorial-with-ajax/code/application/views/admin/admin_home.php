<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<script type="text/javascript">
	
	</script>
</head>
<style type="text/css">
	ol li{ width: 30%;height: 100px;margin-left: 2%;float: left;list-style: none; line-height: 100px;border:1px solid silver;text-align: center;color: red; }
</style>
<body>
<?php 
include('include/header.php');
?>
			<div class="col-sm-8">
				<div style="width: 100%;height: 400px;padding-top: 10px;padding-top:130px;">
						<ol>
							<li>Total Product (5)</li>
							<li>Total Order (5)</li>
							<li>Total Earning (5)</li>
						</ol>
				</div>
				<br>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>