<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<script type="text/javascript">
		function admin_login()
		{
			var un=$('#un').val();
			var ps=$('#ps').val();
			data={'un':un,'ps':ps};
			if(un=='')
				alert('Enter Username')
			else if(ps=='')
				alert('Enter Password')
			else 
			{
				$.post('<?php echo  base_url().'index.php/Admin_login/login_code'?>',data,function(fb){
					if(fb.match('1'))
						window.location.href="<?php echo  base_url().'index.php/admin/' ?>";
					else 
						alert('Username And Password Not Match');
				});
			}
		}
	</script>
</head>
<body>
<style type="text/css">
	.login_box{
		width: 80%;
		height: 200px;
		color: blue;
		margin: auto;
		font-size: 17px;
	}
</style>
<div class="container-fluid">
	<div class="container">
		<div class="col-sm-12 header" >
			<div class="col-sm-4"><h3>Restront Booking System</h3></div>
			<div class="col-sm-2"></div>
			<div class="col-sm-6">
				<div class="input">
				<input type="text" class="text_filed" placeholder="Search.....">
				<a href="#" class="sbtn"><font color="red">&nbsp;&nbsp;Search</font></a>
				</div>
			</div>
		</div>
		<div class="col-sm-12">
			<div class="col-sm-4">
				<div class="menu">
					<ul>
						<li><a href="<?php echo  base_url(); ?>">Home</a></li>
						<li><a href="<?php echo  base_url().'index.php/home/food_order/'; ?>">Food Order</a></li>
						<li><a href="<?php echo  base_url().'index.php/home/tbl_booking/'; ?>">Table Booking</a></li>
						<li><a href="<?php echo  base_url().'index.php/home/about/'; ?>">About</a></li>
						<li><a href="<?php echo  base_url().'index.php/home/contect/'; ?>">Contect</a></li>
					</ul>
				</div>
			</div>
			<div class="col-sm-8">
				<div style="width: 100%;height: 400px;background:url('<?php echo  base_url('tool/img1/g5.jpeg'); ?>');padding-top: 90px; background-size: 100% 400px;margin-top: 15px;">
						<div class="login_box">
							<div class="form-group">
								<label>Enter Username</label>
								<input type="text" name="text" id="un" class="form-control" placeholder="Enter Username" title="Enter Username">
							</div>
							<div class="form-group">
								<label>Enter Password</label>
								<input type="password" name="ps" id="ps" class="form-control" placeholder="Enter Password" title="Enter Password">
							</div>
							<div class="form-group">
								<button class="btn btn-success" onclick="admin_login()">Login</button>
							</div>
						</div>
				</div>
				<br>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>