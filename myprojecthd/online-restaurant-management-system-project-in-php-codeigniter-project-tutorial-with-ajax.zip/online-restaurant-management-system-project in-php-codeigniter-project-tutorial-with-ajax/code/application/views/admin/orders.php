<!DOCTYPE html>
<html>
<head>
	<title>Orders</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/fa/css/font-awesome.min.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<script type="text/javascript">
	
	</script>
</head>
<style type="text/css">
	ol li{ width: 30%;height: 100px;margin-left: 2%;float: left;list-style: none; line-height: 100px;border:1px solid silver;text-align: center;color: red; }
</style>
<body>
<?php 
include('include/header.php');
?>
			<div class="col-sm-8">
				<div style="width: 100%;height: 400px;padding-top: 10px;padding-top:61px;">
						<table class="table">
							<tr>
								<td>#</td>
								<td>Order No</td>
								<td>Order Date</td>
								<td>Name</td>
								<td>Mobile No</td>
								<td>Address</td>
								<td>City</td>
								<td>Status</td>
								<td>Action</td>
							</tr>
							<?php 
							if($all_orders)
							{
								$i=1;
								foreach($all_orders as $order)
								{
									?>
									<tr>
										<td><?php echo $i; ?></td>
										<td><?php echo $order['order_no'] ?></td>
										<td><?php echo $order['order_date'] ?></td>
										<td><?php echo $order['name'] ?></td>
										<td><?php echo $order['mobile_no'] ?></td>
										<td><?php echo $order['address'] ?></td>
										<td><?php echo $order['city'] ?></td>
										<td>
											<select name="order_staus" class="order_status_change form-control" data-id="<?php echo $order['id'] ?>"  > 
												<option <?php if($order['status']==0) { echo "selected"; } ?> value="0">New Order</option>
												<option <?php if($order['status']==1) { echo "selected"; } ?> value="1">Accepted</option>
												<option <?php if($order['status']==2) { echo "selected"; } ?> value="2">Campleted</option>
												<option <?php if($order['status']==3) { echo "selected"; } ?> value="3">Cancel</option>
											</select>
										</td>
										<td><a href="<?php echo base_url().'index.php/admin/view_order/'.$order['id'] ?>" class="btn btn-info"><i class="fa fa-eye"></i></a></td>
									</tr>
									<?php 
									$i++;
								}
							}
							?>
						</table>
				</div>
				<br>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>
<script type="text/javascript">
	$(document).on('change','.order_status_change',function(){
		data=$(this).val();
		id=$(this).attr('data-id');
		$.post('<?php echo base_url().'index.php/admin/change_order_status' ?>',{'status':data,'id':id},function(fb){
			if(fb.match('1'))
				alert('Status Successfully Changed');
			else 
				alert('Status Not Changed');
		})
	});
</script>