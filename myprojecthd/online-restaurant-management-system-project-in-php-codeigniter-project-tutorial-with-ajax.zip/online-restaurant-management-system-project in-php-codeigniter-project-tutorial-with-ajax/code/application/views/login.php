<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<style type="text/css">
		a:hover{ text-decoration: none; }
	</style>
</head>
<body>
<div class="container-fluid">
	<div class="container">
		<?php include('include/menu.php'); ?>
		<div class="col-sm-12">
			<h3>Login</h3>
			<div class="col-sm-6">
				<img src="<?php echo base_url().'tool/img1/banner.jpeg' ?>" class="img-responsive"><br>
			</div>
			<div class="col-sm-6"><br>
				<div style="margin-top: 80px;">
				<div class="form-group">
					<label>Enter E-Mail</label>
					<input type="text" name="email" id="email" class="form-control" placeholder="Enter E-Mail" />
				</div>
				<div class="form-group">
					<label>Enter Password</label>
					<input type="password" name="password" id="password" class="form-control" placeholder="Enter Password" />
				</div>
				<div class="form-group">
					<div class="col-sm-6"><input type="submit" onclick="login_now()" name="sub" value="Login" class="btn btn-success"></div>
					<div class="col-sm-6"><a href="<?php echo base_url().'index.php/home/forgot_password' ?>" class="pull-right"><font color="black">Forgot Password</font></a></div>1
				</div>

			</div>
				<div style="margin-top: 67px;">
				<p align="center"><a href="<?php echo base_url().'index.php/home/signup' ?>"><font color="black">SignUp</font></a></p>
				</div>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>
<script type="text/javascript">
	function login_now()
	{
		email=$('#email').val();
		password=$('#password').val();
		if(email=='')
			alert('Enter E-Mail')
		else if(password=='')
			alert('Enter Password ')
		else 
		{
			data={'email':email,'password':password};
			$.post('<?php echo base_url().'index.php/home/login' ?>',data,function(fb){
				if(fb.match('1'))
				{
					window.location.href="<?php echo base_url() ?>";
				}
				else 
				{
					alert("Username And Password Dose't Match ")
				}
			});
		}
	}
</script>