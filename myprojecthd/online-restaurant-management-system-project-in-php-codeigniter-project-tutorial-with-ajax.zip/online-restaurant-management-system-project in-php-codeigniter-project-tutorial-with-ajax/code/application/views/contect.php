<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
</head>
<body>
<div class="container-fluid">
	<div class="container">
		<?php include('include/menu.php'); ?>
		<div class="col-sm-12">
			<h3>Contect Information</h3>
			<div class="col-sm-6">
				<br>
				Map
				<br>
			</div>
			<div class="col-sm-6"><br>
				<div class="form-group">
					<label>Enter Name</label>
					<input type="text" name="name" class="form-control" placeholder="Enter Name" />
				</div>
				<div class="form-group">
					<label>Enter Mobile No</label>
					<input type="text" name="mno" class="form-control" placeholder="Enter Mobile No" />
				</div>
				<div class="form-group">
					<label>Enter E-Mail</label>
					<input type="text" name="mno" class="form-control" placeholder="Enter E-Mail" />
				</div>
				<div class="form-group">
					<label>Enter City</label>
					<input type="text" name="city" class="form-control" placeholder="Enter City" />
				</div>
				<div class="form-group">
					<label>Enter Comment</label>
					<textarea class="form-control" placeholder="Enter Comment"></textarea>
				</div>
				<div class="form-group">
					<input type="submit" name="sub" value="Send" class="btn btn-success">
				</div>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>