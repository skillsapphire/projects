<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/fa/css/font-awesome.min.css' ?>">
<style>
.count {
    position: absolute;
    margin-left: 46px;
    margin-top: 25px;
}
a {
    color: white;
    text-decoration: none;
}
a:hover {
    color: white;
    text-decoration: none;
}
</style>
<?php 
$user_id=$this->session->userdata('user_id');
if($this->session->userdata('user_id'))
{
	$count1=$this->my_model->select_data('add_to_cart','qty',array('user_id'=>$user_id));
	$count=0;
	foreach($count1 as $c1)
	{
		$count=$count+$c1['qty'];
	}
}
else 
{
	$count=0;
}
?>
<div class="col-sm-12 header" >
			<div class="col-sm-4"><a style="color:white;" href="<?php echo base_url() ?>"><h3>Restront Booking System</h3></a></div>
			<div class="col-sm-1"></div>
			<div class="col-sm-6">
				<div class="input">
				<input type="text" class="text_filed" placeholder="Search.....">
				<a href="#" class="sbtn"><font color="red">&nbsp;&nbsp;Search</font></a>
				</div>
			</div>
			<?php 
			$session_email=$this->session->userdata('email');
			if($session_email)
			{
			?>
			<div class="col-sm-1"><a href="<?php echo base_url().'index.php/home/cart' ?>"><i class="fa fa-cart-plus pull-right" aria-hidden="true" style=" font-size: 36px; margin-top: 6px; margin-right: 20px; "></i>
				<div class="count"><?php echo $count; ?></div></a>
			</div>
		<?php } else 
		{ ?> 
			<div class="col-sm-1"><a href="javascript:;"><i class="fa fa-cart-plus pull-right" aria-hidden="true" style=" font-size: 36px; margin-top: 6px; margin-right: 20px; "></i>
				<div class="count"><?php echo $count; ?></div></a>
			</div>
		<?php   } ?>
		</div>
		
		<div class="col-sm-12">
			<div class="col-sm-4">
				<div class="menu">
					<ul>
						<li><a href="<?php echo  base_url().'index.php/home/food_order/'; ?>">Food Order</a></li>
						<?php 
						if($session_email)
						{
						?>
						<li><a href="<?php echo  base_url().'index.php/home/tbl_booking/'; ?>">Table Booking</a></li>
						<?php 
						}
						?>
						<li><a href="<?php echo  base_url().'index.php/home/about/'; ?>">About</a></li>
						<li><a href="<?php echo  base_url().'index.php/home/contect/'; ?>">Contect</a></li>
						<?php 
						if(!$session_email)
						{
						?>
						<li><a href="<?php echo  base_url().'index.php/home/login/'; ?>">Login</a></li>
						<?php 
						}
						else 
						{
						?><li><a href="<?php echo  base_url().'index.php/home/logout'; ?>">Logout</a></li><?php 
						}
						?>
					</ul>
				</div>
			</div>
			<div class="col-sm-8">
				<div style="width: 100%;height: 400px;background:url('<?php echo  base_url('tool/img1/g5.jpeg'); ?>');padding-top: 150px; background-size: 100% 400px;margin-top: 15px;">
					<h2 style="color: white">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Message</h2>
					<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="#" class="banner_btn">View</a>
				</div>
				<br>
			</div>
		</div>