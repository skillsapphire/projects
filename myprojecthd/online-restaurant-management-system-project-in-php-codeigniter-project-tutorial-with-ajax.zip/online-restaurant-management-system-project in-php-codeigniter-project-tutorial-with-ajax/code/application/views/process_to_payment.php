<!DOCTYPE html>
<html>
<head>
	<title>Payment</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<style type="text/css">
		a:hover{ text-decoration: none; }
		.mode_logo >img {
		    width: 250px;
		}
		.mode_logo {
	    width: 50%;
	    height: 136px;
	    float: left;
	    padding-left: 277px;
	    padding-bottom: 36px !important;
	}

	.mode_button {
	    width: 50%;
	    height: 136px;
	    float: left;
	    padding-top: 35px;
	    padding-left: 133px;
	}
	</style>
</head>
<body>
<div class="container-fluid">
	<div class="container">
		<?php include('include/menu.php'); ?>
		<div class="col-sm-12">
			<h3 align="center">Select Payment Mode</h3>	
			
			<div class="payment_mode_block">
				<div class="mode_logo">
					<img src="<?php echo base_url().'tool/img/cod.png' ?>">
				</div>
				<div class="mode_button">
					<a href="<?php echo base_url().'index.php/home/continue_payment/1/'.$this->uri->segment(3) ?>" class="btn btn-primary">Continue</a>
				</div>
			</div>
			<div class="payment_mode_block">
				<div class="mode_logo">
					<img src="<?php echo base_url().'tool/img/w.jpg' ?>" style=" height: 103px; border-radius: 21px; ">
				</div>
				<div class="mode_button">
					<a href="<?php echo base_url().'index.php/home/continue_payment/2/'.$this->uri->segment(3) ?>" class="btn btn-primary">Continue</a>
				</div>
			</div>
		</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>
<script type="text/javascript">
	
</script>