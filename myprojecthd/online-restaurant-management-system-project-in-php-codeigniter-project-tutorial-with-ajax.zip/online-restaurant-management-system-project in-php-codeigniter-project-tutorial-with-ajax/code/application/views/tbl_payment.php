<!DOCTYPE html>
<html>
<head>
	<title>Table Payment</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<style type="text/css">
		a:hover{ text-decoration: none; }
		.payment_method_box {
		    width: 60%;
		    height: 150px;
		    margin-bottom: 100px;
		    margin-top: 100px;
		    margin-left: 350px;
		}
		.payment_method_img > img {
		    width: 200px;
		    float: left;
		    margin-right: 17px;
		    height: 85px;
		}
		.payment_method_button_box {
		    padding-top: 21px;
		}
	</style>
</head>
<body>
<div class="container-fluid">
	<div class="container">
		<?php include('include/menu.php'); ?>
		<div class="col-sm-12">
			<h3>Select Payment Mode</h3>
			<div class="col-sm-6">
			<div class="payment_method_box">
				<div class="payment_method_img">
					<img src="<?php echo base_url().'tool/img/w.jpg' ?>">
				</div>
				<div class="payment_method_button_box">
					<a href="javascript:;" data-url="<?php echo base_url().'index.php/home/continue_payment_table/'.$this->uri->segment(3) ?>" id="pay_tbl_amount" class="btn btn-success">Continue</a>
				</div>
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>
<script type="text/javascript">
	$(document).on('click','#pay_tbl_amount',function(){
		url=$(this).attr('data-url');
		$.post(url,function(fb){
			if(fb.match(2))
			{
				alert('Please Manage Your Wallet Balance')
			}
			else if(fb.match(1))
			{
				window.location.href='<?php echo base_url().'index.php/home/tbl_payment_success' ?>';
			}
			else 
			{
				alert('Same Technical Problum Plese Try Again')
			}
		})
	});
</script>