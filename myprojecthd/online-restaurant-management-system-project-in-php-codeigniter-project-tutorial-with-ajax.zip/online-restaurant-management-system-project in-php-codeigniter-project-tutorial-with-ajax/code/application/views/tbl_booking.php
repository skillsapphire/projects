<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
</head>
<body>
<style type="text/css">
	.tbl_box
	{
		background: red;
		color: white;
		width:120px;
		height: 100px;
		text-align: center;
		line-height: 100px;
		cursor: pointer;
	}
</style>
<div class="container-fluid">
	<div class="container">
		<?php include('include/menu.php'); ?>
		<div class="col-sm-12">
			<h3>Table Booking</h3>
		<div style="border:2px solid black;padding: 10px;">
		<h4>4 Member</h4>
		<div class="row">
			<?php 
			if($four_table)
			{
			foreach($four_table as $ftbl)
			{
			?>
			<a href="<?php echo base_url().'index.php/home/table_billing/'.$ftbl['id'] ?>"><div class="col-sm-2">
				<div class="tbl_box">
					<?php echo $ftbl['table_no'] ?>
				</div>
			</div></a>
			<?php 
			}
			}
			else 
			{
			?>
			<div class="col-sm-12">
				<h3>Table Not Found</h3>
			</div>
			<?php 
			}
			?>
		</div>
	    </div><br>
	    <div style="border:2px solid black;padding: 10px;">
		<h4>6 Member</h4>
		<div class="row">
			<?php 
			if($six_table)
			{
			foreach($six_table as $stbl)
			{
			?>
			<a href="<?php echo base_url().'index.php/home/table_billing/'.$stbl['id'] ?>"><div class="col-sm-2">
				<div class="tbl_box">
					<?php echo $stbl['table_no'] ?>
				</div>
			</div></a>
			<?php 
			}
			}
			else 
			{
			?>
			<div class="col-sm-12">
				<h3>Table Not Found</h3>
			</div>
			<?php 
			}
			?>
			
		</div>
	    </div><br>
	    <div style="border:2px solid black;padding: 10px;">
		<h4>2 Member</h4>
		<div class="row">
			<?php 
			if($two_table)
			{
			foreach($two_table as $ttbl)
			{
			?>
			<a href="<?php echo base_url().'index.php/home/table_billing/'.$ttbl['id'] ?>"><div class="col-sm-2">
				<div class="tbl_box">
					<?php echo $ttbl['table_no'] ?>
				</div>
			</div></a>
			<?php 
			}
			}
			else 
			{
			?>
			<div class="col-sm-12">
				<h3>Table Not Found</h3>
			</div>
			<?php 
			}
			?>
		</div>
	    </div><br>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>