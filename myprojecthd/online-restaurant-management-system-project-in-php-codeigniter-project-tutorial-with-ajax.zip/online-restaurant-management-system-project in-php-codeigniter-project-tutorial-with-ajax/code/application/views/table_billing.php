<!DOCTYPE html>
<html>
<head>
	<title>Table Billing</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'tool/css/style.css' ?>">
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/jquery-3.2.1.min.js' ?>"></script>
	<script type="text/javascript" src="<?php echo  base_url().'tool/js/bootstrap.js' ?>"></script>
	<style type="text/css">
		a:hover{ text-decoration: none; }
		.biilling_info {
		    margin-top: 30px;
		}
	</style>
</head>
<body>
<div class="container-fluid">
	<div class="container">
		<?php include('include/menu.php'); ?>
		<div class="col-sm-12">
			<h3>Login</h3>
			<div class="col-sm-6">
				<img src="<?php echo base_url().'tool/img1/banner.jpeg' ?>" class="img-responsive"><br>
			</div>
			<div class="col-sm-6"><br>
				<div class="row">
					<div class="col-sm-9">
						Table No : <?php echo $table_info[0]['table_no'] ?>
					</div>
					<div class="col-sm-3">
						Price : $<?php echo $table_info[0]['amount'] ?>
					</div>
				</div>
				<div class="biilling_info">
				<div class="row">
					<div class="col-sm-12">
						<div class="form-group">
							<label>Select Date</label>
							<input type="date" name="date" id="date" class="form-control">
						</div>
					</div>
					<div class="col-sm-6">
						<div class="form-group">
							<label>Time Start</label>
							<input type="time" name="stime" id="stime"  class="form-control">
						</div>
					</div>
					<div class="col-sm-6">
						<div class="form-group">
							<label>Time End</label>
							<input type="time" name="etime" id="etime"  class="form-control">
						</div>
					</div>
					<div class="col-sm-12">
						<div class="form-group">
							<label>Enter Name</label>
							<input type="hidden" id="tbl_no" value="<?php echo $table_info[0]['table_no'] ?>">
							<input type="hidden" id="amount" value="<?php echo $table_info[0]['amount'] ?>">
							<input type="text" name="name" id="name" placeholder="Enter Name" class="form-control">
						</div>
					</div>
					<div class="col-sm-12">
						<div class="form-group">
							<label>Enter Mobile No</label>
							<input type="text" name="mobile" id="mobile" placeholder="Enter Mobile No" class="form-control">
						</div>
					</div>
					<div class="col-sm-12">
						<div class="form-group">
							<label>Enter E-Mail</label>
							<input type="text" name="email" id="email" placeholder="Enter E-Mail" class="form-control">
						</div>
					</div>
					<div class="col-sm-12">
						<div class="form-group">
							<label>Enter Address</label>
							<textarea name="address" id="address" class="form-control" placeholder="Address"></textarea>
						</div>
					</div>
					<div class="col-sm-12">
						<div class="form-group">
							<button id="table_book_btn" class="btn btn-success">Book Now</button>
						</div>
					</div>
				</div>
				</div>
			</div>
				
			</div>
		</div>
		<div class="col-sm-12" style="background:green;color: white;">
			<br>
			<h3 align="center">Copyright@myprojecthd</h3>
			<br>
		</div>
	</div>
</div>
</body>
</html>
<script type="text/javascript">
	$(document).on('click','#table_book_btn',function(){
		date=$('#date').val();
		stime=$('#stime').val();
		etime=$('#etime').val();
		name=$('#name').val();
		email=$('#email').val();
		mobile=$('#mobile').val();
		address=$('#address').val();
		if(date=='')
			alert('Enter Date');
		else if(stime=='')
			alert('Enter Start Time')
		else if(etime=='')
			alert('Enter End Time')
		else if(name=='')
			alert('Enter Name');
		else if(mobile=='')
			alert('Enter Mobile No')
		else if(email=='')
			alert('Enter E-Mail')
		else if(address=='')
			alert('Enter Address')
		else 
		{
			var data={
				'bookdate_date':date,
				'stime':stime,
				'etime':etime,
				'name':name,
				'mobile_no':mobile,
				'email':email,
				'address':address,
				'table_no':$('#tbl_no').val(),
				'amount':$('#amount').val(),
			};
			$.post('<?php echo base_url().'index.php/home/table_billing/'; ?>',data,function(fb){
				if(fb!=0)
				{
					window.location.href='<?php echo base_url().'index.php/home/tbl_payment/' ?>'+fb;
				}
				else 
				{
					alert('Same Technical Problum Plese Try Again');
				}
			})
		}
	});
</script>