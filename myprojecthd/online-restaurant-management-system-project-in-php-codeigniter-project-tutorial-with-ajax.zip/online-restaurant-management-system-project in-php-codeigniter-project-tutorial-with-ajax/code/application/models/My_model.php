<?php 
class My_model extends CI_model
{
	public function select_data($tbl_name,$field,$warr='')
	{
		$this->db->select($field);
		$this->db->from($tbl_name);
		if($warr!='')
		{
			$this->db->where($warr);
		}
		$r1=$this->db->get();
		return $r1->result_array();
	}
	function insert_data($tbl_name,$data)
	{
		return $this->db->insert($tbl_name,$data);
	}
	function update_data($tbl_name,$data,$wdata)
	{
		$this->db->where($wdata);
		return $this->db->update($tbl_name,$data);
	}
	function delete_data($warr,$tbl_name)
	{
		$this->db->where($warr);
		return $this->db->delete($tbl_name);
	}
}

?>