<?php
class Home extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}
	function index()
	{
		$data['products']=$this->my_model->select_data('products','*',array('status'=>'1'));
		$this->load->view('home1',$data);
	}
	function food_order()
	{
		$this->load->view('food_order');
	}
	function about()
	{
		$this->load->view('about');
	}
	function contect()
	{
		$this->load->view('contect');
	}
	function tbl_booking()
	{
		$data['two_table']=$this->my_model->select_data('table_info','*',array('category'=>'2 Member'));
		$data['four_table']=$this->my_model->select_data('table_info','*',array('category'=>'4 Member'));
		$data['six_table']=$this->my_model->select_data('table_info','*',array('category'=>'6 Member'));
		$this->load->view('tbl_booking',$data);
	}
	function table_billing($id='')
	{
		if($this->input->method()=='post')
		{
			$_POST['user_id']=$this->session->userdata('user_id');
			$res=$this->db->insert('table_booking',$_POST);
			$last_id=$this->db->insert_id();
			if($res)
				echo $last_id;
			else 
				echo '0';
		}
		else 
		{
			$data['table_info']=$this->my_model->select_data('table_info','*',array('id'=>$id));
			$this->load->view('table_billing',$data);
		}
		
	}
	function tbl_payment($id)
	{
		$this->load->view('tbl_payment');
	}
	function continue_payment_table($id)
	{
		$tb_info=$this->my_model->select_data('table_booking','*');
		$user_info=$this->my_model->select_data('users','amount',array('id'=>$tb_info[0]['user_id']));
		if($tb_info[0]['amount'] > $user_info[0]['amount'])
		{
			echo 2;
		}
		else
		{
			$new_amount=$user_info[0]['amount']-$tb_info[0]['amount'];
			$this->db->where(array('id'=>$tb_info[0]['user_id']));
			$this->db->update('users',array('amount'=>$new_amount));	
			$this->db->where('id',$id);
			$res=$this->db->update('table_booking',array('mode'=>'COD'));
			if($res)
				echo '1';
			else 
				echo '0';
		}
	}
	function login()
	{
		if($this->input->method()=='post')
		{
			$data=$this->input->post();
			$res=$this->my_model->select_data('users','email,id',$data);
			if($res)
			{
				$this->session->set_userdata('email',$res[0]['email']);
				$this->session->set_userdata('user_id',$res[0]['id']);
				echo '1';
			}
			else 
				echo 0;
		}
		else 
		{
			$this->load->view('login');
		}	
	}
	function logout()
	{
		$this->session->unset_userdata('email');
		$this->session->unset_userdata('user_id');
		redirect(base_url());
	}
	function signup()
	{
		if($this->input->method()=='post')
		{
			$data=$this->input->post();
			$res=$this->db->insert('users',$data);
			if($res)
			{
				echo 1;
			}
			else 
			{
				echo 0;
			}
		}
		else 
		{
			$this->load->view('signup');
		}
	}
	function forgot_password()
	{
		if($this->input->method()=='post')
		{
			$check_status=$this->my_model->select_data('users','email',$_POST);
			if($check_status)
			{
				$ps=rand();
				$this->db->where($_POST);
				$res=$this->db->update('users',array('password'=>$ps));
				if($res)
					echo '1';
				else 
					echo '0';
				
			}
			else 
			{
				echo '2';
			}
		}
		else 
		{
			$this->load->view('forgot_password');
		}
	}
	function add_to_cart()
	{
		$check_product=$this->my_model->select_data('products','qty',array('id'=>$_POST['product_id']));
		
		if($check_product[0]['qty']>0)
		{
		$check_status=$this->my_model->select_data('add_to_cart','qty',$_POST);
		if($check_status)
		{
			$q=$check_status[0]['qty']+1;
			$new_qty=$check_product[0]['qty']-1;

			$this->db->where('id',$_POST['product_id']);
			$this->db->update('products',array('qty'=>$check_product[0]['qty']-1));
			$this->db->where($_POST);
			$res=$this->db->update('add_to_cart',array('qty'=>$q));
		}
		else 
		{
			$_POST['qty']=1;
			$res=$this->db->insert('add_to_cart',$_POST);
		}

		if($res)
			echo '1';
		else 
			echo '0';
		}
		else 
		{
			echo '2';
		}
	}
	function cart()
	{
		$user_id=$this->session->userdata('user_id');
		$this->db->join('products','add_to_cart.product_id=products.id');
		$data['cart_products']=$this->my_model->select_data('add_to_cart','add_to_cart.*,products.name as pname,products.price',array('user_id'=>$user_id));
	
		$this->load->view('cart',$data);
	}
	function delete_cart_product($id)
	{
		$cart_info=$this->my_model->select_data('add_to_cart','*',array('id'=>$id));
		$product_info=$this->my_model->select_data('products','qty',array('id'=>$cart_info[0]['product_id']));
		$new_qty=$product_info[0]['qty']+$cart_info[0]['qty'];
		$this->db->where('id',$cart_info[0]['product_id']);
		$this->db->update('products',array('qty'=>$new_qty));
		$this->db->where('id',$id);
		$this->db->delete('add_to_cart');
		redirect(base_url().'index.php/home/cart');
	}
	function continue_cart()
	{
		$user_id=$this->session->userdata('user_id');
		$data['user_info']=$this->my_model->select_data('users','*',array('id'=>$user_id))[0];

		$this->db->join('products','add_to_cart.product_id=products.id');
		$data['cart_info']=$this->my_model->select_data('add_to_cart','add_to_cart.*,products.name,products.price',array('user_id'=>$user_id));
		$this->load->view('checkout',$data);
	}
	function place_order()
	{
		$user_id=$this->session->userdata('user_id');
		$cart_data=json_encode($this->my_model->select_data('add_to_cart','product_id,qty',array('user_id'=>$user_id)));
		$data=$this->input->post();
		$data['order_date']=date('d/m/Y');
		$data['product_info']=$cart_data;
		$data['order_no']='RBS'.date('is');
		
		$this->db->where('user_id',$user_id);
		$this->db->delete('add_to_cart');
		$res=$this->db->insert('order_master',$data);
		$id=$this->db->insert_id();
		if($res)
			redirect(base_url().'index.php/home/process_to_payment/'.$id);
		else 
			redirect(base_url().'index.php/home/order_cancel');
	}
	function process_to_payment($id)
	{
			$this->load->view('process_to_payment');	
	}
	function continue_payment($type,$id)
	{
		if($type=='1')
		{
			$this->db->where('id',$id);
			$res=$this->db->update('order_master',array('payment_mode'=>'COD'));
			if($res)
				redirect(base_url().'index.php/home/order_success/'.$id);
			else 
				redirect(base_url().'index.php/home/order_cancel');
		}
		else 
		{
			$order_prod_info=$this->my_model->select_data('order_master','product_info',array('id'=>$id));
			$pinfo= json_decode($order_prod_info[0]['product_info']);
			$main_amount=0;
			foreach($pinfo as $pi)
			{
				$oamount=$this->my_model->select_data('products','price',array('id'=>$pi->product_id));
				$bacup_aamount=$oamount[0]['price']*$pi->qty;
				$main_amount=$main_amount+$bacup_aamount;
			}
			echo $user_id=$this->session->userdata('user_id');
			$user_info=$this->my_model->select_data('users','amount',array('id'=>$user_id));
			if($main_amount > $user_info[0]['amount'])
			{
				redirect(base_url().'index.php/home/order_cancel');
			}
			else 
			{
				$this->db->where('id',$id);
				$this->db->update('order_master',array('payment_mode'=>'W'));
				redirect(base_url().'index.php/home/order_success/'.$id);
			}
		}
	}
	function order_success($id)
	{
		$order_no=$this->my_model->select_data('order_master','order_no',array('id'=>$id));
		$data['order_no']=$order_no;
		$this->load->view('order_success',$data);
	}
	function tbl_payment_success()
	{
		$this->load->view('tbl_payment_success');
	}
	function order_cancel()
	{
		echo "Order Cancel";
	}
}
?>