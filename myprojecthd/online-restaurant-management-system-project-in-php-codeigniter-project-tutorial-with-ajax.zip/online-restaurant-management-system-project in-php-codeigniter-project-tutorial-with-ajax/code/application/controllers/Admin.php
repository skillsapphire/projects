<?php 
class Admin extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$user_session=$this->session->userdata('user_session');
		if(!$user_session)
		{
			redirect('admin_login');
		}
	}
	public function index()
	{
		$data['page_title']="Admin Home";
		$this->load->view('admin/admin_home',$data);
	}
	function users()
	{
		$data['page_title']="Users";
		$data['user_list']=$this->my_model->select_data('users','*');
		$this->load->view('admin/users',$data);
	}
	function add_amount($id)
	{
		if($this->input->method()=='post')
		{
			$amount=$this->my_model->select_data('users','amount',array('id'=>$id));
			$new_amount=$amount[0]['amount']+$_POST['amount'];
			$this->db->where('id',$id);
			$res=$this->db->update('users',array('amount'=>$new_amount));
			if($res)
				echo '1';
			else 
				echo '0';
		}
		else 
		{
			$data['page_title']="Add Amount";
			$this->load->view('admin/add_amount',$data);
		}
		
	}
	public function cat()
	{
		$data['page_title']="Category";
		$cat_data=$this->my_model->select_data('category','*');
		$this->db->join('category','sub_category.cat=category.id');
		$sub_cat=$this->my_model->select_data('sub_category',['sub_category.*','category.name as cat_name']);
		$data['cats']=$cat_data;
		$data['sub_cats']=$sub_cat;
		$this->load->view('admin/cat',$data);
	}
	function add_cat()
	{
		$data=$this->input->post();
		$res=$this->my_model->insert_data('category',$data);
		if($res)
			echo 1;
		else 
			echo 0; 
	}
	function add_sub_cat()
	{
		$data=$this->input->post();
		$res=$this->my_model->insert_data('sub_category',$data);
		if($res)
			echo '1';
		else 
			echo '0';
	}
	public function product()
	{
		$data['page_title']="Manage Product";
		$data['products']=$this->my_model->select_data('products','*');
		$this->load->view('admin/product',$data);
	}
	public function setting()
	{
		echo "Setting";
	}
	function status_change()
	{
		$tbl_name=$this->input->post('tbl_name');
		$field=$this->input->post('field');
		$field_data=$this->input->post('field_data');
		$op_data=$this->input->post('op_data');

		$data_arr=array('status'=>$op_data);
		$w_arr=array($field=>$field_data);
		$res=$this->my_model->update_data($tbl_name,$data_arr,$w_arr);
		if($res)
		{
			echo '1';
		}
		else 
		{
			echo '0';
		}
	}
	function delete_data()
	{
		$tbl_name=$this->input->post('tbl_name');
		$id=$this->input->post('id');
		$field=$this->input->post('field1');
		$res=$this->my_model->delete_data(array($field=>$id),$tbl_name);
		if($res)
		{
			redirect('admin/cat');
		}
	}
	function update_cat()
	{
		$name=$this->input->post('name');
		$id=$this->input->post('id');
		$data_arr=array('name'=>$name);
		$w_arr=array('id'=>$id);
		$res=$this->my_model->update_data('category',$data_arr,$w_arr);
		if($res)
			echo '1';
		else 
			echo '0';

	}
	function change_cat()
	{
		$id=$this->input->post('id');
		$cat_id=$this->input->post('cat_id');
		$data_arr=array('cat'=>$cat_id);
		$w_arr=array('id'=>$id);
		$res=$this->my_model->update_data('sub_category',$data_arr,$w_arr);
		if($res)
			echo 1;
		else 
			echo 0;
		
	}
	function supdate()
	{
		$data=$this->input->post('id');
		$name=$this->input->post('sname');
		$res=$this->my_model->update_data('sub_category',array('name'=>$name),array('id'=>$data));
		if($res)
			echo 1;
		else 
			echo 0;
	}
	function add_products()
	{
		
		$data=$this->input->post();
		$config['upload_path']   	= './uploads/products';
        $config['allowed_types'] 	= 'jpg|png|jpeg';
		$config['encrypt_name'] = TRUE;
        $this->load->library('upload', $config);
		$this->upload->initialize($config);
        if ($this->upload->do_upload('img')) {	
            $uploaddata    = $this->upload->data();
          	$data['img']=$uploaddata['file_name'];
        	$resp=$this->my_model->insert_data('products',$data);  	
        	if($resp)
				echo 1;
			else 
				echo 0;
        }
        else 
        {
        	echo '2';
        }
		die();
		
		
	}
	function orders()
	{
		$data['page_title']="Orders";
		$this->db->where('payment_mode!=""');
		$data['all_orders']=$this->my_model->select_data('order_master','*');
		$this->load->view('admin/orders',$data);
	}
	function view_order($id)
	{
		$data['page_title']="View Orders";
		$data['orders']=$this->my_model->select_data('order_master','product_info',array('id'=>$id));
		$this->load->view('admin/view_order',$data);
	}
	function change_order_status()
	{
		$this->db->where('id',$_POST['id']);
		$res=$this->db->update('order_master',array('status'=>$_POST['status']));
		if($res)
			echo 1;
		else 
			echo 0;
	}
	function tables()
	{
		$data['page_title']='Tables';
		$data['tables']=$this->my_model->select_data('table_info','*');
		$this->db->where('mode!=""');
		$data['book_tables']=$this->my_model->select_data('table_booking','id,table_no,bookdate_date,name,amount');
		$this->load->view('admin/tables',$data);
	}
	function show_table_info($id)
	{
		$data['page_title']='Book Table Information	';
		$data['book_tables']=$this->my_model->select_data('table_booking','*',array('id'=>$id))[0];
		$this->load->view('admin/show_table_info',$data);	
	}
	function add_new_table()
	{
		if($this->input->method()=='post')
		{
			$res=$this->db->insert('table_info',$_POST);
			if($res)
				echo '1';
			else 
				echo '0';
		}
		else 
		{
			$data['page_title']='Add Tables';
			$this->load->view('admin/add_new_table',$data);
		}
	}

}
?>