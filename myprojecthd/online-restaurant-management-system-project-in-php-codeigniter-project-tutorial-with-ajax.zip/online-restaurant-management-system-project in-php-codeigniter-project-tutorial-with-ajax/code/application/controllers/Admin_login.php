<?php 
class Admin_login extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();

	}
	public function index()
	{
		$this->load->view('admin/login');
	}
	public function login_code()
	{
		$data=$this->input->post();
		$ps=$this->input->post('ps');
		unset($data['ps']);
		$data['ps']=md5($ps);
		$res=$this->my_model->select_data('admin','*',$data);		
		if($res)
		{
			$this->session->set_userdata('user_session','admin');
			echo 1;
		}
		else 
			echo 0;
	}
}
?>