<div class="row mt-4 mb-4">
	<div class="col-sm-12">
		<div class="success_block mb-4 mt-4">
			<img src="<?php echo base_url().'tools/img/success.png' ?>">
			<h2>Your Order Successfully Booked</h2>
		</div>
	</div>
</div>