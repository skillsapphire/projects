<div class="row mt-4 m-4">
	<div class="col-sm-12">
		<div class="payment_method_box">
			<table>
				<tr>
					<td style="width: 80%"><img src="<?php echo base_url().'tools/img/paypal.png' ?>" width="100px"></td>
					<td style="width: 20%"><button class="btn btn-info pay_pal_pay">Pay Now</button></td>
				</tr>
				<tr>
					<td style="width: 80%"><img src="<?php echo base_url().'tools/img/cod.png' ?>" width="100px"></td>
					<td style="width: 20%"><a href="<?php echo base_url().'index.php/home/cod_payment' ?>" class="btn btn-info">Pay Now</a></td>
				</tr>
			</table>
		</div>
	</div>
</div>
<div class="form_box"></div>