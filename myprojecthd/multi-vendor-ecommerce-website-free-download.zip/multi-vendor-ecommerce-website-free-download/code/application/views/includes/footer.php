<div class="footer_box">
    <div class="row">
      <div class="col-sm-4">
        <h4 align="center">Quick Links</h4>
        <ul class="quick_link">
          <li><a href="javascript:;">Service</a></li>
          <li><a href="javascript:;">Support</a></li>
          <li><a href="javascript:;">T&C</a></li>
        </ul>
      </div>
      <div class="col-sm-4">
        <h4 align="center">Contect Us</h4>
        <p><b>Address </b>:</p>
        <p><b>Contectl No </b>:</p>
        <p><b>E-Mail</b> :</p>
      </div>
      <div class="col-sm-4">
        <h4 align="center">Social Links</h4>
        <i class="fa fa-facebook social_icon"></i>
        <i class="fa fa-google-plus social_icon"></i>
        <i class="fa fa-linkedin social_icon" aria-hidden="true"></i>
        <i class="fa fa-pinterest-p social_icon" aria-hidden="true"></i>
        <i class="fa fa-whatsapp social_icon" aria-hidden="true"></i>
      </div>
    </div>
    </div>

</div>
 <script src="<?php echo base_url() ?>tools/js/jquery.min.js"></script>
<script src="<?php echo base_url() ?>tools/js/popper.min.js"></script>
<script src="<?php echo base_url() ?>tools/js/swiper.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>tools/js/bootstrap.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>tools/js/custom.js"></script>
</body>
</html>